"""Ornaments, comments and colour-marked sections: what marking them does.
No Qt imports.

These functions work out a change from the selection and return it; the
main window applies it as one undoable step (see commands.py), so every
annotation can be undone like a link.

* Ornaments are stored by note (model.Ornament). Marking one on a single
  score note also links the selected performance notes to it, which is what
  a trill's notes need: they belong to that score note and nowhere else.
* Comments are for a second reviewer. Each is about some performance notes,
  never score notes, and can collect replies and be resolved.
* Sections are colour-marked stretches of the performance, in seconds. They're
  marked on the performance; their score side is worked out from the links.
  Each has an id and keywords for its .match file line.
* Pitch errors aren't marked at all: a note played instead of its score note
  is linked to it, and the pitches show the mistake. pitch_check says what
  the rules make of a performance note's links, for the Pitch errors panel.
"""
from __future__ import annotations

import dataclasses
import html
import re
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

import numpy as np

from .model import (GROUPING_KEYWORDS, GROUPINGS, ORNAMENT_ATTRIBUTES, Comment, Link, Ornament,
                    Project, Reply, Section, chord_notes)

# key, as stored in ornaments.json and .match files: (name in the interface, mark on the rolls)
ORNAMENT_TYPES = {
    "trill": ("Trill", "tr"),
    "mordent": ("Mordent", "mord"),
    "inverted-mordent": ("Inverted mordent", "inv. mord"),
    "turn": ("Turn", "turn"),
    "inverted-turn": ("Inverted turn", "inv. turn"),
    "tremolo": ("Tremolo", "trem"),
    "generic_ornament": ("Other ornament", "orn"),
}
DEFAULT_ORNAMENT = "trill"

# name in the interface: colour. Light enough behind the notes, and apart from
# the note colours; the names keep them apart without relying on colour alone.
SECTION_COLOURS = {
    "Orange": "#E69F00",
    "Sky blue": "#56B4E9",
    "Lime": "#9BCB3C",
    "Violet": "#A17FD6",
    "Rose": "#EE8FA0",
    "Grey": "#9AA4AE",
}
DEFAULT_SECTION_COLOUR = "#E69F00"


class AnnotationError(ValueError):
    """The selection doesn't fit the change. The message says what to select."""


def _plural(n: int, word: str) -> str:
    return f"{n} {word}{'' if n == 1 else 's'}"


def now() -> str:
    return datetime.now().isoformat(timespec="seconds")


# --------------------------------------------------------------------------- ornaments

def ornament_name(kind: str) -> str:
    """The ornament type's name in the interface; unknown types from files are
    shown as they're spelled there."""
    return ORNAMENT_TYPES.get(kind, (kind.replace("_", " ").replace("+", " and "), ""))[0]


def a_ornament(kind: str) -> str:
    """The ornament's name with "a" or "an": "a trill", "an inverted mordent"."""
    name = ornament_name(kind).lower()
    return f"{'an' if name[:1] in 'aeiou' else 'a'} {name}"


# What each ornament type plays, for the tooltip of an ornament written in the score.
ORNAMENT_DESCRIPTIONS = {
    "trill": "a quick alternation of the note and the one above it",
    "mordent": "the note, the one below it and the note again, quickly",
    "inverted-mordent": "the note, the one above it and the note again, quickly",
    "turn": "the note above, the note, the note below and the note again",
    "inverted-turn": "the note below, the note, the note above and the note again",
    "tremolo": "the note repeated quickly",
    "shake": "a short trill",
    "schleifer": "a slide of two or three notes up to the note",
    "haydn": "Haydn's ornament, a turn",
}


def ornament_description(kind: str) -> str:
    """What an ornament type plays, in words, or "" for one FERMATA doesn't know."""
    return ORNAMENT_DESCRIPTIONS.get(kind, "")


def ornament_mark(kind: str) -> str:
    """The short mark drawn on the rolls, such as "tr" for a trill."""
    known = ORNAMENT_TYPES.get(kind)
    return known[1] if known else kind.replace("_", " ")


@dataclass(frozen=True)
class OrnamentChange:
    ornaments: list        # the project's ornaments afterwards
    add: frozenset         # links to add
    remove: frozenset      # links to remove
    summary: str


def grouping_name(orn) -> str:
    """A grouping's name in the interface: the ornament's type ("Trill"), the
    kind ("Basso continuo realization", "Improvisation"), or an other
    grouping's own name, its words apart again ("special grouping")."""
    if orn.group == "ornament":
        return ornament_name(orn.type)
    if orn.group == "other":
        return orn.type.replace("_", " ")
    return GROUPINGS.get(orn.group, orn.group)


def a_grouping(orn) -> str:
    """Its name with "a" or "an": "a trill", "an improvisation"."""
    name = grouping_name(orn).lower() if orn.group != "other" else grouping_name(orn)
    return f"{'an' if name[:1].lower() in 'aeiou' else 'a'} {name}"


def grouping_mark(orn) -> str:
    """The short mark on its box in the performance roll: "tr", "continuo",
    "impro", or an other grouping's name."""
    if orn.group == "ornament":
        return ornament_mark(orn.type)
    return {"continuo_realization": "continuo", "improvisation": "impro"}.get(
        orn.group, grouping_name(orn))


def other_grouping_name(text: str) -> str:
    """An other grouping's name as it goes into a .match file: lower case,
    with an underscore for each run of spaces ("Special Grouping" is
    "special_grouping"). Letters, digits and spaces only, and not a name
    FERMATA has for something else. Raises AnnotationError, in words."""
    text = text.strip()
    if not text:
        raise AnnotationError("Name the grouping first, such as Special grouping.")
    if not re.fullmatch(r"[A-Za-z0-9 ]+", text):
        raise AnnotationError("A grouping's name can have letters, digits and spaces only.")
    name = re.sub(r" +", "_", text).lower()
    taken = set(GROUPING_KEYWORDS) | set(ORNAMENT_ATTRIBUTES.values()) | {"pitch_error"}
    if name in taken:
        raise AnnotationError(f"{text} is a name FERMATA has already: choose another one.")
    return name


def mark_grouping(project: Project, sel_perf, sel_score, group: str, kind: str) -> OrnamentChange:
    """Mark performance notes as a grouping on the score: an ornament of type
    kind, a basso continuo realization or an other grouping named kind, on one
    score note, or an improvisation on a chord: every score note on the onset
    of the one chosen. Every performance note is linked to the score note, an
    improvisation's to the chord's lowest note, and their links to other score
    notes are removed: they belong to the grouping. Groupings that share a note
    with the new one are replaced by it."""
    if group == "ornament":
        return mark_ornament(project, sel_perf, sel_score, kind)
    score_ids, perf_ids = sorted(sel_score), sorted(sel_perf)
    new_name = grouping_name(Ornament(kind, (), (), group))
    if not perf_ids:
        raise AnnotationError(f"Select the performance notes of the {new_name.lower()} first.")
    if len(score_ids) != 1:
        raise AnnotationError(f"A {new_name.lower()} belongs to one score "
                              f"{'chord' if group == 'improvisation' else 'note'}: choose it.")
    sid = score_ids[0]
    if group == "improvisation":
        score_ids = chord_notes(project.score, sid)
        sid = score_ids[0]                 # the lowest note of the chord
    new = Ornament(kind, score_ids, perf_ids, group)
    replaced = [o for o in project.ornaments
                if set(o.score) & set(new.score) and o.group == group
                or set(o.performance) & set(new.performance)]
    ornaments = [o for o in project.ornaments if all(o is not r for r in replaced)] + [new]
    al = project.alignment
    add = {(sid, pid) for pid in perf_ids} - al.links
    remove = {(s, pid) for pid in perf_ids for s in al.by_perf.get(pid, ()) if s != sid}
    on = (f"the chord at beat {float(project.score.onset[project.score.row[sid]]):g} "
          f"({_plural(len(score_ids), 'score note')}, linked to its lowest, {sid})"
          if group == "improvisation" else f"score note {sid}")
    summary = (f"Marked {a_grouping(new)} on {on}, played by "
               f"{_plural(len(perf_ids), 'performance note')}")
    if replaced:
        summary += f"; it replaces {_plural(len(replaced), 'grouping')}"
    return OrnamentChange(ornaments, frozenset(add), frozenset(remove), summary + ".")


def mark_ornament(project: Project, sel_perf, sel_score, kind: str) -> OrnamentChange:
    """Mark performance notes as an ornament of type kind on one score note.

    Every ornament type belongs to one score note, as in MusicXML, where each
    ornament is written on a note, and in .match ornament lines. Every
    performance note is linked to the score note, and their links to other
    score notes are removed: they play this ornament. Ornaments that share a
    note with the new one are replaced by it.
    """
    score_ids, perf_ids = sorted(sel_score), sorted(sel_perf)
    if not perf_ids:
        raise AnnotationError("Select the performance notes that play the ornament first.")
    if len(score_ids) != 1:
        raise AnnotationError("An ornament belongs to one score note: choose the note it "
                              "ornaments.")
    new = Ornament(kind, score_ids, perf_ids)
    replaced = [o for o in project.ornaments
                if set(o.score) & set(new.score) or set(o.performance) & set(new.performance)]
    ornaments = [o for o in project.ornaments if all(o is not r for r in replaced)] + [new]
    al = project.alignment
    sid = score_ids[0]
    add = {(sid, pid) for pid in perf_ids} - al.links
    remove = {(s, pid) for pid in perf_ids for s in al.by_perf.get(pid, ()) if s != sid}
    summary = (f"Marked {a_ornament(kind)} on score note {sid}, played by "
               f"{_plural(len(perf_ids), 'performance note')}")
    if replaced:
        summary += f"; it replaces {_plural(len(replaced), 'ornament')}"
    return OrnamentChange(ornaments, frozenset(add), frozenset(remove), summary + ".")


def describe_ornament(orn) -> str:
    """A grouping in words: "Trill on score note n12, played by 5 performance
    notes", "Improvisation on a chord of 3 score notes, played by 8 ..."."""
    on = (f"score note {orn.score[0]}" if len(orn.score) == 1
          else f"a chord of {_plural(len(orn.score), 'score note')}" if orn.group == "improvisation"
          else _plural(len(orn.score), "score note"))
    name = grouping_name(orn)
    return (f"{name[:1].upper()}{name[1:]} on {on}, played by "
            f"{_plural(len(orn.performance), 'performance note')}")


def ornaments_of(project: Project, sel_perf, sel_score) -> list:
    """The ornaments that have a selected note."""
    sel_perf, sel_score = set(sel_perf), set(sel_score)
    return [o for o in project.ornaments
            if set(o.score) & sel_score or set(o.performance) & sel_perf]


# --------------------------------------------------------------------------- comments

def new_comment(text: str, author: str, sel_perf) -> Comment:
    """A comment about the selected performance notes. Comments are about the
    performance only, so selected score notes don't come into it."""
    text = text.strip()
    if not text:
        raise AnnotationError("A comment needs some text.")
    if not sel_perf:
        raise AnnotationError("Select the performance notes the comment is about first.")
    return Comment(text, author, now(), sel_perf)


def reply(comment: Comment, text: str, author: str) -> Comment:
    text = text.strip()
    if not text:
        raise AnnotationError("A reply needs some text.")
    return dataclasses.replace(comment, replies=comment.replies + (Reply(author, now(), text),))


def comment_title(comment: Comment, number: int) -> str:
    """One line for the list of comments."""
    first = comment.text.splitlines()[0] if comment.text else ""
    parts = [f"{number}. {first}"]
    if comment.author:
        parts.append(f"({comment.author})")
    if comment.replies:
        n = len(comment.replies)
        parts.append(f"· {n} {'reply' if n == 1 else 'replies'}")
    if comment.resolved:
        parts.append("· resolved")
    return " ".join(parts)


def comment_thread_html(comment: Comment, number: int, dim: str = "#6B7784") -> str:
    """The comment and its replies, for the sidebar and the popup on the rolls.
    dim is the colour of the times, dimmer than the text on that background."""
    def when(stamp: str) -> str:
        try:
            return datetime.fromisoformat(stamp).strftime("%d %b %Y, %H:%M")
        except ValueError:
            return stamp

    def entry(author, time, text):
        head = html.escape(author or "Someone")
        if time:
            head += f" <span style='color:{dim}'>{html.escape(when(time))}</span>"
        return f"<p><b>{head}</b><br>{html.escape(text).replace(chr(10), '<br>')}</p>"

    status = "Resolved" if comment.resolved else "Open"
    notes = _plural(len(comment.performance), "performance note")
    out = [f"<p><b>Comment {number}</b> · {status} · on {notes}</p>",
           entry(comment.author, comment.time, comment.text)]
    out += [entry(r.author, r.time, r.text) for r in comment.replies]
    return "".join(out)


# --------------------------------------------------------------------------- sections

LINK_MARGIN = 2.0   # seconds: links further than this from where the time map puts a passage are stray


def linked_span(project: Project, score_span, tm=None) -> Optional[tuple]:
    """The stretch of the performance that the links of the score notes in
    score_span go to, from the first onset to the last offset, or None if they
    have no links. Links far from where the time map puts the passage are
    stray and left out, and so is a passage played again in between: the
    stretch is where the links are, not everything between its ends."""
    score, perf, by_score = project.score, project.performance, project.alignment.by_score
    lo = np.searchsorted(score.onset, score_span[0], "left")
    hi = np.searchsorted(score.onset, score_span[1], "left")
    if hi <= lo:
        return None
    tm = tm or project.time_map()
    first = tm.to_perf(float(score.onset[lo])) - LINK_MARGIN
    last = tm.to_perf(float(score.onset[hi - 1])) + LINK_MARGIN
    rows = [perf.row[p] for sid in score.ids[lo:hi] for p in by_score.get(sid, ())]
    rows = [r for r in rows if first <= perf.onset[r] <= last]
    if not rows:
        return None
    return (float(perf.onset[rows].min()), float(perf.offset[rows].max()))


def new_section(project: Project, sel_perf, name: str, colour: str,
                description: str = "") -> Section:
    """A section over the selected performance notes, from the first onset to
    the last offset, with the next free id. Sections are marked on the
    performance; their score side comes from the links. Its description,
    comma-separated keywords, goes into its .match file line; without one, it's
    DEFAULT_SECTION_KEYWORD."""
    perf = project.performance
    rows = [perf.row[i] for i in map(str, sel_perf) if i in perf.row]
    if not rows:
        raise AnnotationError("Select the performance notes the section covers first.")
    span = (float(perf.onset[rows].min()), float(perf.offset[rows].max()))
    return Section(name.strip() or f"Section {len(project.sections) + 1}", colour, span,
                   id=next_section_id(project.sections),
                   attributes=parse_keywords(description) or (DEFAULT_SECTION_KEYWORD,))


# What a section marked without a description is in a .match file's SectionAttrList.
DEFAULT_SECTION_KEYWORD = "rehearsal_repetition"


def next_section_id(sections) -> str:
    """The first id "s1", "s2", ... that no section has, for its .match file line."""
    used = {s.id for s in sections}
    n = 1
    while f"s{n}" in used:
        n += 1
    return f"s{n}"


def parse_keywords(text: str) -> tuple:
    """Comma-separated keywords, such as "rehearsal_repetition, theme", as a
    section's attributes: spaces inside one become underscores, since a .match
    file's list has none."""
    return tuple(dict.fromkeys(k.strip().replace(" ", "_") for k in text.split(",") if k.strip()))


def section_title(section: Section) -> str:
    """One line for the list of sections."""
    def fmt(v: float) -> str:
        return f"{v:.2f}".rstrip("0").rstrip(".")
    where = []
    if len(section.passes) > 1:
        n = len(section.passes)
        where.append("played twice" if n == 2 else f"played {n} times")
    elif section.performance:
        where.append(f"{fmt(section.performance[0])}–{fmt(section.performance[1])} s")
    if section.attributes:
        where.append(", ".join(section.attributes))
    return f"{section.name} ({'; '.join(where)})" if where else section.name


def colour_name(colour: str) -> Optional[str]:
    for name, value in SECTION_COLOURS.items():
        if value.lower() == colour.lower():
            return name
    return None


# --------------------------------------------------------------------------- pitch errors
#
# The rules: a performer who means to play a score note but plays another one
# makes a pitch error, and the note played is linked to the score note it was
# meant to be. That's only so when the two are at most PITCH_ERROR_RANGE
# semitones apart, as E and G are, on neighbouring lines of the staff. A note
# farther off is an insertion and has no link, unless a whole passage is played
# an octave off, as when an octave sign is missed. And if the score note's own
# pitch is played just before or after, or with it, that note is linked and the
# wrong one is an insertion.

PITCH_ERROR_RANGE = 4   # semitones a pitch error can be off its score note, either way
PITCH_NAMES = ["C", "C♯", "D", "E♭", "E", "F", "F♯", "G", "A♭", "A", "B♭", "B"]
TOGETHER = 0.04         # seconds: notes played this close are played together, as a chord
NEXT = 0.5              # seconds: how far "just before" and "just after" reach
LINE = 7                # semitones: notes this close in pitch are taken as one hand's line
AROUND = 3              # notes of that line on each side that tell whether it's an octave off


def pitch_name(p: int) -> str:
    return f"{PITCH_NAMES[p % 12]}{p // 12 - 1}"


def pitch_error_kind(semitones: int) -> str:
    """What a performance note played semitones above its score note (below,
    if negative) is: "same", "pitch error", "octave" (an octave off: right only
    if the passage around it is too) or "insertion"."""
    if semitones == 0:
        return "same"
    if abs(semitones) <= PITCH_ERROR_RANGE:
        return "pitch error"
    return "octave" if abs(semitones) == 12 else "insertion"


@dataclass(frozen=True)
class PitchCheck:
    pitch: int                            # the performance note's
    partners: tuple[tuple[str, int], ...]  # its score notes: id and pitch
    verdict: str                          # what the rules make of its links, in words


def pitch_check(project: Project, pid: str) -> PitchCheck:
    """The performance note pid, its score notes, and what the rules on pitch
    errors make of its links."""
    perf, score, al = project.performance, project.score, project.alignment
    row = perf.row[pid]
    pitch = int(perf.pitch[row])
    partners = tuple(sorted(((s, int(score.pitch[score.row[s]]))
                             for s in al.by_perf.get(pid, set()) if s in score.row),
                            key=lambda partner: -partner[1]))
    own = [s for s, p in partners if p == pitch]
    if any(pid in o.performance for o in project.ornaments):
        orn = next(o for o in project.ornaments if pid in o.performance)
        verdict = (f"Part of {a_grouping(orn)}: its notes differ from the score note by design, "
                   "so these rules don't apply.")
    elif not partners:
        verdict = ("Not linked, so it's an insertion. If it was meant to be a score note at most "
                   f"{PITCH_ERROR_RANGE} semitones away, link it to that note as a pitch error.")
    elif not own:
        verdict = " ".join(_partner_verdict(project, row, s, p) for s, p in partners)
    else:
        # It plays a score note at its own pitch, so it's no pitch error: links
        # to other pitches are extra.
        verdict = f"Linked to score note{_s(own)} {_and(own)}, {pitch_name(pitch)}, the same pitch."
        extra = [s for s, p in partners if p != pitch]
        if extra:
            names = _and([f"{s} ({pitch_name(p)})" for s, p in partners if p != pitch])
            verdict += (f" Also linked to score note{_s(extra)} {names}: "
                        f"{'that link is' if len(extra) == 1 else 'those links are'} extra, since "
                        f"it plays {own[0]} at its own pitch. "
                        f"{'That score note was' if len(extra) == 1 else 'Those were'} left out, "
                        f"or played by another note.")
    return PitchCheck(pitch, partners, verdict)


def _s(items) -> str:
    return "" if len(items) == 1 else "s"


def _and(items) -> str:
    """"a", "a and b", "a, b and c"."""
    items = list(items)
    return items[0] if len(items) == 1 else f"{', '.join(items[:-1])} and {items[-1]}"


def _partner_verdict(project: Project, row: int, sid: str, score_pitch: int) -> str:
    perf = project.performance
    off = int(perf.pitch[row]) - score_pitch
    kind = pitch_error_kind(off)
    said = f"Linked to score note {sid}, {pitch_name(score_pitch)}"
    if kind == "same":
        return f"{said}, the same pitch."
    if kind == "insertion":
        return (f"{said}, played {_apart(off)}: more than {PITCH_ERROR_RANGE} semitones off, "
                "so it's an insertion and shouldn't be linked.")
    right = _right_pitch_near(project, row, sid, score_pitch)
    if kind == "pitch error":
        return f"{said}, played {_apart(off)}: a pitch error, and the link is all it needs.{right}"
    said += (f", played {_apart(off)}: right only if the passage around it is played an "
             "octave off too.")
    if right:
        return said + right
    same = _also_off(project, row, off)
    if same is None:
        return said
    return said + (" The notes around it in the same hand are, so the link holds." if same else
                   " The notes around it in the same hand aren't, so it's an insertion.")


def _apart(off: int) -> str:
    """"3 semitones higher", "an octave lower"."""
    way = "higher" if off > 0 else "lower"
    n = abs(off)
    if n == 12:
        return f"an octave {way}"
    return f"{n} semitone{'' if n == 1 else 's'} {way}"


def _right_pitch_near(project: Project, row: int, sid: str, pitch: int) -> str:
    """What to say when score note sid's own pitch is played just before or
    after the note at row, or with it, by a note that can be sid's: one
    without a link, or linked to sid as well. A note that plays another score
    note, such as the next of a repeated note, or a note of an ornament, isn't
    one. "" if there's none."""
    perf, al = project.performance, project.alignment
    t = perf.onset[row]
    in_ornaments = {i for o in project.ornaments for i in o.performance}
    near = np.flatnonzero((np.abs(perf.onset - t) <= NEXT) & (perf.pitch == pitch))
    for r in sorted(near.tolist(), key=lambda r: abs(perf.onset[r] - t)):
        nid = str(perf.ids[r])
        partners = al.by_perf.get(nid, set())
        if r == row or nid in in_ornaments or (partners and sid not in partners):
            continue
        dt = perf.onset[r] - t
        when = "with it" if abs(dt) <= TOGETHER else "just before" if dt < 0 else "just after"
        if partners:
            return (f" But {nid}, played {when}, is linked to it at its own pitch: remove this "
                    "note's link, it's an insertion.")
        return (f" But {pitch_name(pitch)} is played {when} ({nid}): link that note, and this "
                "one is an insertion.")
    return ""


def _also_off(project: Project, row: int, off: int) -> Optional[bool]:
    """Whether most of the linked notes around the one at row in the same
    hand's line, those played within LINE semitones of it, are played off
    their score notes by off semitones as well; None if there are none."""
    perf, score, al = project.performance, project.score, project.alignment
    pitch = int(perf.pitch[row])
    found = []
    for step in (-1, 1):
        r, n = row + step, 0
        while 0 <= r < len(perf) and n < AROUND and abs(r - row) <= 40:
            partners = al.by_perf.get(perf.ids[r], set())
            if partners and abs(int(perf.pitch[r]) - pitch) <= LINE:
                found.append(any(int(perf.pitch[r]) - int(score.pitch[score.row[s]]) == off
                                 for s in partners if s in score.row))
                n += 1
            r += step
    return None if not found else sum(found) * 2 >= len(found)
