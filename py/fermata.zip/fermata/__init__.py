"""FERMATA: Friendly Editor for Repetitions, Mistakes, Annotations, Trills and Alignment.

A desktop editor for checking and correcting note alignments between a score
and a performance.
"""
__version__ = "0.1.27"

APP_NAME = "FERMATA"
FULL_NAME = "Friendly Editor for Repetitions, Mistakes, Annotations, Trills and Alignment"
