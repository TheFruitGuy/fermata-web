"""Passages played more than once: the passes of a colour-marked section,
which of them is aligned, and finding passages played again. No Qt imports.

A section (model.Section; annotations.py marks one by hand) is marked on the
performance only, and each of its passes is a stretch of the performance.
When a passage is played twice, the links go to one pass, the aligned pass,
and the notes of the other pass have none. Which pass is aligned isn't
stored: it's the pass with the most links, so it follows every edit,
realignment and undo. Nor are the bars of the score that the section plays,
its score side: they're where the aligned pass's links go (score_rows).

In a .match file, each pass is a section line (match_sections), and runs of
at least OMITTED_BEATS beats of score notes nobody played become omittedSection
lines (omitted_sections).

Finding passes
--------------
find() looks for runs of performance notes without links, such as a passage
played again after a slip, and compares each run with the score around the
links near it. The comparison is a local alignment of the chords' pitches, so
a few wrong, extra or missing notes don't matter. A run that plays a stretch
of the score becomes another pass: of the section that covers that stretch,
or of a new section.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np

from .annotations import SECTION_COLOURS, linked_span
from .model import NoteTrack, Project, Section, longest_rising

MIN_RUN = 12            # notes: shorter runs without links aren't taken for another pass
MAX_LINKED_IN_RUN = 2   # a run may contain this many linked notes in a row (stray links)
CHORD_GAP = 0.05        # seconds: notes this close to the previous one belong to its chord
MIN_MATCH = 0.5         # alignment score per performance chord that a pass needs
SEARCH_WINDOW = 30.0    # seconds around a run in which the links say where in the score to look
SEARCH_MARGIN = 4.0     # beats added on both sides of that part of the score
STRAY_GAP = 2 * SEARCH_MARGIN   # beats of notes: a section's links further apart than this aren't one passage
GAP = 0.5               # local alignment: the cost of skipping a chord in either roll
NEAR_BONUS = 0.2        # local alignment: extra score for score chords played just before or after
SAME_SECTION = 0.5      # beat spans that overlap this much (intersection over union) are one section
SAME_PASS = 0.5         # passes that overlap by this share of the shorter one are the same pass
AUTO_COLOURS = [c for name, c in SECTION_COLOURS.items() if name != "Grey"]   # grey is for other passes' notes
OMITTED_BEATS = 4.0     # beats of score notes in a row without links that make an omitted section


def _plural(n: int, word: str, plural: str = "") -> str:
    return f"{n} {word if n == 1 else plural or word + 's'}"


def pass_name(k: int) -> str:
    return f"pass {k + 1}"


# --------------------------------------------------------------------------- notes of sections and passes

def score_rows(project: Project, section: Section) -> np.ndarray:
    """Rows of the score notes the section plays: from the first to the last
    score note that its aligned pass's links go to, with the notes between
    them that aren't linked. Stray links are left out: the links kept are the
    pass's longest run that goes forward in the score, and of those the
    largest group without a gap of more than STRAY_GAP beats in which score
    notes sound: a rest in the score, while the orchestra plays on its own say,
    doesn't split a passage. None are there when no pass has links."""
    k = aligned_pass(project, section)
    if k is None:
        return np.zeros(0, int)
    return pass_score_rows(project, section.passes[k])


def pass_score_rows(project: Project, span) -> np.ndarray:
    """Rows of the score notes one pass plays, worked out as score_rows does."""
    perf, score, by_perf = project.performance, project.score, project.alignment.by_perf
    beats = [float(score.onset[score.row[s]]) for p in perf.ids[pass_rows(project, span)]
             for s in sorted(by_perf.get(p, ()), key=score.row.get)]
    run = [beats[i] for i in longest_rising(beats)]
    if not run:
        return np.zeros(0, int)
    gaps = [i for i in np.flatnonzero(np.diff(run) > STRAY_GAP).tolist()
            if _sounding(score, run[i], run[i + 1]) > STRAY_GAP]
    groups = np.split(np.array(run), np.array(gaps, int) + 1)
    kept = max(groups, key=len)
    return np.arange(np.searchsorted(score.onset, kept[0], "left"),
                     np.searchsorted(score.onset, kept[-1], "right"))


def _sounding(score, t0: float, t1: float) -> float:
    """How many of the beats from t0 to t1 have a score note sounding."""
    rows = score.rows_in(t0, t1)
    total, end = 0.0, t0
    for start, stop in zip(score.onset[rows].tolist(), score.offset[rows].tolist()):
        start, stop = max(start, end), min(stop, t1)
        if stop > start:
            total += stop - start
            end = stop
    return total


def score_beats(project: Project, section: Section):
    """The stretch of the score the section plays, from the first onset to the
    last offset of score_rows, in beats, or None."""
    rows = score_rows(project, section)
    if not len(rows):
        return None
    score = project.score
    return (float(score.onset[rows].min()), float(score.offset[rows].max()))


def pass_rows(project: Project, span) -> np.ndarray:
    """Rows of a pass's performance notes: those with an onset in its span."""
    onset = project.performance.onset
    return np.arange(np.searchsorted(onset, span[0], "left"),
                     np.searchsorted(onset, span[1], "right"))


def aligned_pass(project: Project, section: Section) -> Optional[int]:
    """The index of the pass that the links go to, the one with the most
    linked notes, or None if no pass has any."""
    passes = section.passes
    if not passes:
        return None
    perf, by_perf = project.performance, project.alignment.by_perf
    counts = [sum(1 for p in perf.ids[pass_rows(project, span)] if by_perf.get(p))
              for span in passes]
    best = int(np.argmax(counts))
    return best if counts[best] else None


def other_pass_mask(project: Project, linked: Optional[np.ndarray] = None) -> np.ndarray:
    """Per performance row: is this a note without a link in a pass that isn't
    the aligned one? Those notes play a passage again; they aren't extra notes.
    In a section with no aligned pass, no note counts, so its notes still show
    up as notes to align."""
    mask = np.zeros(len(project.performance), bool)
    if linked is None:
        linked = project.aligned_mask("perf")
    for section in project.sections:
        aligned = aligned_pass(project, section)
        if aligned is None:
            continue
        for k, span in enumerate(section.passes):
            if k != aligned:
                rows = pass_rows(project, span)
                mask[rows[~linked[rows]]] = True
    return mask


# --------------------------------------------------------------------------- passes and sections that find() makes

def _same_pass(a, b) -> bool:
    """Do two stretches of the performance mostly overlap? Passes next to each
    other may share a few milliseconds, where a held note runs into the next."""
    inter = min(a[1], b[1]) - max(a[0], b[0])
    return inter > SAME_PASS * max(min(a[1] - a[0], b[1] - b[0]), 1e-9)


def next_name(sections) -> str:
    """The first "Section n" that's free, counting on from the sections there are."""
    used = {s.name for s in sections}
    n = len(sections) + 1
    while f"Section {n}" in used:
        n += 1
    return f"Section {n}"


def next_colour(sections) -> str:
    """The first section colour that no section has, or else the least used one."""
    counts = {c: 0 for c in AUTO_COLOURS}
    for s in sections:
        if s.colour in counts:
            counts[s.colour] += 1
    return min(AUTO_COLOURS, key=lambda c: (counts[c], AUTO_COLOURS.index(c)))


# --------------------------------------------------------------------------- finding passes

@dataclass(frozen=True)
class Found:
    sections: tuple          # every section, with what was found added
    new_sections: int
    new_passes: int

    @property
    def summary(self) -> str:
        if not self.new_passes:
            return "No passages played again were found."
        text = f"Found {_plural(self.new_passes, 'pass', 'passes')} of passages played again"
        if self.new_sections:
            text += f", in {_plural(self.new_sections, 'new section')}"
        return text + "."


def _runs(free: np.ndarray, min_notes: int = MIN_RUN,
          bridge: int = MAX_LINKED_IN_RUN) -> list[np.ndarray]:
    """Runs of rows where free is True, bridging up to bridge rows in a row
    where it isn't. Runs with fewer than min_notes free rows are left out."""
    runs, start, last = [], None, None
    for row, ok in enumerate(free.tolist()):
        if ok:
            start = row if start is None else start
            last = row
        elif start is not None and row - last > bridge:
            runs.append((start, last))
            start = None
    if start is not None:
        runs.append((start, last))
    return [np.arange(a, b + 1) for a, b in runs if free[a:b + 1].sum() >= min_notes]


def _perf_chords(track: NoteTrack, rows: np.ndarray) -> list[np.ndarray]:
    """rows grouped into chords: a note within CHORD_GAP of the one before it
    joins that note's chord, so a slightly spread chord stays one chord."""
    if not len(rows):
        return []
    starts = np.flatnonzero(np.diff(track.onset[rows]) > CHORD_GAP) + 1
    return np.split(rows, starts)


def _score_chords(track: NoteTrack, lo: int, hi: int) -> list[np.ndarray]:
    """Score rows lo to hi grouped by onset."""
    rows = np.arange(lo, hi)
    if not len(rows):
        return []
    _, first = np.unique(track.onset[rows], return_index=True)
    return np.split(rows, first[1:])


def _pitches(track: NoteTrack, chords) -> np.ndarray:
    out = np.zeros((len(chords), 128), np.float32)
    for k, rows in enumerate(chords):
        out[k, track.pitch[rows]] = 1.0
    return out


def _similarity(perf_pitches: np.ndarray, score_pitches: np.ndarray) -> np.ndarray:
    """-1 to 1 for every pair of chords: 1 for the same pitches, -1 for none
    in common (from the Dice coefficient)."""
    common = perf_pitches @ score_pitches.T
    sizes = perf_pitches.sum(1)[:, None] + score_pitches.sum(1)[None, :]
    return 4.0 * common / np.maximum(sizes, 1.0) - 1.0


def _local_alignment(sim: np.ndarray, gap: float = GAP):
    """Smith-Waterman on a chord similarity matrix, rows the performance and
    columns the score, with a linear cost for skipping a chord in either.

    A performance chord may also match the score chord the one before it
    matched, which is what a chord played a little spread out looks like.
    Returns (score, (first, last) performance chord, (first, last) score
    chord), or (0, None, None) if nothing matches. Each row is computed with
    numpy in one go: skipping score chords is a running maximum.
    """
    n, m = sim.shape
    ramp = gap * np.arange(m + 1)
    prev = np.zeros(m + 1)
    moves = np.zeros((n, m + 1), np.int8)   # 0 start, 1 next score chord, 2 same score chord or skip, 3 skip score chord
    best, end = 0.0, None
    for i in range(n):
        diag = prev[:-1] + sim[i]
        up = prev[1:] + np.maximum(sim[i], -gap)
        d = np.zeros(m + 1)
        d[1:] = np.maximum(np.maximum(diag, up), 0.0)
        move = np.zeros(m + 1, np.int8)
        move[1:] = np.where(d[1:] > 0.0, np.where(diag >= up, 1, 2), 0)
        h = np.maximum.accumulate(d + ramp) - ramp
        move[h > d] = 3
        moves[i] = move
        j = int(np.argmax(h))
        if h[j] > best:
            best, end = float(h[j]), (i, j)
        prev = h
    if end is None:
        return 0.0, None, None
    i, j = end
    last_i, last_j = i, j - 1
    first_i, first_j = i, j - 1
    while i >= 0 and j > 0 and moves[i, j]:
        move = moves[i, j]
        if move == 1:
            first_i, first_j = i, j - 1
            i, j = i - 1, j - 1
        elif move == 2:
            first_i = i
            i -= 1
        else:
            j -= 1
    return best, (first_i, last_i), (first_j, last_j)


def _search_rows(project: Project, rows: np.ndarray) -> tuple[int, int]:
    """The score rows to compare a run with: around the score notes that the
    linked performance notes near the run are linked to, or the whole score."""
    perf, score, by_perf = project.performance, project.score, project.alignment.by_perf
    t0, t1 = float(perf.onset[rows[0]]), float(perf.onset[rows[-1]])
    window = max(SEARCH_WINDOW, 2.0 * (t1 - t0))
    lo = np.searchsorted(perf.onset, t0 - window, "left")
    hi = np.searchsorted(perf.onset, t1 + window, "right")
    beats = [score.onset[score.row[s]] for p in perf.ids[lo:hi] for s in by_perf.get(p, ())]
    if not beats:
        return 0, len(score)
    return (int(np.searchsorted(score.onset, min(beats) - SEARCH_MARGIN, "left")),
            int(np.searchsorted(score.onset, max(beats) + SEARCH_MARGIN, "right")))


def _near_chords(project: Project, rows: np.ndarray, s_chords) -> np.ndarray:
    """Per score chord: is it linked to notes played just before or after the
    run, within the run's own length? Music often repeats, and a passage
    played again is most likely the one next to it, so those chords get a
    small bonus when the run is compared with the score."""
    perf, score, by_perf = project.performance, project.score, project.alignment.by_perf
    t0, t1 = float(perf.onset[rows[0]]), float(perf.onset[rows[-1]])
    length = max(t1 - t0, 1.0)
    near = np.zeros(len(score), bool)
    for a, b in ((t0 - length, t0), (t1, t1 + length)):
        lo, hi = np.searchsorted(perf.onset, a, "left"), np.searchsorted(perf.onset, b, "right")
        near[[score.row[s] for p in perf.ids[lo:hi] for s in by_perf.get(p, ())]] = True
    return np.array([near[c].any() for c in s_chords])


def _section_end(project: Project, last_onset: float) -> float:
    """Where a passage whose last chord starts at last_onset ends: at the next
    onset in the score, or at the end of the score."""
    score = project.score
    i = np.searchsorted(score.onset, last_onset, "right")
    if i < len(score):
        return float(score.onset[i])
    return float(score.end) if score.end > last_onset else float(last_onset) + 1.0


def _match_run(project: Project, rows: np.ndarray):
    """Where in the score a run of performance notes is played.

    Returns ((first, last) beat of the passage, (first onset, last offset) of
    the pass in seconds, rows before the pass, rows after it), or None if the
    run doesn't play the score around it.
    """
    perf, score = project.performance, project.score
    lo, hi = _search_rows(project, rows)
    p_chords, s_chords = _perf_chords(perf, rows), _score_chords(score, lo, hi)
    if not s_chords:
        return None
    sim = _similarity(_pitches(perf, p_chords), _pitches(score, s_chords))
    _, (i0, i1), (j0, j1) = _local_alignment(sim + NEAR_BONUS * _near_chords(project, rows, s_chords))
    if i0 is None:
        return None
    # How well it matches, without the bonus.
    total, _, _ = _local_alignment(sim[i0:i1 + 1, j0:j1 + 1])
    played = np.concatenate(p_chords[i0:i1 + 1])
    if total / (i1 - i0 + 1) < MIN_MATCH or len(played) < MIN_RUN:
        return None
    beats = (float(score.onset[s_chords[j0][0]]),
             _section_end(project, float(score.onset[s_chords[j1][0]])))
    span = (float(perf.onset[played].min()), float(perf.offset[played].max()))
    return beats, span, rows[rows < played[0]], rows[rows > played[-1]]


def _overlap(a, b) -> float:
    """Intersection over union of two spans."""
    inter = max(0.0, min(a[1], b[1]) - max(a[0], b[0]))
    union = max(a[1], b[1]) - min(a[0], b[0])
    return inter / union if union > 0 else 0.0


def find(project: Project) -> Found:
    """Find passes that play a passage again: runs of performance notes
    without links, outside every pass, that play the score near them.

    Each pass found joins the section whose passage it plays, or starts a new
    section, which also gets the pass its links go to. Only reads the project.
    """
    free = ~project.aligned_mask("perf")
    for section in project.sections:
        for span in section.passes:
            free[pass_rows(project, span)] = False
    found = []
    todo = _runs(free)
    while todo:
        rows = todo.pop()
        match = _match_run(project, rows)
        if match is None:
            continue
        beats, span, before, after = match
        found.append((beats, span))
        todo += [part for part in (before, after) if free[part].sum() >= MIN_RUN]

    sections = list(project.sections)
    tm = project.time_map()
    new_sections = new_passes = 0
    for beats, span in sorted(found, key=lambda f: f[1]):
        spans = [score_beats(project, s) for s in sections]
        scores = [_overlap(beats, span) if span else 0.0 for span in spans]
        k = int(np.argmax(scores)) if scores else -1
        if k >= 0 and scores[k] >= SAME_SECTION:
            section = sections[k]
            if any(_same_pass(span, p) for p in section.passes):
                continue
            sections[k] = section.with_passes(section.passes + (span,))
        else:
            passes = [span]
            linked = linked_span(project, beats, tm)
            if linked and not _same_pass(linked, span):
                passes.append(linked)
            sections.append(Section(next_name(sections), next_colour(sections))
                            .with_passes(passes))
            new_sections += 1
        new_passes += 1
    return Found(tuple(sections), new_sections, new_passes)


# --------------------------------------------------------------------------- .match files

def section_ids(project: Project) -> list[list[str]]:
    """The ids of each section's passes in an exported .match file: "s1",
    "s2", ... in the order the passes are played, without gaps, so deleting a
    section closes the gap and a new one takes its place in the order. The
    dataset's files are numbered this way, so theirs come back unchanged."""
    order = sorted((span[0], span[1], i, k) for i, section in enumerate(project.sections)
                   for k, span in enumerate(section.passes))
    ids = [[""] * len(section.passes) for section in project.sections]
    for n, (_start, _end, i, k) in enumerate(order, 1):
        ids[i][k] = f"s{n}"
    return ids


def match_sections(project: Project, mpq: int, ppq: int) -> list[dict]:
    """The sections as save_match takes them: a section line for each pass,
    with the keys of a .match file's section(...) line. The score beats are the
    pass's linked score notes, from the first onset to the last offset. A
    section read from a .match file and not changed since is written back as
    its line was (Section.match). A pass without
    links plays the same bars as the section's aligned pass, so it gets those;
    a section without any links gets them from the links around it (the time
    map). FERMATA's score is as written, so the beats are the same unfolded and
    original. The later passes of a section played more than once get
    "rehearsal_repetition". The lines are in the order they're played, with
    the ids section_ids gives."""
    ids = section_ids(project)
    score = project.score
    tmap = project.time_map() if project.alignment.links else None
    ticks = ppq * 1e6 / mpq   # per second
    out = []
    by_perf, perf = project.alignment.by_perf, project.performance
    for i, section in enumerate(project.sections):
        bars = score_beats(project, section)
        for k, span in enumerate(section.passes):
            start_tick, end_tick = int(round(span[0] * ticks)), int(round(span[1] * ticks))
            if k == 0 and len(section.match) == 6 and \
                    abs(start_tick - section.match[4]) <= 1 and abs(end_tick - section.match[5]) <= 1:
                # As read from the file: the section hasn't been changed.
                values = section.match
                out.append({"id": ids[i][k],
                            "start_in_beats_unfolded": float(values[0]),
                            "end_in_beats_unfolded": float(values[1]),
                            "start_in_beats_original": float(values[2]),
                            "end_in_beats_original": float(values[3]),
                            "start_in_perf_time": int(values[4]),
                            "end_in_perf_time": int(values[5]),
                            "section_attr_list": list(section.attributes)})
                continue
            linked = [score.row[s] for p in perf.ids[pass_rows(project, span)]
                      for s in by_perf.get(p, ()) if s in score.row]
            if linked:
                beats = (float(score.onset[linked].min()), float(score.offset[linked].max()))
            elif bars is not None:
                beats = bars
            elif tmap is not None:
                beats = (float(tmap.to_score(span[0])), float(tmap.to_score(span[1])))
            else:
                beats = (0.0, 0.0)
            attrs = list(section.attributes)
            if k and "rehearsal_repetition" not in attrs:
                attrs.append("rehearsal_repetition")
            out.append({"id": ids[i][k],
                        "start_in_beats_unfolded": beats[0], "end_in_beats_unfolded": beats[1],
                        "start_in_beats_original": beats[0], "end_in_beats_original": beats[1],
                        "start_in_perf_time": start_tick,
                        "end_in_perf_time": end_tick,
                        "section_attr_list": attrs})
    return sorted(out, key=lambda line: int(line["id"][1:]))


def omitted_sections(project: Project, min_beats: float = OMITTED_BEATS) -> list[dict]:
    """Stretches of the score that weren't played, as save_match takes them for
    omittedSection(...) lines, with the attribute "not_performed": at least
    min_beats beats of score notes in a row, each chord without a single link.

    They're worked out anew from the links at every export, so the stretches
    a .match file had as several omitted sections and deletion lines become
    one when none of it is linked. A file's own omitted section is written back
    as it was while none of its notes has been linked since it was opened, also
    if it's shorter than min_beats: links the file had inside it (the Rach3
    files have some) don't count. A stretch that starts or ends where one of
    the file's does keeps that end's beat in the original (folded) score.
    They're numbered "os1", "os2", ... in score order, without gaps."""
    score, by_score = project.score, project.alignment.by_score
    kept = [dict(o) for o in project.match_header.get("omitted_sections", ())]
    before = set(project.match_header.get("linked_in_omitted", ()))
    onsets, first = np.unique(score.onset, return_index=True) if len(score) else ([], [])
    bounds = list(first) + [len(score)]
    played = [any(by_score.get(score.ids[r]) and str(score.ids[r]) not in before
                  for r in range(bounds[i], bounds[i + 1])) for i in range(len(onsets))]
    result, i = [], 0
    while i < len(onsets):
        if played[i]:
            i += 1
            continue
        j = i
        while j + 1 < len(onsets) and not played[j + 1]:
            j += 1
        start = float(onsets[i])
        end = float(score.offset[bounds[i]:bounds[j + 1]].max())
        # The file's sections reach as far as the chords played around the stretch.
        lo = float(onsets[i - 1]) if i else -np.inf
        hi = float(onsets[j + 1]) if j + 1 < len(onsets) else np.inf
        end = min(end, hi)   # not into the next chord, which was played
        for o in kept:
            a, b = o["start_in_beats_unfolded"], o["end_in_beats_unfolded"]
            if a < end and b > start:   # overlaps the stretch
                if lo - 5e-4 <= a < start:
                    start = a
                if end < b <= hi + 5e-4:
                    end = b
        same = next((o for o in kept if abs(o["start_in_beats_unfolded"] - start) < 5e-4
                     and abs(o["end_in_beats_unfolded"] - end) < 5e-4), None)
        if same is not None:
            result.append(same)
        elif end - start >= min_beats:
            result.append(_omitted_between(start, end, kept))
        i = j + 1
    result.sort(key=lambda o: o["start_in_beats_unfolded"])
    for n, o in enumerate(result, 1):
        o["id"] = f"os{n}"   # copies of the file's, so its own stay as they were
    return result


def _omitted_between(start: float, end: float, kept) -> dict:
    """An omitted section from start to end in beats, whose ends are in the
    original (folded) score where one of the file's sections, kept, has the
    same end, and the same as the unfolded beats otherwise."""
    out = _omitted(start, end)
    for o in kept:
        for side in ("start", "end"):
            if abs(o[f"{side}_in_beats_unfolded"] - (start if side == "start" else end)) < 5e-4:
                out[f"{side}_in_beats_original"] = o[f"{side}_in_beats_original"]
    return out


def inside_omitted(project: Project, sid: str) -> bool:
    """Whether score note sid lies inside one of the omitted sections of the
    .match file the project was opened from (strictly inside, as for lines)."""
    beat = float(project.score.onset[project.score.row[sid]])
    return any(o["start_in_beats_unfolded"] + 5e-4 < beat < o["end_in_beats_unfolded"] - 5e-4
               for o in project.match_header.get("omitted_sections", ()))


def _omitted(start: float, end: float, shift: float = 0.0, attrs=("not_performed",), sid: str = "") -> dict:
    """An omitted section from start to end in beats; shift is how far the
    original (folded) score's beats are from these."""
    return {"id": sid, "start_in_beats_unfolded": start, "end_in_beats_unfolded": end,
            "start_in_beats_original": start + shift, "end_in_beats_original": end + shift,
            "section_attr_list": list(attrs)}
