"""The piano FERMATA plays with: a SoundFont 2 file, read with numpy. No Qt imports.

FERMATA comes with the Salamander C5 Light soundfont by Ziya Mete Demircan (HED
Sounds), made from Alexander Holm's Salamander Grand Piano (see Credits in the
README). This module reads what playing it takes: for a key and a velocity, the
recordings to play, each stereo pair mixed to mono, with their tuning, loudness,
low-pass filter and volume envelope. playback.py plays them.

Only what this soundfont uses is read: its first preset, zones with key and
velocity ranges, and the generators for tuning, attenuation, the filter's cutoff
and the volume envelope. Modulators aren't read, since the file has only the
default ones every SoundFont player has, and playback.py applies the one that
matters here, velocity to loudness. Loops aren't played: its zones don't loop.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass
from pathlib import Path

import numpy as np

PATH = Path(__file__).parent / "resources" / "SalC5Light2.sf2"

# Generators (SoundFont 2.04, 8.1.2), and their defaults.
_CUTOFF, _PAN, _ATTACK, _HOLD, _DECAY, _SUSTAIN, _RELEASE = 8, 17, 34, 35, 36, 37, 38
_INSTRUMENT, _KEYS, _VELOCITIES, _ATTENUATION = 41, 43, 44, 48
_COARSE, _FINE, _SAMPLE, _ROOT = 51, 52, 53, 58
_RANGES = (_KEYS, _VELOCITIES)
_DEFAULTS = {_CUTOFF: 13500, _ATTACK: -12000, _HOLD: -12000, _DECAY: -12000, _SUSTAIN: 0,
             _RELEASE: -12000, _ATTENUATION: 0, _COARSE: 0, _FINE: 0, _ROOT: -1}
_MONO, _RIGHT, _LEFT = 1, 2, 4


@dataclass(frozen=True)
class Region:
    """What a zone plays: a recording, for the keys and velocities in its ranges."""
    keys: tuple[int, int]
    velocities: tuple[int, int]
    wave: int           # which of SoundFont.waves
    root: int           # the key the recording sounds, played as recorded
    tune: float         # cents
    attenuation: float  # centibels
    cutoff: float       # Hz; at or above SoundFont.rate * 0.45, no filter
    attack: float       # seconds
    hold: float         # seconds at full level after the attack
    decay: float        # seconds to fall by 96 dB while the key is down...
    sustain: float      # ...down to this many decibels below full
    release: float      # seconds to fall by 96 dB once the key is up


class SoundFont:
    """A SoundFont 2 file's first preset, ready to play: its regions, and its
    recordings as 16-bit mono waves at their own sample rate."""

    def __init__(self, path=PATH):
        data = Path(path).read_bytes()
        if data[:4] != b"RIFF" or data[8:12] != b"sfbk":
            raise ValueError(f"{Path(path).name} isn't a SoundFont 2 file.")
        lists = {data[at:at + 4]: (at + 4, at + size)
                 for kind, at, size in _chunks(data, 12, len(data)) if kind == b"LIST"}
        sdta = {kind: (at, size) for kind, at, size in _chunks(data, *lists[b"sdta"])}
        at, size = sdta[b"smpl"]
        pcm = np.frombuffer(data, dtype="<i2", count=size // 2, offset=at)
        pdta = {kind: data[at:at + size] for kind, at, size in _chunks(data, *lists[b"pdta"])}
        presets = _records(pdta[b"phdr"], "<20sHHHIII")
        pbag, pgen = _records(pdta[b"pbag"], "<HH"), _records(pdta[b"pgen"], "<HH")
        inst = _records(pdta[b"inst"], "<20sH")
        ibag, igen = _records(pdta[b"ibag"], "<HH"), _records(pdta[b"igen"], "<HH")
        self._samples = _records(pdta[b"shdr"], "<20sIIIIIBbHH")
        self._pcm = pcm
        self.rate = int(self._samples[0][5])
        self.waves: list[np.ndarray] = []
        self._wave_of: dict[tuple, int] = {}
        regions = []
        for preset_zone in _zones(pbag, pgen, presets[0][3], presets[1][3], _INSTRUMENT):
            pz = preset_zone
            for zone in _zones(ibag, igen, inst[pz[_INSTRUMENT]][1], inst[pz[_INSTRUMENT] + 1][1], _SAMPLE):
                region = self._region(pz, zone)
                if region is not None:
                    regions.append(region)
        self.regions = regions
        del self._pcm   # the waves are copies: let the file's bytes go
        self._found: dict[tuple[int, int], tuple[Region, ...]] = {}
        self._filtered: dict[tuple[int, float], np.ndarray] = {}

    def regions_for(self, key: int, velocity: int) -> tuple[Region, ...]:
        """The regions a key played at velocity sounds."""
        found = self._found.get((key, velocity))
        if found is None:
            found = tuple(r for r in self.regions if r.keys[0] <= key <= r.keys[1]
                          and r.velocities[0] <= velocity <= r.velocities[1])
            self._found[(key, velocity)] = found
        return found

    def wave(self, region: Region) -> np.ndarray:
        """region's recording through its low-pass filter, a 16-bit mono wave.
        Filtered once, the first time it's played: the filter is fixed for each
        velocity layer, so filtering the recording and then changing its pitch
        is close to the other way round."""
        key = (region.wave, region.cutoff)
        wave = self._filtered.get(key)
        if wave is None:
            wave = self.waves[region.wave]
            if region.cutoff < 0.45 * self.rate:
                from scipy.signal import butter, sosfilt
                sos = butter(2, region.cutoff, fs=self.rate, output="sos")
                wave = np.clip(np.round(sosfilt(sos, wave.astype(np.float32))),
                               -32768, 32767).astype(np.int16)
            self._filtered[key] = wave
        return wave

    def _region(self, preset_zone: dict, zone: dict):
        """The region of an instrument zone in a preset zone, or None if it
        plays nothing, as the right half of a stereo pair does: the left half
        plays both, mixed."""
        sample = self._samples[zone[_SAMPLE]]
        kind, link = sample[9], sample[8]
        if kind == _RIGHT and self._samples[link][9] == _LEFT:
            return None
        pair = (zone[_SAMPLE], link) if kind == _LEFT else (zone[_SAMPLE],)
        if pair not in self._wave_of:
            halves = [self._pcm[self._samples[i][1]:self._samples[i][2]] for i in pair]
            n = min(len(h) for h in halves)
            mixed = sum(h[:n].astype(np.int32) for h in halves) // len(halves)
            self._wave_of[pair] = len(self.waves)
            self.waves.append(mixed.astype(np.int16))
        gens = {**_DEFAULTS, **zone}
        for op, amount in preset_zone.items():   # a preset adds to its instruments' values
            if op not in _RANGES and op not in (_INSTRUMENT, _SAMPLE) and op in gens:
                gens[op] += amount
        keys = _overlap(preset_zone.get(_KEYS, (0, 127)), gens.get(_KEYS, (0, 127)))
        velocities = _overlap(preset_zone.get(_VELOCITIES, (0, 127)), gens.get(_VELOCITIES, (0, 127)))
        if keys is None or velocities is None:
            return None
        root = gens[_ROOT] if gens[_ROOT] >= 0 else sample[6]
        return Region(keys, velocities, self._wave_of[pair], int(root),
                      tune=gens[_COARSE] * 100.0 + gens[_FINE] + sample[7],
                      attenuation=float(gens[_ATTENUATION]),
                      cutoff=8.176 * 2.0 ** (gens[_CUTOFF] / 1200.0),
                      attack=_seconds(gens[_ATTACK]), hold=_seconds(gens[_HOLD]),
                      decay=_seconds(gens[_DECAY]), sustain=gens[_SUSTAIN] / 10.0,
                      release=_seconds(gens[_RELEASE]))


def _seconds(timecents: float) -> float:
    return 2.0 ** (timecents / 1200.0)


def _overlap(a, b):
    lo, hi = max(a[0], b[0]), min(a[1], b[1])
    return (lo, hi) if lo <= hi else None


def _chunks(data: bytes, start: int, end: int):
    """The RIFF chunks from start to end: (kind, where its data starts, its size)."""
    at = start
    while at + 8 <= end:
        kind, size = data[at:at + 4], struct.unpack_from("<I", data, at + 4)[0]
        yield kind, at + 8, size
        at += 8 + size + (size & 1)


def _records(data: bytes, fmt: str) -> list[tuple]:
    size = struct.calcsize(fmt)
    return [struct.unpack_from(fmt, data, at) for at in range(0, len(data) - size + 1, size)]


def _zones(bags, gens, first: int, last: int, target: int) -> list[dict]:
    """The zones of a preset (target _INSTRUMENT) or an instrument (target
    _SAMPLE), bags first to last, as {generator: amount}, each with the
    global zone's generators under its own. Ranges are (low, high); other
    amounts are signed, but for the target, an index."""
    zones, shared = [], {}
    for bag in range(first, last):
        zone = {}
        for op, raw in gens[bags[bag][0]:bags[bag + 1][0]]:
            if op in _RANGES:
                zone[op] = (raw & 0xFF, raw >> 8)
            elif op == target:
                zone[op] = raw
            else:
                zone[op] = struct.unpack("<h", struct.pack("<H", raw))[0]
        if target not in zone:
            if bag == first:
                shared = zone   # the global zone
            continue
        zones.append({**shared, **zone})
    return zones
