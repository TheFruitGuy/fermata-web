"""Qt-free core of FERMATA: notes, many-to-many links, ornaments, loading and saving.

Nothing in this module imports Qt. That keeps it easy to test with pytest and
reusable unchanged if the interface ever moves to another toolkit.

Conventions
-----------
* A link is a ``(score_id, performance_id)`` pair, and links are many-to-many.
* Insertions (performance notes without a link) and deletions (score notes
  without a link) are derived from the links, never stored.
* Performance time is in seconds, score time in beats.

Files
-----
FERMATA never writes into the folder a project was opened from. Work in
progress goes to backups (see session.py), and the finished work goes to an
export folder. Both hold the five Parangonada CSV files: ``align.csv`` with
the current links, and the note lists, ``feature.csv`` and ``zalign.csv``
exactly as they were opened, so a second alignment in ``zalign.csv`` is
carried along unchanged. Ornament labels go in ``ornaments.json``, because
the Parangonada files have no place for them; ``align.csv`` stores ornament
links as plain matches. Anchors, the links that realigning keeps, go in
``anchors.json``, comments for a second reviewer in ``comments.json``, and
``project.json`` keeps the realign method, the source files and the
colour-marked sections between sessions, with every pass of a section that's
played more than once.

A new alignment isn't opened from one file but made from two: a MusicXML
score and a MIDI performance (read_score, read_performance and new_project;
realign.new_alignment aligns them). It can be exported as a .match file too, and
FERMATA doesn't write into the folder of either file.
"""
from __future__ import annotations

import bisect
import json
import os
import re
import tempfile
from collections import Counter, defaultdict
from contextlib import contextmanager
from dataclasses import dataclass, field, replace
from datetime import datetime
from pathlib import Path
from typing import Iterable, Optional

import numpy as np
import numpy.lib.recfunctions as rfn
import partitura as pt
import partitura.io.importmatch as _importmatch
import partitura.io.matchfile_base as _matchfile_base
from partitura.io.exportparangonada import alignment_dicts_to_array, save_parangonada_csv
from partitura.io.importparangonada import load_parangonada_alignment, load_parangonada_csv
from partitura.io.matchfile_utils import format_pnote_id
from partitura.utils.music import (expand_grace_notes_from_local_grace_order,
                                   remove_double_notes_from_score_note_array)

from . import __version__

# partitura 1.9 works out a score's metrical positions, which expanding grace
# notes and Outer HMM need, with np.row_stack. Newer NumPy doesn't have it; it
# was another name for np.vstack.
if not hasattr(np, "row_stack"):
    np.row_stack = np.vstack

Link = tuple[str, str]  # (score_id, performance_id)

PARANGONADA_FILES = ("ppart.csv", "part.csv", "align.csv", "zalign.csv", "feature.csv")
KEPT_FILES = ("ppart.csv", "part.csv", "zalign.csv", "feature.csv")   # never edited by FERMATA
ORNAMENTS_FILE = "ornaments.json"
ORNAMENTS_FORMAT = 1
ANCHORS_FILE = "anchors.json"
ANCHORS_FORMAT = 1
COMMENTS_FILE = "comments.json"
COMMENTS_FORMAT = 1
PROJECT_FILE = "project.json"   # the method, the source files and the sections
PROJECT_FORMAT = 2              # format 1, written by exports before, only had "source"
SCORE_SUFFIXES = (".musicxml", ".xml", ".mxl")   # MusicXML, for a new alignment
PERFORMANCE_SUFFIXES = (".mid", ".midi")
CSV_CHARS = 20   # partitura writes Parangonada CSV values with "%.20s": longer ids are cut


def _plural(n: int, word: str) -> str:
    return f"{n} {word}{'' if n == 1 else 's'}"


def _count(n: int, word: str) -> str:
    """Like _plural, with thousands separated: "3,590 notes"."""
    return f"{n:,} {word}{'' if n == 1 else 's'}"


class NoteTrack:
    """The notes of one piano roll, sorted by onset, with fast range queries."""

    def __init__(self, ids, pitch, onset, duration):
        onset = np.asarray(onset, dtype=float)
        order = np.argsort(onset, kind="stable")
        self.ids = np.array([str(i) for i in np.asarray(ids)[order]], dtype=object)
        self.pitch = np.asarray(pitch, dtype=int)[order]
        self.onset = onset[order]
        self.duration = np.asarray(duration, dtype=float)[order]
        self.offset = self.onset + self.duration
        self.row = {nid: i for i, nid in enumerate(self.ids)}
        self.max_duration = float(self.duration.max()) if len(self.ids) else 0.0

    @classmethod
    def from_note_array(cls, note_array, onset_field: str, duration_field: str) -> "NoteTrack":
        return cls(note_array["id"], note_array["pitch"],
                   note_array[onset_field], note_array[duration_field])

    def __len__(self) -> int:
        return len(self.ids)

    @property
    def start(self) -> float:
        return float(self.onset[0]) if len(self) else 0.0

    @property
    def end(self) -> float:
        return float(self.offset.max()) if len(self) else 1.0

    @property
    def pitch_range(self) -> tuple[int, int]:
        return (int(self.pitch.min()), int(self.pitch.max())) if len(self) else (60, 72)

    def rows_in(self, t0: float, t1: float) -> np.ndarray:
        """Row indices of the notes that overlap the time range [t0, t1]."""
        lo = np.searchsorted(self.onset, t0 - self.max_duration, side="left")
        hi = np.searchsorted(self.onset, t1, side="right")
        rows = np.arange(lo, hi)
        return rows[self.offset[rows] >= t0]


class Alignment:
    """Many-to-many links between score notes and performance notes."""

    def __init__(self, links: Iterable[Link] = ()):
        self.links: set[Link] = set()
        self.by_score: dict[str, set[str]] = defaultdict(set)
        self.by_perf: dict[str, set[str]] = defaultdict(set)
        self.add(links)

    def add(self, links: Iterable[Link]) -> set[Link]:
        """Add links; returns the ones that weren't there before."""
        added = {link for link in links if link not in self.links}
        for sid, pid in added:
            self.links.add((sid, pid))
            self.by_score[sid].add(pid)
            self.by_perf[pid].add(sid)
        return added

    def remove(self, links: Iterable[Link]) -> set[Link]:
        """Remove links; returns the ones that were actually there."""
        removed = {link for link in links if link in self.links}
        for sid, pid in removed:
            self.links.discard((sid, pid))
            self.by_score[sid].discard(pid)
            self.by_perf[pid].discard(sid)
        return removed

    def links_of(self, score_ids: Iterable[str] = (), perf_ids: Iterable[str] = ()) -> set[Link]:
        """All links that touch any of the given notes."""
        out = {(s, p) for s in score_ids for p in self.by_score.get(s, ())}
        out |= {(s, p) for p in perf_ids for s in self.by_perf.get(p, ())}
        return out

    def replacing(self, links: Iterable[Link]) -> tuple[set[Link], set[Link]]:
        """What linking links instead of their performance notes' other links
        takes: (links to remove, links to add). Those performance notes lose
        their links to other score notes; the score notes keep theirs."""
        links = set(links)
        old = self.links_of((), {p for _, p in links}) - links
        return old, links - self.links

    def many_to_many_links(self, ignore: Iterable[Link] = ()) -> set[Link]:
        """Plain links on notes that have more than one plain partner.

        A .match file has one line per note, so partitura's save_match writes
        all but one partner of such a note as virtual lines, which FERMATA reads
        back and partitura's own load_match ignores. Ornament links are written
        as separate lines and aren't affected; pass them as ignore.
        """
        plain = self.links - set(ignore)
        per_score = Counter(s for s, _ in plain)
        per_perf = Counter(p for _, p in plain)
        return {(s, p) for s, p in plain if per_score[s] > 1 or per_perf[p] > 1}

    def to_partitura(self, score_ids: Iterable[str], perf_ids: Iterable[str],
                     ornament_types: Optional[dict[Link, str]] = None) -> list[dict]:
        """Partitura's list-of-dicts format, with insertions and deletions filled in.

        Links in ornament_types become "ornament" entries, which only the
        .match format can store; every other link is a plain match.
        """
        ornament_types = ornament_types or {}
        out = []
        for sid, pid in sorted(self.links):
            kind = ornament_types.get((sid, pid))
            entry = {"label": "match"} if kind is None else {"label": "ornament", "type": kind}
            entry.update(score_id=sid, performance_id=pid)
            out.append(entry)
        out += [{"label": "deletion", "score_id": s} for s in score_ids if not self.by_score.get(s)]
        out += [{"label": "insertion", "performance_id": p} for p in perf_ids if not self.by_perf.get(p)]
        return out


@dataclass
class Ornament:
    """A note grouping: an ornament such as a trill, a basso continuo
    realization, an improvisation or a grouping of the user's own, with the
    score notes it belongs to and the performance notes that play it.

    group is the kind of grouping (GROUPINGS); type is an ornament's type
    ("trill"), and for the others the name that goes into a .match file's
    attribute lists: "continuo_realization", "improvisation", or the user's
    own name, such as "special_grouping". Groupings are stored by note rather
    than by link, so they survive editing the links, and the same shape works
    for those marked by hand.
    """
    type: str
    score: list[str]
    performance: list[str]
    group: str = "ornament"

    def __post_init__(self):
        self.type = str(self.type)
        self.score = sorted({str(i) for i in self.score})
        self.performance = sorted({str(i) for i in self.performance})
        self.group = str(self.group or "ornament")

    @property
    def attribute(self) -> str:
        """Its name in a .match file's attribute lists."""
        return ornament_attribute(self.type) if self.group == "ornament" else self.type

    def to_json(self) -> dict:
        data = {"type": self.type, "score": self.score, "performance": self.performance}
        if self.group != "ornament":
            data["group"] = self.group
        return data

    @classmethod
    def from_json(cls, data: dict) -> "Ornament":
        return cls(data["type"], data.get("score", []), data.get("performance", []),
                   data.get("group", "ornament"))


# The kinds of note grouping (Annotations > Note grouping), and their names.
GROUPINGS = {"ornament": "Ornament", "continuo_realization": "Basso continuo realization",
             "improvisation": "Improvisation", "other": "Other grouping"}
# The attributes of the groupings that are read back from a .match file's
# lines; another grouping's name comes back from the file beside it.
GROUPING_KEYWORDS = ("continuo_realization", "improvisation")


def _ornament_type(value) -> str:
    """partitura reads old trill lines as "trill" and newer ornament lines as a list."""
    if isinstance(value, (list, tuple)):
        return "+".join(str(v) for v in value) or "generic_ornament"
    return str(value) if value else "generic_ornament"


def _ids(values) -> tuple:
    return tuple(sorted({str(i) for i in values}))


@dataclass(frozen=True)
class Reply:
    """An answer to a comment."""
    author: str
    time: str       # ISO 8601, to the second
    text: str

    def to_json(self) -> dict:
        return {"author": self.author, "time": self.time, "text": self.text}

    @classmethod
    def from_json(cls, data: dict) -> "Reply":
        return cls(str(data.get("author", "")), str(data.get("time", "")), str(data["text"]))


@dataclass(frozen=True)
class Comment:
    """A remark for a second reviewer about some performance notes. Comments
    are about the performance only: never about score notes.

    Frozen, like Reply and Section: an edit makes a new object with
    dataclasses.replace, so the undo stack can keep the old one.
    """
    text: str
    author: str = ""
    time: str = ""
    performance: tuple = ()     # performance note ids
    resolved: bool = False
    replies: tuple = ()         # Reply objects, oldest first

    def __post_init__(self):
        object.__setattr__(self, "performance", _ids(self.performance))
        object.__setattr__(self, "replies", tuple(self.replies))

    def to_json(self) -> dict:
        return {"performance": list(self.performance), "author": self.author,
                "time": self.time, "text": self.text, "resolved": self.resolved,
                "replies": [r.to_json() for r in self.replies]}

    @classmethod
    def from_json(cls, data: dict) -> "Comment":
        """A comment from comments.json. The "score" notes that comments had
        before are ignored: comments are about the performance only."""
        return cls(str(data["text"]), str(data.get("author", "")), str(data.get("time", "")),
                   data.get("performance", []), bool(data.get("resolved", False)),
                   [Reply.from_json(r) for r in data.get("replies", [])])


def _span(value) -> Optional[tuple]:
    if value is None:
        return None
    start, end = (float(v) for v in value)
    return (min(start, end), max(start, end))


@dataclass(frozen=True)
class Section:
    """A colour-marked stretch of the performance, in seconds. A section is
    marked on the performance; the score notes its notes are linked to are its
    score side, worked out from the links (repeats.score_beats), never stored.

    A passage played more than once, as in a rehearsal, has a pass for each
    time it's played. The performance span is the first pass and repeats has
    the others, in time order. Which pass is aligned isn't stored: it's the
    pass with the most links (see repeats.aligned_pass), so it follows every
    edit and undo, and so are the bars of the score it plays: where the
    aligned pass's links go (repeats.score_rows).
    """
    name: str
    colour: str                        # "#RRGGBB"
    performance: Optional[tuple] = None   # (first second, last second): the first pass
    repeats: tuple = ()                # the later passes, each (first second, last second)
    # The id its line had in the .match file it was read from ("s1"), and
    # the keywords of its SectionAttrList, such as "rehearsal_repetition".
    # Exporting numbers the lines anew, in the order they're played
    # (repeats.section_ids). The name is only for the interface: a .match file
    # has none.
    id: str = ""
    attributes: tuple = ()
    # The beats (start and end, unfolded and original) and MIDI ticks (start,
    # end) of the section line it was read from. Written back as they were as
    # long as the section's first pass still spans those ticks; moving an edge
    # works them out anew from the links.
    match: tuple = ()

    def __post_init__(self):
        passes = sorted(p for p in (_span(self.performance), *map(_span, self.repeats)) if p)
        object.__setattr__(self, "performance", passes[0] if passes else None)
        object.__setattr__(self, "repeats", tuple(passes[1:]))
        object.__setattr__(self, "id", str(self.id or ""))
        object.__setattr__(self, "attributes",
                           tuple(a for a in (str(a).strip() for a in self.attributes) if a))
        object.__setattr__(self, "match", tuple(self.match or ()))

    @property
    def passes(self) -> tuple:
        """Every stretch of the performance that plays the section, in time order."""
        return ((self.performance,) if self.performance else ()) + self.repeats

    def with_passes(self, passes) -> "Section":
        passes = sorted(passes)
        return replace(self, performance=passes[0] if passes else None, repeats=tuple(passes[1:]))

    def to_json(self) -> dict:
        data = {"name": self.name, "colour": self.colour,
                "performance": list(self.performance) if self.performance else None}
        if self.repeats:
            data["repeats"] = [list(p) for p in self.repeats]
        if self.id:
            data["id"] = self.id
        if self.attributes:
            data["attributes"] = list(self.attributes)
        if self.match:
            data["match"] = list(self.match)
        return data

    @classmethod
    def from_json(cls, data: dict) -> "Section":
        """A section from project.json. The "score" beats that FERMATA wrote
        before are ignored: the score side comes from the links."""
        return cls(str(data.get("name", "")), str(data["colour"]),
                   data.get("performance"), tuple(data.get("repeats") or ()),
                   str(data.get("id") or ""), tuple(data.get("attributes") or ()),
                   tuple(data.get("match") or ()))


def from_partitura(entries: list[dict]) -> tuple[Alignment, list[Ornament]]:
    """Split partitura's alignment entries into links and ornaments."""
    links, played = [], defaultdict(list)
    for entry in entries:
        sid, pid = entry.get("score_id"), entry.get("performance_id")
        if sid is None or pid is None:
            continue  # insertion or deletion: derived, not stored
        link = (str(sid), str(pid))
        links.append(link)
        if entry.get("label") == "ornament":
            played[(link[0], _ornament_type(entry.get("type")))].append(link[1])
    ornaments = [Ornament(kind, [sid], pids) for (sid, kind), pids in played.items()]
    return Alignment(links), ornaments


def longest_rising(values: list[float]) -> list[int]:
    """Indices of the longest strictly increasing subsequence of values."""
    tails: list[float] = []   # tails[k]: the smallest last value of a rising run of length k + 1
    ends: list[int] = []      # ends[k]: the index of that value
    before = [-1] * len(values)
    for i, v in enumerate(values):
        k = bisect.bisect_left(tails, v)
        if k == len(tails):
            tails.append(v)
            ends.append(i)
        else:
            tails[k], ends[k] = v, i
        if k:
            before[i] = ends[k - 1]
    run, i = [], ends[-1] if ends else -1
    while i >= 0:
        run.append(i)
        i = before[i]
    return run[::-1]


class TimeMap:
    """Matching times in the score (beats) and the performance (seconds).

    This is what lines the rolls up when showing a section or a comment.
    Project.time_map builds it from the links. Between its points, times are interpolated; before the first and
    after the last, the average tempo carries on.
    """

    def __init__(self, beats, seconds):
        self.beats = np.asarray(beats, dtype=float)       # both strictly increasing,
        self.seconds = np.asarray(seconds, dtype=float)   # with at least two points
        self.seconds_per_beat = ((self.seconds[-1] - self.seconds[0])
                                 / (self.beats[-1] - self.beats[0]))

    def to_perf(self, beat: float) -> float:
        """The performance time, in seconds, that matches a score time in beats."""
        b, s = self.beats, self.seconds
        if b[0] <= beat <= b[-1]:
            return float(np.interp(beat, b, s))
        edge = 0 if beat < b[0] else -1
        return float(s[edge] + (beat - b[edge]) * self.seconds_per_beat)

    def to_score(self, second: float) -> float:
        """The score time, in beats, that matches a performance time in seconds."""
        b, s = self.beats, self.seconds
        if s[0] <= second <= s[-1]:
            return float(np.interp(second, s, b))
        edge = 0 if second < s[0] else -1
        return float(b[edge] + (second - s[edge]) / self.seconds_per_beat)


@dataclass
class Project:
    performance: NoteTrack          # seconds
    score: NoteTrack                # beats
    alignment: Alignment
    perf_note_array: np.ndarray     # kept for saving
    score_note_array: np.ndarray
    source: Optional[Path] = None   # the file or folder this was opened from
    perf_obj: object = None         # partitura Performance (needed for .match export)
    score_obj: object = None        # partitura Score or Part (needed for .match export)
    # A new alignment is made from two files instead of opened from one: its
    # (score, performance) files. source is None then.
    pair: Optional[tuple[Path, Path]] = None
    ornaments: list[Ornament] = field(default_factory=list)
    # Links that realigning keeps. Removing a link clears its anchor in the
    # same undo step; pinned_anchors() also leaves out any anchor whose link
    # is gone, so a stray one is never drawn or saved.
    anchors: set[Link] = field(default_factory=set)
    comments: list[Comment] = field(default_factory=list)
    sections: list[Section] = field(default_factory=list)
    # From a .match file: its info lines ({attribute: value}), its scoreprop
    # lines as written, and its omitted sections (dicts as for save_match).
    # Kept in project.json; exporting a .match file uses the info lines'
    # performer, piece, composer and MIDI clock, and finds omitted sections anew.
    match_header: dict = field(default_factory=dict)
    # Every note as partitura writes it for a .match file, worked out once
    # when an export first needs it (it takes a while for a big score); the
    # notes never change, so it holds for the session. Never saved.
    partitura_lines: object = None
    method: Optional[str] = None    # the realign method last chosen, kept in project.json
    # Where the work came from: "original" (the .match file or folder first
    # opened), and "score" and "performance" (the files the alignment is of)
    # when known. Kept in project.json, so re-exporting doesn't lose them.
    sources: dict[str, str] = field(default_factory=dict)
    # The Parangonada files FERMATA never edits, byte for byte as they were opened.
    kept_files: dict[str, bytes] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)   # problems found while opening
    # Ornaments written in the MusicXML score, by score note id: their types, as
    # FERMATA names them ("trill", "mordent", ...). See notated_ornaments.
    notated: dict[str, tuple[str, ...]] = field(default_factory=dict)
    # The performance notes are as long as their keys were held. Those the
    # sustain pedal held on: how long they sounded, in seconds, by performance
    # note id, for playing and realigning (see played_notes). Never saved.
    sustained: dict[str, float] = field(default_factory=dict)

    @property
    def name(self) -> str:
        """The file's name, or for a new alignment the performance's: a score
        usually has several performances."""
        files = self.pair_files
        if files:
            return files[1].stem
        return self.source.stem if self.source else "Untitled"

    @property
    def pair_files(self) -> Optional[tuple[Path, Path]]:
        """For a new alignment, its (score, performance) files: the pair it was
        made from, or when it's opened from a backup or an export of one, the
        files its project.json names. None for anything else, which always has
        an "original" among its sources."""
        if self.pair:
            return self.pair
        score, performance = self.sources.get("score"), self.sources.get("performance")
        if "original" in self.sources or not score or not performance:
            return None
        files = Path(score), Path(performance)
        return files if all(f.is_absolute() for f in files) else None

    def sounding_notes(self) -> np.ndarray:
        """The performance notes as long as they sounded, with the sustain pedal."""
        return with_pedal(self.perf_note_array, self.sustained)

    def pinned_anchors(self) -> set[Link]:
        """The anchors whose link exists."""
        return self.anchors & self.alignment.links

    def aligned_mask(self, kind: str) -> np.ndarray:
        """Boolean array per row: does this note have at least one link?"""
        track, by = ((self.performance, self.alignment.by_perf) if kind == "perf"
                     else (self.score, self.alignment.by_score))
        return np.fromiter((bool(by.get(i)) for i in track.ids), dtype=bool, count=len(track))

    def time_map(self) -> TimeMap:
        """Matching score and performance times, from the current links.

        Each linked score note counts at the onset of its earliest partner (the
        start of a trill, say), and each score onset at the median of its
        notes, so a slightly spread chord counts once. Points that would run
        backwards, like a stray link, are left out: the map keeps the longest
        run of points that moves forwards in both. With fewer than two points,
        the score is stretched over the performance.
        """
        perf, score = self.performance, self.score
        pairs = [(score.onset[score.row[sid]], min(perf.onset[perf.row[pid]] for pid in pids))
                 for sid, pids in self.alignment.by_score.items() if pids]
        if pairs:
            s, t = np.array(pairs).T
            order = np.argsort(s, kind="stable")
            s, t = s[order], t[order]
            beats, first, counts = np.unique(s, return_index=True, return_counts=True)
            seconds = np.array([np.median(t[a:a + n]) for a, n in zip(first, counts)])
            run = longest_rising(seconds.tolist())
            if len(run) >= 2:
                return TimeMap(beats[run], seconds[run])

        def extent(track: NoteTrack) -> list[float]:
            return [track.start, track.end if track.end > track.start else track.start + 1.0]
        return TimeMap(extent(score), extent(perf))

    def ornament_of_note(self) -> dict[tuple[str, str], str]:
        """(kind, note id) -> ornament type, where kind is "perf" or "score"."""
        out = {}
        for orn in self.ornaments:
            out.update({("score", i): orn.type for i in orn.score})
            out.update({("perf", i): orn.type for i in orn.performance})
        return out

    def ornament_links(self) -> dict[Link, str]:
        """The links to export as .match ornament lines, with their ornament type.

        These are the links between an ornament's score and performance notes.
        Every ornamented score note keeps one plain match, though: a score note
        that only appears in ornament lines is missing from the .match file's
        score. If it has no plain link, its earliest-played note stays one.
        """
        perf, out = self.performance, {}
        for orn in self.ornaments:
            if orn.group != "ornament":
                continue
            members = set(orn.performance)
            for sid in orn.score:
                partners = self.alignment.by_score.get(sid, set())
                ornament_notes = [p for p in partners if p in members]
                if ornament_notes and len(ornament_notes) == len(partners):
                    ornament_notes.sort(key=lambda p: perf.onset[perf.row[p]])
                    ornament_notes = ornament_notes[1:]
                out.update({(sid, p): orn.type for p in ornament_notes})
        return out

    def grouping_links(self) -> set:
        """The links between every grouping's score and performance notes, of
        ornaments and the other groupings alike."""
        return {(sid, pid) for orn in self.ornaments for sid in orn.score for pid in orn.performance
                if (sid, pid) in self.alignment.links}

    def partitura_alignment(self, with_ornaments: bool = False) -> list[dict]:
        return self.alignment.to_partitura(self.score.ids, self.performance.ids,
                                           self.ornament_links() if with_ornaments else None)


# --------------------------------------------------------------------------- loading

@contextmanager
def _ornament_notes_count_as_played():
    """Make partitura include the notes of ornament lines in the performance.

    partitura 1.9 builds the performance from note, snote-note and insertion
    lines only, so notes that appear only in ornament lines, such as the extra
    notes of a trill, vanish when a .match file is opened. Remove this once
    partitura includes them: test_partitura_keeps_ornament_notes will start
    passing, which fails the test run on purpose.
    """
    original = getattr(_matchfile_base, "note_classes", None)
    ornament_line = getattr(_matchfile_base, "BaseOrnamentLine", None)
    if original is None or ornament_line is None or ornament_line in original:
        yield   # partitura has changed: nothing to patch
        return
    _matchfile_base.note_classes = original + (ornament_line,)
    try:
        yield
    finally:
        _matchfile_base.note_classes = original


@contextmanager
def _virtual_lines_count_as_links():
    """Make partitura read back the extra partners it writes as virtual lines.

    A .match file has one line per note, so partitura's save_match writes every
    partner of a note but the first as a virtualSnote(...)-note(...),
    snote(...)-virtualPnote(...) or virtualSnote(...)-virtualPnote(...) line.
    partitura 1.9's load_match ignores those lines: their links are lost, and so
    are the notes that appear only in them, such as the notes of a pass linked
    to score notes that another pass is linked to as well. Remove this once
    partitura reads them: test_partitura_reads_virtual_lines will start passing,
    which fails the test run on purpose.
    """
    base = _matchfile_base
    names = ("note_classes", "snote_classes", "VirtualSnoteNoteLine",
             "BaseSnoteVirtualNoteLine", "VirtualSnoteVirtualNoteLine")
    alignment = getattr(_importmatch, "alignment_from_matchfile", None)
    if alignment is None or not all(hasattr(base, name) for name in names):
        yield   # partitura has changed: nothing to patch
        return
    notes, snotes = base.note_classes, base.snote_classes
    virtual = (base.VirtualSnoteNoteLine, base.BaseSnoteVirtualNoteLine,
               base.VirtualSnoteVirtualNoteLine)

    def with_virtual_links(mf):
        return alignment(mf) + [{"label": "match", "score_id": str(line.snote.Anchor),
                                 "performance_id": format_pnote_id(line.note.Id)}
                                for line in mf.lines if isinstance(line, virtual)]

    # The other side of these two is a whole note, which the performance or the
    # score needs.
    base.note_classes = notes + (base.VirtualSnoteNoteLine,)
    base.snote_classes = snotes + (base.BaseSnoteVirtualNoteLine,)
    _importmatch.alignment_from_matchfile = with_virtual_links
    try:
        yield
    finally:
        base.note_classes, base.snote_classes = notes, snotes
        _importmatch.alignment_from_matchfile = alignment


PEDAL_OFF = 127   # a sustain pedal threshold no pedal value goes above


def played_notes(performance) -> tuple[np.ndarray, dict[str, float]]:
    """A partitura Performance's notes as long as their keys were held, and
    how long those the sustain pedal held on sounded, by id. partitura adds the
    pedal to a note's length when its value is above 64, half pedal too, so a
    pedalled passage hides its notes under each other's tails. The Performance
    keeps its pedal, for .match export."""
    parts = performance.performedparts
    pedalled = performance.note_array()
    before = [part.sustain_pedal_threshold for part in parts]
    try:
        for part in parts:
            part.sustain_pedal_threshold = PEDAL_OFF
        keys = performance.note_array()
    finally:
        for part, threshold in zip(parts, before):
            part.sustain_pedal_threshold = threshold
    sounded = dict(zip(pedalled["id"].astype(str).tolist(), pedalled["duration_sec"].tolist()))
    held = zip(keys["id"].astype(str).tolist(), keys["duration_sec"].tolist())
    return keys, {i: sounded[i] for i, d in held if sounded.get(i, d) > d}


def with_pedal(notes: np.ndarray, sustained: dict[str, float]) -> np.ndarray:
    """notes with the lengths the sustain pedal gave them (see played_notes)."""
    if not sustained or not len(notes):
        return notes
    notes = notes.copy()
    ids = notes["id"].astype(str).tolist()
    notes["duration_sec"] = [sustained.get(i, d) for i, d in zip(ids, notes["duration_sec"].tolist())]
    return notes


def _make_project(pna, sna, entries, ornaments=None, anchors=(), comments=(), **kwargs) -> Project:
    """Build a project, skipping links and ornament notes that point to notes
    the file doesn't contain (instead of failing later)."""
    warnings = []
    _, first = np.unique(pna["id"], return_index=True)
    if len(first) < len(pna):
        warnings.append(f"{_plural(len(pna) - len(first), 'duplicate performance note')} "
                        "were ignored.")
        pna = pna[np.sort(first)]
    performance = NoteTrack.from_note_array(pna, "onset_sec", "duration_sec")
    score = NoteTrack.from_note_array(sna, "onset_beat", "duration_beat")
    alignment, found = from_partitura(entries)
    unknown = {(s, p) for s, p in alignment.links if s not in score.row or p not in performance.row}
    if unknown:
        alignment.remove(unknown)
        warnings.append(f"{_plural(len(unknown), 'link')} pointed to notes that aren't in the "
                        "file and were skipped.")
    clean, dropped = [], 0
    for orn in groupings_on_chords(found if ornaments is None else ornaments, score):
        kept = Ornament(orn.type, [i for i in orn.score if i in score.row],
                        [i for i in orn.performance if i in performance.row], orn.group)
        dropped += len(orn.score) + len(orn.performance) - len(kept.score) - len(kept.performance)
        if kept.score or kept.performance:
            clean.append(kept)
    if dropped:
        warnings.append(f"{_plural(dropped, 'note')} in the ornaments aren't in the file and were skipped.")
    anchors = set(anchors)
    if anchors - alignment.links:
        warnings.append(f"{_plural(len(anchors - alignment.links), 'anchor')} in {ANCHORS_FILE} "
                        "aren't links in align.csv and were skipped.")
    kept_comments = []
    for c in comments:
        known = replace(c, performance=[i for i in c.performance if i in performance.row])
        if known.performance:
            kept_comments.append(known)
    if len(kept_comments) < len(comments):
        warnings.append(f"{_plural(len(comments) - len(kept_comments), 'comment')} in "
                        f"{COMMENTS_FILE} are about notes that aren't in the file, or only about "
                        "score notes, and were skipped.")
    notated = {sid: kinds for sid, kinds in notated_ornaments(kwargs.get("score_obj")).items()
               if sid in score.row}
    return Project(performance, score, alignment, pna, sna, ornaments=clean,
                   anchors=anchors & alignment.links, comments=kept_comments,
                   warnings=warnings, notated=notated, **kwargs)


# MusicXML's ornaments, as partitura reads them into a note's ornaments, by
# FERMATA's ornament types. A wavy-line on its own carries a trill on to later
# notes, so it isn't an ornament of its note.
NOTATED_ORNAMENTS = {
    "trill-mark": "trill", "mordent": "mordent", "inverted-mordent": "inverted-mordent",
    "turn": "turn", "delayed-turn": "turn", "vertical-turn": "turn",
    "inverted-turn": "inverted-turn", "delayed-inverted-turn": "inverted-turn",
    "inverted-vertical-turn": "inverted-turn", "tremolo": "tremolo", "shake": "shake",
    "schleifer": "schleifer", "haydn": "haydn", "other-ornament": "generic_ornament",
}


def notated_ornaments(score_obj) -> dict[str, tuple[str, ...]]:
    """The ornaments written in a partitura score or part, such as a trill
    sign over a note, by note id: FERMATA's ornament types, in the order the
    score has them. Unfolded parts keep them, with their notes' ids ("n33-1")."""
    if score_obj is None:
        return {}
    parts = score_obj.parts if hasattr(score_obj, "parts") else [score_obj]
    out = {}
    for part in parts:
        for note in getattr(part, "notes_tied", ()):
            kinds = [NOTATED_ORNAMENTS[o] for o in (getattr(note, "ornaments", None) or ())
                     if o in NOTATED_ORNAMENTS]
            if kinds:
                out[str(note.id)] = tuple(dict.fromkeys(kinds))
    return out


def _generated_files(project: Project) -> dict[str, bytes]:
    """The kept files for a project that wasn't opened from a Parangonada folder.
    Its zalign.csv holds the alignment as it was when the project was opened."""
    with tempfile.TemporaryDirectory() as tmp:
        save_parangonada_csv(project.partitura_alignment(), project.perf_note_array,
                             project.score_note_array, outdir=tmp)
        return {name: (Path(tmp) / name).read_bytes() for name in KEPT_FILES}


_INFO_LINE = re.compile(r"^info\((scoreFileName|scoreFilePath|midiFileName|midiFilePath),(.*)\)\.\s*$")


def match_sources(path) -> dict[str, str]:
    """The score and performance files a .match file names in its header, if any."""
    found = {}
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            if not line.startswith("info("):
                break   # the header is over
            m = _INFO_LINE.match(line.strip())
            if m:
                value = m.group(2).strip().strip("'\"").strip()
                if value and value != "-":
                    found[m.group(1)] = value
    sources = {}
    for key, name, folder in (("score", "scoreFileName", "scoreFilePath"),
                              ("performance", "midiFileName", "midiFilePath")):
        name, folder = found.get(name), found.get(folder)
        if name and folder and not folder.endswith(name):
            sources[key] = str(Path(folder) / name)
        elif name or folder:
            sources[key] = name or folder
    return sources


def load_match(path, score_path=None, keep=()) -> Project:
    """Open a .match file with its MusicXML score, score_path. Score notes in
    keep stay, also ones read_match_score leaves out: those saved work has
    links on (see read_match_score).

    The performance and the links come from the .match file, and the score
    from the MusicXML: all its notes, also those inside the omitted sections
    that a .match file leaves out, with the ids the .match file gives them
    (read_match_score) and the beats it gives them. Ornaments and comments come
    from the JSON files beside it (match_side_files); without an ornaments
    file, the ornaments are read from the attributes of its links.

    FERMATA always opens a .match file with its score. Without score_path, the
    score is the one partitura builds from the .match file itself, which is
    how the tests open parangonar's example.
    """
    path = Path(path)
    lines = _read_match_lines(path)
    header, section_lines = read_match_header(path)
    with _ornament_notes_count_as_played(), _virtual_lines_count_as_links():
        if score_path is None:
            perf, entries, score = pt.load_match(str(path), create_score=True)
            sna = score.note_array()
        else:
            perf, entries = pt.load_match(str(path))
            score, sna = read_match_score(score_path, lines.snotes.keys(), keep)
    sources = {"original": str(path.resolve()), **match_sources(path)}
    if score_path is not None:
        sources["score"] = str(Path(score_path).resolve())
    ornaments, comments = read_match_side_files(path)
    if ornaments is None:
        ornaments = ornaments_from_attributes(lines) or None   # or else from ornament lines
    pna, sustained = played_notes(perf)
    project = _make_project(pna, _file_beats(sna, path), entries, sustained=sustained,
                            ornaments=ornaments, comments=comments,
                            source=path, perf_obj=perf, score_obj=score, sources=sources,
                            match_header=header, sections=sections_from_match(section_lines, header))
    from . import repeats   # repeats needs model: imported here
    # The score notes it has links for inside its omitted sections (the Rach3
    # files have some): an omitted section is split only for links made since.
    linked = sorted(sid for sid, links in project.alignment.by_score.items()
                    if links and repeats.inside_omitted(project, sid))
    if linked:
        project.match_header["linked_in_omitted"] = linked
    # The names of its other groupings, which its snote lines may have too.
    names = sorted({o.attribute for o in project.ornaments if o.group == "other"})
    if names:
        project.match_header["grouping_attributes"] = names
    project.kept_files = _generated_files(project)
    return project


def match_score_name(path) -> str:
    """The file name of the MusicXML score a .match file names in its
    info(scoreFileName) line, or "" if it names none ("-")."""
    name = read_match_header(path)[0].get("info", {}).get("scoreFileName", "").strip().strip("'\"")
    return "" if name in ("", "-") else Path(name.replace("\\", "/")).name


# The Rach3 dataset's names: "p", the performer, date and take, the piece, and
# "mi". p1200811001rachmaop30m1mi_alignment.match plays rachmaop30m1.musicxml.
_DATASET_NAME = re.compile(r"^p\d+([a-z].*)mi(?:_alignment)?$", re.IGNORECASE)


def match_score_names(path) -> list[str]:
    """The names the MusicXML score of a .match file can have, the likeliest
    first: the piece its file name says, as the dataset names its files (whose
    scoreFileName is "-"), then the score its info(scoreFileName) line names."""
    names = []
    dataset = _DATASET_NAME.match(Path(path).stem)
    if dataset:
        names.append(f"{dataset.group(1)}.musicxml")
    named = match_score_name(path)
    if named and named.lower() not in (n.lower() for n in names):
        names.append(named)
    return names


def find_score(folder, name: str) -> Optional[Path]:
    """The file called name in folder or any folder inside it, ignoring case;
    the one nearest the top if there are several. None if there's none, or
    the folder can't be searched."""
    try:
        if not folder or not name or not Path(folder).is_dir():
            return None
    except OSError:   # a folder on the way that can't be searched
        return None
    found = []
    for root, dirs, files in os.walk(folder):
        dirs[:] = sorted(d for d in dirs if not d.startswith("."))
        found += [Path(root) / f for f in files if f.lower() == name.lower()]
    return min(found, key=lambda f: (len(f.parts), str(f))) if found else None


class ScoreError(ValueError):
    """The MusicXML score for a .match file can't be read, or doesn't fit it."""


def read_match_score(path, anchors, keep=()) -> tuple[object, np.ndarray]:
    """The MusicXML score of a .match file: a partitura Part with all the
    score's parts in one, and its notes, grace notes included, with the ids the
    .match file uses for them (anchors). Those are the score's own ids, or the
    ids of its notes with the repeats written out, such as "n6-1", which is
    what partitura's unfold_part_maximal gives and the Rach3 files use. The
    notes are those the Rach3 alignments are made with (_alignment_notes),
    with the notes in keep as well, such as double notes that work saved
    before FERMATA 0.1.14 has links on. Raises ScoreError, in words, if the
    file can't be read or doesn't have every score note of the .match file."""
    path = Path(path).resolve()
    try:
        _readable(path, SCORE_SUFFIXES, "a MusicXML score")
    except ValueError as exc:
        raise ScoreError(str(exc)) from None
    try:
        parts = list(pt.load_score(str(path)).parts)
        part = parts[0] if len(parts) == 1 else pt.score.merge_parts(parts)
    except Exception as exc:  # partitura raises all sorts: say it in words
        raise ScoreError(f"{path.name} couldn't be read as a MusicXML score: {_reason(exc)}") from exc
    anchors = set(anchors)
    missing = anchors
    for unfold in (False, True):
        try:
            candidate = pt.score.unfold_part_maximal(part) if unfold else part
            notes = candidate.note_array(include_grace_notes=True)
        except Exception as exc:  # partitura raises all sorts: say it in words
            raise ScoreError(f"{path.name} couldn't be read as a MusicXML score: "
                             f"{_reason(exc)}") from exc
        left = anchors - {str(i) for i in notes["id"]}
        if not left:
            return candidate, _alignment_notes(candidate, notes, anchors | set(keep))
        missing = min(missing, left, key=len)
    examples = ", ".join(sorted(missing)[:3])
    raise ScoreError(f"{path.name} doesn't fit this .match file: {_count(len(missing), 'score note')} "
                     f"of its {_count(len(anchors), 'score note')} aren't in it, such as {examples}. "
                     "Choose the MusicXML score the .match file was made from.")


def _alignment_notes(part, notes: np.ndarray, keep) -> np.ndarray:
    """A score's notes as the Rach3 alignments are made from them: each grace
    note with a beat of its own before its main note
    (expand_grace_notes_from_local_grace_order, a quarter at most), and a note
    at the same beat and pitch as another left out
    (remove_double_notes_from_score_note_array). The .match file has beats of
    its own for its notes, so this places the notes it leaves out, those of its
    omitted sections. Notes it names (keep) stay, also a double one. If
    partitura can't do it for a score, the notes are as note_array gives them."""
    try:
        expanded = expand_grace_notes_from_local_grace_order(
            part, grace_offset_quarter=1 / 4, include_metrical_position=True)
        single = {str(i) for i in remove_double_notes_from_score_note_array(expanded)["id"]}
    except Exception:  # partitura raises all sorts; the plain notes still work
        return notes
    kept = single | set(keep)
    return expanded[np.array([str(i) in kept for i in expanded["id"]], dtype=bool)]


def match_side_files(match_path) -> tuple[Path, Path]:
    """The ornaments and comments files that go with a .match file, beside it:
    p1..._alignment.match has p1..._alignment.ornaments.json and
    p1..._alignment.comments.json."""
    path = Path(match_path)
    stem = path.name[:-len(".match")] if path.name.lower().endswith(".match") else path.name
    return path.with_name(f"{stem}.ornaments.json"), path.with_name(f"{stem}.comments.json")


def read_match_side_files(match_path) -> tuple[Optional[list[Ornament]], list[Comment]]:
    """The ornaments and comments of the JSON files beside a .match file: None
    for the ornaments if there's no ornaments file, and no comments if there's
    no comments file."""
    ornaments_path, comments_path = match_side_files(match_path)
    ornaments = _read_ornaments_file(ornaments_path) if ornaments_path.exists() else None
    comments = _read_comments_file(comments_path) if comments_path.exists() else []
    return ornaments, comments


# How an ornament is named in the attribute list of a .match file's
# virtualSnote(...) lines, as the type of the connection, like pitch_error.
ORNAMENT_ATTRIBUTES = {"trill": "trill", "mordent": "mordent", "inverted-mordent": "inverted_mordent",
                       "turn": "turn", "inverted-turn": "inverted_turn", "tremolo": "tremolo",
                       "generic_ornament": "ornament"}


def chord_notes(score: "NoteTrack", sid: str) -> list[str]:
    """The ids of the score notes on the same onset as sid, its chord, the
    lowest first."""
    onset = score.onset[score.row[sid]]
    rows = np.flatnonzero(np.isclose(score.onset, onset))
    return [str(score.ids[r]) for r in sorted(rows, key=lambda r: (score.pitch[r], str(score.ids[r])))]


def groupings_on_chords(ornaments, score: "NoteTrack") -> list:
    """The groupings, with an improvisation read from a .match file's
    attributes, which only names the chord's lowest note, on its whole chord."""
    out = []
    for orn in ornaments:
        if orn.group == "improvisation" and len(orn.score) == 1 and orn.score[0] in score.row:
            orn = Ornament(orn.type, chord_notes(score, orn.score[0]), orn.performance, orn.group)
        out.append(orn)
    return out


def ornament_attribute(kind: str) -> str:
    """An ornament type's name in a .match file's attribute list."""
    return ORNAMENT_ATTRIBUTES.get(kind, re.sub(r"[^A-Za-z0-9]+", "_", kind).strip("_") or "ornament")


def ornaments_from_attributes(lines: "_MatchLines") -> list[Ornament]:
    """Ornaments from the ornament attributes of a .match file's virtualSnote
    lines: the performance notes of each score note's links that name an
    ornament. An snote(...) line's attribute list is the score note's own, where
    partitura puts the ornaments written in the score, such as a turn. Basso
    continuo realizations and improvisations come back from their keywords
    (GROUPING_KEYWORDS), on those lines and on their first note's snote line:
    a realization on its score note, an improvisation on every score note of
    the chord whose lowest note its notes are linked to (see
    groupings_on_chords)."""
    kinds = {attribute: kind for kind, attribute in ORNAMENT_ATTRIBUTES.items()}
    played: dict[tuple[str, str], list[str]] = defaultdict(list)
    grouped: dict[tuple[str, str], list[str]] = defaultdict(list)
    for (sid, pid), attributes in lines.attributes.items():
        for attribute in attributes:
            if attribute in GROUPING_KEYWORDS:
                grouped[(sid, attribute)].append(pid)
            elif attribute in kinds:
                played[(sid, kinds[attribute])].append(pid)
    return ([Ornament(kind, [sid], pids) for (sid, kind), pids in played.items()]
            + [Ornament(kind, [sid], pids, kind) for (sid, kind), pids in grouped.items()])


def _file_beats(sna: np.ndarray, path) -> np.ndarray:
    """The score notes with the beats their snote(...) lines give (OnsetInBeats
    and OffsetInBeats). partitura 1.9 works the beats out again from bars and
    time signatures, and gets some wrong in pieces with changes of metre ("does
    not match OnsetInBeats"), which would put notes in the wrong place."""
    beats = {}
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            if not line.startswith("snote("):
                continue
            fields = _match_fields(line[len("snote("):].partition(")-")[0])
            try:
                beats[fields[0]] = (float(fields[6]), float(fields[7]))
            except (IndexError, ValueError, OverflowError):
                continue
    sna = sna.copy()
    for i, sid in enumerate(sna["id"]):
        found = beats.get(str(sid))
        if found:
            sna["onset_beat"][i] = found[0]
            sna["duration_beat"][i] = max(found[1] - found[0], 0.0)
    return sna


# The example FERMATA comes with: the first bars of Mozart's Variations K. 265,
# variation 1, as a .match file and its MusicXML score.
EXAMPLE_MATCH = Path(__file__).parent / "resources" / "simple_mozart_k265_var1.match"
EXAMPLE_SCORE = Path(__file__).parent / "resources" / "simple_mozart_k265_var1.musicxml"

_HEADER_LINE = re.compile(r"^(info|scoreprop|section|omittedSection)\((.*)\)\.\s*$")
MPQ, PPQ = 500000, 480   # a .match file's MIDI clock when it doesn't say: µs per quarter, ticks per quarter


def _match_fields(text: str) -> list[str]:
    """The comma-separated fields of a match line, a [list] counting as one."""
    fields, depth, current = [], 0, ""
    for ch in text:
        if ch == "," and depth == 0:
            fields.append(current.strip())
            current = ""
            continue
        depth += {"[": 1, "]": -1}.get(ch, 0)
        current += ch
    fields.append(current.strip())
    return fields


def _match_list(text: str) -> list[str]:
    return [item.strip() for item in text.strip().strip("[]").split(",") if item.strip()]


def read_match_header(path) -> tuple[dict, list[dict]]:
    """A .match file's info, scoreprop and omittedSection lines as a match
    header (see Project.match_header; load_match adds the score notes it has as
    deletions), and its section lines as dicts with the keys save_match takes.
    Lines that can't be read are left out."""
    info, scoreprops, omitted, sections = {}, [], [], []
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            found = _HEADER_LINE.match(line.strip())
            if not found:
                continue
            kind, body = found.groups()
            try:
                if kind == "info":
                    attribute, _, value = body.partition(",")
                    info[attribute.strip()] = value.strip()
                elif kind == "scoreprop":
                    scoreprops.append(line.strip())
                elif kind == "omittedSection":
                    sid, a, b, c, d, attrs = _match_fields(body)
                    omitted.append({"id": sid, "start_in_beats_unfolded": float(a),
                                    "end_in_beats_unfolded": float(b),
                                    "start_in_beats_original": float(c),
                                    "end_in_beats_original": float(d),
                                    "section_attr_list": _match_list(attrs)})
                else:
                    sid, a, b, c, d, e, f2, attrs = _match_fields(body)
                    sections.append({"id": sid, "start_in_beats_unfolded": float(a),
                                     "end_in_beats_unfolded": float(b),
                                     "start_in_beats_original": float(c),
                                     "end_in_beats_original": float(d),
                                     "start_in_perf_time": int(float(e)),
                                     "end_in_perf_time": int(float(f2)),
                                     "section_attr_list": _match_list(attrs)})
            except (ValueError, OverflowError):
                continue   # a line FERMATA can't make sense of
    header = {}
    if info:
        header["info"] = info
    if scoreprops:
        header["scoreprop"] = scoreprops
    if omitted:
        header["omitted_sections"] = omitted
    return header, sections


def match_clock(header: dict) -> tuple[int, int]:
    """(microseconds per quarter, ticks per quarter) from a match header's info lines."""
    info = header.get("info", {})

    def number(key, default):
        try:
            return int(float(info.get(key, default)))
        except (ValueError, OverflowError):
            return default
    return number("midiClockRate", MPQ) or MPQ, number("midiClockUnits", PPQ) or PPQ


def sections_from_match(lines: list[dict], header: dict) -> list[Section]:
    """Sections from a .match file's section lines, one for each line, named
    after its id, with its keywords, over the stretch of the performance its
    MIDI ticks give. Exporting writes each line back as it was until the
    section is changed (Section.match)."""
    from .annotations import SECTION_COLOURS   # annotations needs model: imported here
    mpq, ppq = match_clock(header)
    seconds = mpq / 1e6 / ppq
    colours = list(SECTION_COLOURS.values())
    out = []
    for n, line in enumerate(sorted(lines, key=lambda l: l["start_in_perf_time"])):
        span = (line["start_in_perf_time"] * seconds, line["end_in_perf_time"] * seconds)
        values = (line["start_in_beats_unfolded"], line["end_in_beats_unfolded"],
                  line["start_in_beats_original"], line["end_in_beats_original"],
                  line["start_in_perf_time"], line["end_in_perf_time"])
        out.append(Section(line["id"], colours[n % len(colours)], span, (), line["id"],
                           tuple(line["section_attr_list"]), values))
    return out


def read_ornaments(folder) -> list[Ornament]:
    """Ornaments from a project folder's ornaments.json, or none if there's no file."""
    path = Path(folder) / ORNAMENTS_FILE
    return _read_ornaments_file(path) if path.exists() else []


def _read_ornaments_file(path: Path) -> list[Ornament]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if data.get("format", ORNAMENTS_FORMAT) > ORNAMENTS_FORMAT:
            raise ValueError("it was written by a newer version of FERMATA")
        return [Ornament.from_json(item) for item in data.get("ornaments", [])]
    except (ValueError, KeyError, TypeError, AttributeError) as exc:
        raise ValueError(f"{path.name} couldn't be read: {exc}") from exc


def read_anchors(folder) -> set[Link]:
    """Anchors from a project folder's anchors.json, or none if there's no file."""
    path = Path(folder) / ANCHORS_FILE
    if not path.exists():
        return set()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if data.get("format", ANCHORS_FORMAT) > ANCHORS_FORMAT:
            raise ValueError("it was written by a newer version of FERMATA")
        return {(str(item["score"]), str(item["performance"])) for item in data.get("anchors", [])}
    except (ValueError, KeyError, TypeError, AttributeError) as exc:
        raise ValueError(f"{ANCHORS_FILE} couldn't be read: {exc}") from exc


def read_comments(folder) -> list[Comment]:
    """Comments from a project folder's comments.json, or none if there's no file."""
    path = Path(folder) / COMMENTS_FILE
    return _read_comments_file(path) if path.exists() else []


def _read_comments_file(path: Path) -> list[Comment]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if data.get("format", COMMENTS_FORMAT) > COMMENTS_FORMAT:
            raise ValueError("it was written by a newer version of FERMATA")
        return [Comment.from_json(item) for item in data.get("comments", [])]
    except (ValueError, KeyError, TypeError, AttributeError) as exc:
        raise ValueError(f"{path.name} couldn't be read: {exc}") from exc


def read_project_file(folder) -> dict:
    """The method, sources and sections from a project folder's project.json:
    a dict with those keys, or an empty dict if there's no file. The format 1
    written by exports before only has the file it came from."""
    path = Path(folder) / PROJECT_FILE
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        version = data.get("format", 1)
        if version > PROJECT_FORMAT:
            raise ValueError("it was written by a newer version of FERMATA")
        if version < 2:
            return {"sources": {"original": data["source"]} if data.get("source") else {}}
        return {"sources": {str(k): str(v) for k, v in (data.get("sources") or {}).items() if v},
                "method": data.get("method"),
                "sections": [Section.from_json(item) for item in data.get("sections", [])],
                "match_header": dict(data.get("match") or {})}
    except (ValueError, KeyError, TypeError, AttributeError) as exc:
        raise ValueError(f"{PROJECT_FILE} couldn't be read: {exc}") from exc


def load_parangonada(folder) -> Project:
    folder = Path(folder)
    missing = [f for f in PARANGONADA_FILES if not (folder / f).exists()]
    if missing:
        raise FileNotFoundError(f"{folder.name} is missing {', '.join(missing)}.")
    perf, entries, _zalign, _feature, sna = load_parangonada_csv(str(folder), create_score=True)
    info = read_project_file(folder)
    sources = info.get("sources") or {"original": str(folder.resolve())}
    pna, sustained = played_notes(perf)   # Parangonada files have no pedal: as they are
    return _make_project(pna, sna, entries, sustained=sustained, ornaments=read_ornaments(folder),
                         anchors=read_anchors(folder), comments=read_comments(folder),
                         source=folder, perf_obj=perf, score_obj=None,
                         method=info.get("method"), sources=sources,
                         sections=info.get("sections", []),
                         match_header=info.get("match_header", {}),
                         kept_files={name: (folder / name).read_bytes() for name in KEPT_FILES})


def load(path, score=None, keep=()) -> Project:
    """Open a .match file, with its MusicXML score and the score notes in keep
    (see load_match), or a folder with the five Parangonada CSV files."""
    path = Path(path)
    if path.is_dir():
        return load_parangonada(path)
    if path.suffix.lower() == ".match":
        return load_match(path, score, keep)
    raise ValueError(f"{path.name} isn't a .match file or a folder of Parangonada CSV files.")


def first_links(folder) -> set[Link]:
    """The links in a project folder's zalign.csv: for a new alignment, the
    matcher's alignment as it was made."""
    alignment, _ = from_partitura(load_parangonada_alignment(str(Path(folder) / "zalign.csv")))
    return alignment.links


# --------------------------------------------------------------------------- a new alignment

@dataclass
class ScoreFile:
    """A MusicXML score, read for a new alignment."""
    path: Path            # absolute
    part: object          # partitura Part with all the score's parts, or None if they didn't merge
    notes: np.ndarray     # with is_grace, which DualDTWNoteMatcher needs
    parts: int            # how many parts the file has

    @property
    def summary(self) -> str:
        """What was read, in words: "312 notes, 2 parts"."""
        return f"{_count(len(self.notes), 'note')}, {_plural(self.parts, 'part')}"


@dataclass
class PerformanceFile:
    """A MIDI performance, read for a new alignment."""
    path: Path            # absolute
    performance: object   # partitura Performance, with all the tracks in one part
    notes: np.ndarray     # as long as their keys were held
    sustained: dict = field(default_factory=dict)   # see played_notes

    @property
    def duration(self) -> float:
        """Seconds from the start of the file to the end of the last note."""
        return float((self.notes["onset_sec"] + self.notes["duration_sec"]).max())

    @property
    def summary(self) -> str:
        """What was read, in words: "3,590 notes, 4:12"."""
        minutes, seconds = divmod(round(self.duration), 60)
        return f"{_count(len(self.notes), 'note')}, {minutes}:{seconds:02d}"


def _reason(exc: Exception) -> str:
    """An exception's message, also when partitura gives it as several parts."""
    return " ".join(str(arg) for arg in exc.args).strip() or type(exc).__name__


def _readable(path: Path, suffixes, kind: str) -> None:
    if path.suffix.lower() not in suffixes:
        raise ValueError(f"{path.name} isn't {kind}. Choose a {', '.join(suffixes[:-1])} "
                         f"or {suffixes[-1]} file.")
    if not path.is_file():
        raise ValueError(f"{path.name} can't be found.")


def read_score(path) -> ScoreFile:
    """Read a MusicXML score (.musicxml, .xml or .mxl) for a new alignment.
    Raises ValueError with what's wrong, in words.

    The score is read as written: repeat signs aren't unfolded, so a repeat
    the performer plays shows as performance notes without links. The .match
    format has room for one part, and partitura's save_match writes only the
    first, so several parts are merged into one. Note ids that parts share, or
    that are too long for the Parangonada files, are replaced by new ones.
    """
    path = Path(path).resolve()
    _readable(path, SCORE_SUFFIXES, "a MusicXML score")
    try:
        score = pt.load_score(str(path))
        parts = list(score.parts)
        ids = [str(note.id) for part in parts for note in part.notes]
        if len(set(ids)) < len(ids) or any(len(i) > CSV_CHARS for i in ids):
            pt.score.assign_note_ids(parts, keep=False)   # number them all afresh
        part = notes = None
        if ids:
            part = parts[0] if len(parts) == 1 else _merged(parts)
            notes = (part.note_array(include_grace_notes=True) if part is not None
                     else _notes_of_parts(parts))
    except Exception as exc:  # partitura raises all sorts: say it in words
        raise ValueError(f"{path.name} couldn't be read as a MusicXML score: {_reason(exc)}") from exc
    if notes is None or not len(notes):
        raise ValueError(f"{path.name} has no notes.")
    return ScoreFile(path, part, notes, len(parts))


def _merged(parts):
    try:
        return pt.score.merge_parts(parts)
    except Exception:  # partitura can't merge parts whose divisions change: no .match file then
        return None


def _notes_of_parts(parts) -> np.ndarray:
    """The note arrays of parts that couldn't be merged, as one. Each part's
    works on its own, even where partitura's for several parts fails."""
    notes = rfn.stack_arrays([part.note_array(include_grace_notes=True) for part in parts],
                             usemask=False, autoconvert=True)
    return notes[np.argsort(notes["onset_beat"], kind="stable")]


def read_performance(path) -> PerformanceFile:
    """Read a MIDI performance (.mid or .midi) for a new alignment, with all
    its tracks in one part, as the .match format needs. Raises ValueError
    with what's wrong, in words."""
    path = Path(path).resolve()
    _readable(path, PERFORMANCE_SUFFIXES, "a MIDI file")
    try:
        performance = pt.load_performance_midi(str(path), merge_tracks=True)
        played = any(len(part.notes) for part in performance.performedparts)
        notes, sustained = played_notes(performance) if played else (None, {})
    except Exception as exc:  # partitura and mido raise all sorts: say it in words
        raise ValueError(f"{path.name} couldn't be read as a MIDI file: {_reason(exc)}") from exc
    if notes is None or not len(notes):
        raise ValueError(f"{path.name} has no notes.")
    return PerformanceFile(path, performance, notes, sustained)


def new_project(score: ScoreFile, performance: PerformanceFile, links=(),
                method: Optional[str] = None, sections=()) -> Project:
    """A new alignment: score and performance with links between them, made
    from the two files rather than opened from one, with the sections the
    matcher found, if any. Its zalign.csv holds these links, to compare the
    edited alignment against later."""
    entries = [{"label": "match", "score_id": s, "performance_id": p} for s, p in links]
    project = _make_project(performance.notes, score.notes, entries,
                            pair=(score.path, performance.path), method=method,
                            sections=list(sections), sustained=dict(performance.sustained),
                            perf_obj=performance.performance, score_obj=score.part,
                            sources={"score": str(score.path), "performance": str(performance.path)})
    if score.part is None:
        project.warnings.append(f"The parts of {score.path.name} couldn't be merged into one, "
                                "so exports won't have a .match file. The Parangonada files "
                                "have every link.")
    project.kept_files = _generated_files(project)
    return project


def load_pair(score_path, performance_path, links=()) -> Project:
    """A new alignment's two files, read again and given links, as restoring
    its backup does. Raises ValueError if either can't be read."""
    return new_project(read_score(score_path), read_performance(performance_path), links)


# --------------------------------------------------------------------------- saving

def source_folders(project: Project) -> list[Path]:
    """The folders FERMATA never writes into: the folder the project was opened
    from or its file's folder, and for a new alignment the folders of the score
    and the performance, also when it was opened from a backup or an export."""
    folders = []
    if project.source is not None:
        folders.append(project.source if project.source.is_dir() else project.source.parent)
    folders += [path.parent for path in project.pair_files or ()]
    return list(dict.fromkeys(folders))


def refused_folder(project: Project, folder) -> Optional[str]:
    """Why FERMATA won't write into folder, in words, or None if it will."""
    folder = Path(folder).resolve()
    for source in source_folders(project):
        if folder != source.resolve():
            continue
        kinds = [kind for kind, path in zip(("score", "performance"), project.pair_files or ())
                 if path.parent.resolve() == folder]
        whose = (f"the folder of the {' and the '.join(kinds)}" if kinds
                 else "the folder this project was opened from")
        return (f"FERMATA doesn't write into {source.name}, {whose}, so the original files "
                "stay untouched.")
    return None


def _refuse_source_folder(project: Project, folder: Path) -> None:
    refusal = refused_folder(project, folder)
    if refusal:
        raise ValueError(f"{refusal} Choose another folder.")


def ornaments_json(ornaments: list[Ornament]) -> str:
    """ornaments.json with one ornament per line, which keeps git diffs readable."""
    lines = ",\n".join("    " + json.dumps(o.to_json(), ensure_ascii=False) for o in ornaments)
    body = f"[\n{lines}\n  ]" if ornaments else "[]"
    return f'{{\n  "format": {ORNAMENTS_FORMAT},\n  "ornaments": {body}\n}}\n'


def anchors_json(anchors) -> str:
    """anchors.json with one anchor per line, like ornaments.json."""
    lines = ",\n".join(f"    {json.dumps({'score': s, 'performance': p}, ensure_ascii=False)}"
                        for s, p in sorted(anchors))
    body = f"[\n{lines}\n  ]" if anchors else "[]"
    return f'{{\n  "format": {ANCHORS_FORMAT},\n  "anchors": {body}\n}}\n'


def comments_json(comments: list[Comment]) -> str:
    """comments.json with one comment per line, like ornaments.json."""
    lines = ",\n".join("    " + json.dumps(c.to_json(), ensure_ascii=False) for c in comments)
    body = f"[\n{lines}\n  ]" if comments else "[]"
    return f'{{\n  "format": {COMMENTS_FORMAT},\n  "comments": {body}\n}}\n'


def project_json(project: Project, **extra) -> str:
    """project.json: the method, the source files and the sections, one section
    per line. extra adds fields, such as the export time."""
    head = {"format": PROJECT_FORMAT, "fermata": __version__, **extra,
            "sources": project.sources, "method": project.method}
    lines = [f"  {json.dumps(k)}: {json.dumps(v, ensure_ascii=False)}" for k, v in head.items()]
    sections = ",\n".join("    " + json.dumps(s.to_json(), ensure_ascii=False)
                          for s in project.sections)
    lines.append('  "sections": ' + (f"[\n{sections}\n  ]" if project.sections else "[]"))
    if project.match_header:
        lines.append('  "match": ' + json.dumps(project.match_header, ensure_ascii=False))
    return "{\n" + ",\n".join(lines) + "\n}\n"


def _align_csv(project: Project) -> bytes:
    """align.csv for the current links, byte for byte as partitura writes it
    (np.savetxt with fmt="%.20s"), but several times faster, since this runs
    after every edit."""
    array = alignment_dicts_to_array(project.partitura_alignment())
    rows = [",".join(array.dtype.names)]
    rows += [",".join(str(value)[:20] for value in row) for row in array.tolist()]
    return ("\n".join(rows) + "\n").encode("utf-8")


def _write_files(folder: Path, files: dict[str, bytes]) -> list[str]:
    """Write files into folder, each replaced in one step so that a crash never
    leaves a half-written file. Files whose content is already the same aren't
    touched. Returns the names written."""
    written = []
    with tempfile.TemporaryDirectory(dir=folder) as tmp:
        for name, data in files.items():
            target = folder / name
            if target.exists() and target.read_bytes() == data:
                continue
            staged = Path(tmp) / name
            staged.write_bytes(data)
            os.replace(staged, target)
            written.append(name)
    return written


def save_work(project: Project, folder) -> None:
    """Write only what editing changes: align.csv with the current links
    (ornament links as plain matches), project.json, and ornaments.json,
    anchors.json and comments.json when there are ornaments, anchors or
    comments. Refuses the folder the project was opened from."""
    folder = Path(folder)
    _refuse_source_folder(project, folder)
    folder.mkdir(parents=True, exist_ok=True)
    files = {"align.csv": _align_csv(project)}
    if project.ornaments or (folder / ORNAMENTS_FILE).exists():
        files[ORNAMENTS_FILE] = ornaments_json(project.ornaments).encode("utf-8")
    anchors = project.pinned_anchors()
    if anchors or (folder / ANCHORS_FILE).exists():
        files[ANCHORS_FILE] = anchors_json(anchors).encode("utf-8")
    if project.comments or (folder / COMMENTS_FILE).exists():
        files[COMMENTS_FILE] = comments_json(project.comments).encode("utf-8")
    files[PROJECT_FILE] = project_json(project).encode("utf-8")
    _write_files(folder, files)


def save_parangonada(project: Project, folder) -> None:
    """Write the project as a complete Parangonada folder: the work (see
    save_work) plus the other four files exactly as they were opened.
    Refuses the folder the project was opened from."""
    folder = Path(folder)
    save_work(project, folder)
    _write_files(folder, dict(project.kept_files or _generated_files(project)))


def save_match(project: Project, path, info: Optional[dict] = None) -> set[Link]:
    """Write a .match file, as the extension of the format for non-unique
    alignments describes it (Chiruthapudi et al., "A Flexible Encoding Model
    for Non-Unique Note Alignments"):

    * A score note's partner with the score note's pitch, or else its earliest,
      gets its snote(...)-note(...) line; its other partners virtualSnote(...)
      lines. A performance note's first link gets its note(...); its others
      virtualPnote(...).
    * A link between notes of different pitches has pitch_error in its
      attribute list. An ornament's notes have the ornament's type there
      instead, such as trill, on their virtualSnote lines.
    * Score notes without links get deletion lines, except inside omitted
      sections, and performance notes without links insertion lines.

    A file the project was opened from is written back line for line: every
    line but the links' stays as it was, and lines it had keep their place.
    info sets info lines, such as {"performer": "p1"}. Returns the links that
    went into virtual lines, which partitura 1.9's own load_match ignores.
    """
    if project.score_obj is None or project.perf_obj is None:
        raise ValueError("Writing .match needs the full score, and Parangonada CSV files "
                         "only contain note lists. Open the project from a .match file, or "
                         "align its MusicXML score and MIDI performance on the start page.")
    from . import repeats   # repeats needs model: imported here
    mpq, ppq = match_clock(project.match_header)
    omitted = repeats.omitted_sections(project)
    sections = repeats.match_sections(project, mpq, ppq)
    lines = _lines_for(project, omitted, mpq, ppq)
    text, virtual = _match_text(project, lines, sections, omitted, info or {})
    Path(path).write_text(text, encoding="utf-8")
    return virtual


@dataclass
class _MatchLines:
    """The lines of a .match file that FERMATA writes back: the header before
    the notes (without section and omittedSection lines, which are made anew),
    every other line after them (pedals, say), and each note as written: the
    inside of its snote(...) by score id, with its attributes, and of its
    note(...) by performance id. Also where each note line was, to keep the
    order, and the attribute lists of the virtualSnote links (to read ornaments
    from)."""
    header: list
    trailer: list
    snotes: dict       # score id: (snote fields before the attribute list, attributes)
    notes: dict        # performance id: note fields
    order: dict        # note line: its place among them
    attributes: dict   # (score id, performance id): a virtualSnote link's attributes
    in_file: Optional[set] = None   # the score notes the file had; None for partitura's lines


def _read_match_lines(path) -> _MatchLines:
    header, trailer, snotes, notes, order, attributes = [], [], {}, {}, {}, {}
    in_notes = False
    with open(path, encoding="utf-8", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith(("section(", "omittedSection(")):
                continue
            if line.startswith("insertion-note("):
                body = line[len("insertion-note("):].rstrip(".")[:-1]
                notes[body.split(",", 1)[0]] = body
            elif line.startswith(("snote(", "virtualSnote(", "ornament(")):
                left, _, right = line.partition(")-")
                sid, link_attrs = None, []
                if left.startswith(("snote(", "virtualSnote(")):
                    body = left[left.index("(") + 1:]
                    cut = body.rfind(",[")
                    sid, link_attrs = body.split(",", 1)[0], _match_list(body[cut + 1:]) if cut >= 0 else []
                    if left.startswith("snote("):
                        snotes[sid] = (body[:cut], [a for a in link_attrs if a != "pitch_error"])
                if right.startswith("note("):
                    body = right[len("note("):].rstrip(".")[:-1]
                    pid = body.split(",", 1)[0]
                    notes[pid] = body
                elif right.startswith("virtualPnote("):
                    pid = right[len("virtualPnote("):].rstrip(".").rstrip(")").rstrip(",")
                else:
                    pid = None
                if left.startswith("virtualSnote(") and pid is not None:
                    attributes[(sid, pid)] = link_attrs
                elif left.startswith("snote(") and pid is not None:
                    # A grouping's first note's line has its keyword here too.
                    grouped = [a for a in link_attrs if a in GROUPING_KEYWORDS]
                    if grouped:
                        attributes[(sid, pid)] = grouped
            else:
                (trailer if in_notes else header).append(line)
                continue
            in_notes = True
            order.setdefault(line, len(order))
    return _MatchLines(header, trailer, snotes, notes, order, attributes)


def _original_match(project: Project) -> Optional[_MatchLines]:
    """The lines of the .match file the project was opened from, to write it
    back, or None if there's none or it's of the older format (before
    version 1), whose note lines are written differently."""
    source = project.sources.get("original", "")
    if not source.lower().endswith(".match") or not Path(source).is_file():
        return None
    if not project.match_header.get("info", {}).get("matchFileVersion", "").startswith("1."):
        return None
    return _read_match_lines(source)


def _lines_for(project: Project, omitted, mpq: int, ppq: int) -> _MatchLines:
    """The lines to write a .match file from: the original's, with partitura's
    for notes it doesn't have, such as score notes of an omitted section that
    now have a link; for a new alignment, partitura's alone."""
    original = _original_match(project)
    if original is not None:
        original.in_file = set(original.snotes)
        needed = set(project.alignment.by_score) | set(_deletions(project, omitted, original.in_file))
        if needed <= original.snotes.keys() and set(project.performance.ids) <= original.notes.keys():
            return original
    if project.partitura_lines is None:
        project.partitura_lines = _partitura_lines(project, mpq, ppq)
    made = project.partitura_lines
    if original is None:
        return _MatchLines(made.header, made.trailer, made.snotes, made.notes, {}, {})
    for sid, text in made.snotes.items():
        original.snotes.setdefault(sid, text)
    for pid, text in made.notes.items():
        original.notes.setdefault(pid, text)
    return original


def _deletions(project: Project, omitted, in_file: Optional[set]) -> list[str]:
    """The score notes that get deletion lines: those without links, except
    inside omitted sections; and of a file the project was opened from (whose
    score notes are in_file), except those it didn't have outside its own
    omitted sections, such as a note at the same beat and pitch as another
    (voice overlap), of which the Rach3 files have one."""
    from . import repeats   # repeats needs model: imported here
    out = []
    for sid, beat in zip(project.score.ids, project.score.onset):
        sid = str(sid)
        if project.alignment.by_score.get(sid) or _omitted_beat(float(beat), omitted):
            continue
        if in_file is not None and sid not in in_file and not repeats.inside_omitted(project, sid):
            continue
        out.append(sid)
    return out


def _partitura_lines(project: Project, mpq: int, ppq: int) -> _MatchLines:
    """Every note of the project as partitura's save_match writes it, with
    the header and pedal lines it writes."""
    # partitura works out a time map from the links, so they come along.
    alignment = project.partitura_alignment()
    files = {f"{kind}_filename": Path(project.sources[kind]).name
             for kind in ("score", "performance") if project.sources.get(kind)}
    _whole_times(project.score_obj)
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "notes.match"
        pt.save_match(alignment, project.perf_obj, project.score_obj, str(out), mpq=mpq, ppq=ppq,
                      **files)
        return _read_match_lines(out)


def _omitted_beat(beat: float, omitted) -> bool:
    """Whether a score note at beat lies inside an omitted section, where it
    has no line. Strictly inside, as partitura's save_match and the Rach3 files
    have it: a note on the very start or end keeps its deletion line. Beats
    are written with 4 decimals, and kept as 32-bit floats."""
    return any(o["start_in_beats_unfolded"] + 5e-4 < beat < o["end_in_beats_unfolded"] - 5e-4
               for o in omitted)


def _voice_overlaps(score_obj) -> set[str]:
    """Score notes that share their onset and pitch with another, which
    partitura's save_match marks voice_overlap on their deletion lines."""
    try:
        notes = score_obj.note_array()
        keys = notes[["onset_div", "pitch"]]
        uniques, counts = np.unique(keys, return_counts=True)
        doubled = set(uniques[counts > 1].tolist())
        return {str(i) for i, key in zip(notes["id"], keys.tolist()) if key in doubled}
    except Exception:  # a score without onset_div: no deletion line says it then
        return set()


def _match_text(project: Project, lines: _MatchLines, sections, omitted, info) -> tuple[str, set]:
    """The .match file's text, and the links in virtual lines (see save_match)."""
    perf, score, al = project.performance, project.score, project.alignment
    tmap = project.time_map() if al.links else None
    overlaps = _voice_overlaps(project.score_obj)
    ornament_of = {}   # link: (its grouping's attribute, whether it's an ornament)
    for orn in project.ornaments:
        for sid in orn.score:
            for pid in orn.performance:
                if (sid, pid) in al.links:
                    ornament_of[(sid, pid)] = (orn.attribute, orn.group == "ornament")
    # Groupings' names a file's snote lines had are written anew from the groupings.
    grouping_names = (set(GROUPING_KEYWORDS) | set(project.match_header.get("grouping_attributes", ()))
                      | {o.attribute for o in project.ornaments if o.group != "ornament"})

    def snote(sid, extra=()):
        base, attrs = lines.snotes[sid]
        attrs = [a for a in attrs if a != "voice_overlap" and a not in grouping_names] + list(extra)
        return f"snote({base},[{','.join(attrs)}])"

    def note_time(pid):
        r = perf.row[pid]
        return (float(perf.onset[r]), int(perf.pitch[r]))

    def score_time(sid):
        r = score.row[sid]
        beat = float(score.onset[r])
        return (float(tmap.to_perf(beat)) if tmap is not None else beat, int(score.pitch[r]))

    def wrong_pitch(link):
        return int(perf.pitch[perf.row[link[1]]]) != int(score.pitch[score.row[link[0]]])

    # The paper's order: plain links before ornaments, a score note's own pitch
    # before others, then in time, so each note's first link is its real line.
    order = sorted(al.links, key=lambda link: (ornament_of.get(link, ("", False))[1],
                                               wrong_pitch(link), note_time(link[1]),
                                               score_time(link[0]), link))
    out_lines, seen_s, seen_p, virtual = [], set(), set(), set()
    for sid, pid in order:
        kind, is_ornament = ornament_of.get((sid, pid), (None, False))
        first_s, first_p = sid not in seen_s, pid not in seen_p
        # An ornament's type goes on its virtualSnote lines only, as the
        # paper's examples have it; another grouping's name on every line of
        # its notes, the score note's first one included. Neither is a pitch error.
        if kind:
            attrs = [kind] if not (is_ornament and first_s) else []
        else:
            attrs = ["pitch_error"] if wrong_pitch((sid, pid)) else []
        if first_s and first_p:
            text = f"{snote(sid, attrs)}-note({lines.notes[pid]})."
        elif first_p:
            text = f"virtualSnote({sid},[{','.join(attrs)}])-note({lines.notes[pid]})."
        elif first_s:
            text = f"{snote(sid, attrs)}-virtualPnote({pid},)."
        else:
            text = f"virtualSnote({sid},[{','.join(attrs)}])-virtualPnote({pid},)."
        if not (first_s and first_p):
            virtual.add((sid, pid))
        seen_s.add(sid)
        seen_p.add(pid)
        out_lines.append((note_time(pid), text))
    for sid in _deletions(project, omitted, lines.in_file):
        extra = ["voice_overlap"] if sid in overlaps else []
        out_lines.append((score_time(sid), f"{snote(sid, extra)}-deletion."))
    for pid in perf.ids:
        pid = str(pid)
        if not al.by_perf.get(pid):
            out_lines.append((note_time(pid), f"insertion-note({lines.notes[pid]})."))

    def beats(o):
        return ",".join(f"{o[k]:.4f}" for k in ("start_in_beats_unfolded", "end_in_beats_unfolded",
                                                 "start_in_beats_original", "end_in_beats_original"))
    out = _with_info(lines.header, info)
    out += [f"omittedSection({o['id']},{beats(o)},[{','.join(o['section_attr_list'])}])." for o in omitted]
    out += [f"section({s['id']},{beats(s)},{s['start_in_perf_time']},{s['end_in_perf_time']},"
            f"[{','.join(s['section_attr_list'])}])." for s in sections]
    # Lines the file had stay where they were; new ones go in by time, before
    # the first kept line that comes later.
    kept = sorted((lines.order[text], key, text) for key, text in out_lines if text in lines.order)
    placed = [(index, 0, key, text) for index, key, text in kept]
    for key, text in sorted((key, text) for key, text in out_lines if text not in lines.order):
        later = next((index for index, k, _t in kept if k > key), len(lines.order))
        placed.append((later - 0.5, 1, key, text))
    out += [text for *_sort, text in sorted(placed)]
    out += lines.trailer
    return "\n".join(out) + "\n", virtual


def _with_info(header: list, info: dict) -> list:
    """The header lines with the info lines info sets, such as performer:
    replaced where the header has them, and added after its info lines where
    it doesn't."""
    out, done = [], set()
    for line in header:
        found = re.match(r"^info\(([^,]+),", line)
        if found and found.group(1) in info:
            line = f"info({found.group(1)},{info[found.group(1)]})."
            done.add(found.group(1))
        out.append(line)
    last = max((n for n, line in enumerate(out) if line.startswith("info(")), default=-1)
    missing = [f"info({key},{value})." for key, value in info.items() if key not in done]
    return out[:last + 1] + missing + out[last + 1:]


def _whole_times(score) -> None:
    """Make the score's times whole numbers of divisions where they're floats.

    A score partitura 1.9 builds from a .match file can have a time such as
    90720.0, and its save_match then fails on Fraction(90720.0, ...) ("both
    arguments should be Rational instances"). The value stays the same."""
    parts = list(getattr(score, "parts", None) or [score])
    for part in parts:
        for point in getattr(part, "_points", ()):
            if isinstance(point.t, float) and float(point.t).is_integer():
                point.t = int(point.t)


def match_export_names(project: Project) -> dict:
    """What exporting a .match file suggests: the folder to make, the file's
    name and the three info lines every export has. A file opened as
    p1200811001rachmaop30m1mi_alignment.match goes into a folder
    p1200811001rachmaop30m1mi, with midiFileName p1200811001rachmaop30m1mi.mid
    and performer p1; a new alignment is named after its MIDI file. Values the
    file has (not "-") are kept, and scoreFileName is the MusicXML's name."""
    original = project.sources.get("original", "")
    if original.lower().endswith(".match"):
        file = Path(original).name
        base = file[:-len(".match")]
        base = base[:-len("_alignment")] if base.endswith("_alignment") else base
        midi = f"{base}.mid"
    else:
        performance = Path(project.sources.get("performance") or project.name)
        base, midi = performance.stem, performance.name
        file = f"{base}_alignment.match"
    info = project.match_header.get("info", {})

    def kept(key, default):
        value = str(info.get(key, "")).strip()
        return value if value and value != "-" else default
    score = project.sources.get("score")
    return {"folder": base, "file": file,
            "scoreFileName": kept("scoreFileName", Path(score).name if score else "-"),
            "midiFileName": kept("midiFileName", midi),
            "performer": kept("performer", base[:2] or "-")}


def export_project(project: Project, folder) -> Path:
    """The final save as Parangonada CSV files: write the finished work into folder.

    The folder gets the five Parangonada CSV files, project.json, and
    ornaments.json, anchors.json and comments.json if there are any, so that
    opening it brings everything back. project.json also records when it was
    exported and from where. A .match file is the other export (export_match).
    The folders the project was opened from are refused, so the original files
    stay untouched. Returns the folder.
    """
    folder = Path(folder)
    save_parangonada(project, folder)
    manifest = project_json(project, exported=datetime.now().isoformat(timespec="seconds"),
                            opened_from=str(project.source) if project.source else None)
    _write_files(folder, {PROJECT_FILE: manifest.encode("utf-8")})
    return folder


def can_export_match(project: Project) -> bool:
    """Whether the project has the full score and performance a .match file needs.
    A project opened from Parangonada CSV files has only their note lists."""
    return project.score_obj is not None and project.perf_obj is not None


def export_match(project: Project, path, info: Optional[dict] = None) -> set[Link]:
    """The final save as a .match file at path (see save_match), with the
    ornaments and comments in the JSON files beside it (match_side_files),
    each written only if it has something in it; one left from before is
    removed. Each file is replaced in one step, and the folders the project was
    opened from are refused. Returns the links in virtual lines. Anchors have
    no place in it."""
    path = Path(path)
    _refuse_source_folder(project, path.parent)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=path.parent) as tmp:
        staged = Path(tmp) / path.name
        virtual = save_match(project, staged, info)
        os.replace(staged, path)
    ornaments_path, comments_path = match_side_files(path)
    files = {}
    for side, content, items in ((ornaments_path, ornaments_json, project.ornaments),
                                 (comments_path, comments_json, project.comments)):
        if items:
            files[side.name] = content(items).encode("utf-8")
        elif side.exists():
            side.unlink()
    _write_files(path.parent, files)
    return virtual
