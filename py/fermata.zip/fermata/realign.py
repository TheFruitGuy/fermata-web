"""Aligning a piece, or realigning part of it, with parangonar's matchers. No Qt imports.

new_alignment() aligns a whole piece, for a new alignment from a score and a
performance. Realigning has two steps, so that the slow one can run in a
worker thread:

* plan() turns the selection into the notes to realign and the links their
  new links replace. It's quick, and it refuses selections it can't use with
  a message that says what to select instead.
* run() calls the matcher. It only reads the project, and the caller applies
  the result as one undo step.

Which notes are realigned
-------------------------
* One note selected in each roll: from those two notes to the end. The two
  notes are linked, and every later note in both rolls is realigned.
* At least min_notes selected notes (MIN_NOTES unless the Realign group sets
  another number): those notes. Links are many-to-many: only the selected
  notes' old links are replaced, the performance notes' when there are any, so
  the notes they're aligned with keep their links elsewhere, as the score notes
  of a passage played twice need. If they're all in one
  roll, the notes in the other roll are found between the nearest links
  before and after the selection, in the same pitch range, leaving out notes
  linked to those links' notes or to unselected notes between them. Links
  farther away, such as to the other time of a passage played twice, don't
  count.

Anchors
-------
Anchors are links the user has pinned. Realigning never removes them and
never realigns their performance notes. Their score notes aren't realigned
either, except with performance notes selected: a score note anchored to a
performance note away from the passage (beyond the nearest links before and
after it), such as in the first time of a passage played again, can get a
partner among them as well. Anchors in the passage (whose notes are each in it
or within its time span in their roll) split it into parts:
Dual DTW and Automatic align the parts one by one, and Anchor points passes
them to parangonar's AnchorPointNoteMatcher, together with the links just
before and after the passage. Outer HMM takes the whole passage at once, and
drops the links it makes across an anchor.

Outer HMM
---------
parangonar's SwitchingOuterHMMMatcher follows a rehearsal through the score,
with its skips, repeats and new starts anywhere. Its links to the other
passages of the score with the same notes are off (consider_parallel_sections),
so each performance note gets one place. It takes the score as a partitura
part, never a note list, so it always works through the whole score:
realigning gives it the passage's performance notes, after the LEAD_IN notes
played just before them, which it needs to find its place, and keeps only its
links between the passage's notes. Working through the score takes most of the
time on a big score, so what it finds there is kept in a cache folder, if the
caller gives one and it can be written, and a second run on the same score
skips it. A new alignment takes the sections it finds as well.
"""
from __future__ import annotations

import functools
import hashlib
import os
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
import numpy.lib.recfunctions as rfn
import parangonar as pa
import partitura as pt

try:
    from parangonar.mismatch import switching_outerhmm_matcher as _hmm_matcher
    from parangonar.mismatch import switching_outerhmm_utils as _hmm_utils
    from parangonar.prob import switching_outerhmm as _hmm
except ImportError:   # parangonar before 3.4, as a FERMATA updated with git pull alone has
    _hmm_matcher = _hmm_utils = _hmm = None

from .annotations import SECTION_COLOURS
from .model import (Link, PerformanceFile, Project, ScoreFile, Section, match_clock, new_project,
                    with_pedal)

# Outer HMM prints what it's doing and draws a progress bar on stderr, from the
# worker thread, where there may be no terminal at all; FERMATA shows its own.
# Silenced here, once: swapping sys.stdout from a thread would swap it for all.
if _hmm is not None:
    for _module in (_hmm_matcher, _hmm_utils, _hmm):
        _module.print = lambda *args, **kwargs: None
    _hmm.tqdm = functools.partial(_hmm.tqdm, disable=True)
OUTER_HMM_MISSING = ("Outer HMM needs parangonar 3.4 or newer. In FERMATA's folder, run "
                     "pip install -e . again, and restart FERMATA.")

MIN_NOTES = 3         # the fewest notes a selection needs, unless the Realign group says otherwise
CHORD_WINDOW = 0.15   # seconds: how much earlier than an anchor a note of its chord can be played
MIN_PART = 4          # parts with fewer notes in a roll are paired by pitch instead

# key: (name in the interface, tooltip)
METHODS = {
    "dualdtw": ("Dual DTW",
                "parangonar's DualDTWNoteMatcher: aligns the onsets first, then the notes. "
                "Copes well with extra and missing notes."),
    "automatic": ("Automatic",
                  "parangonar's AutomaticNoteMatcher: time warping over the passage, then "
                  "note matching."),
    "outerhmm": ("Outer HMM",
                 "parangonar's SwitchingOuterHMMMatcher, for rehearsals: follows the "
                 "performance through the whole score, with skips, repeats and new starts "
                 "anywhere. A new alignment gets the sections it finds."),
    "anchors": ("Anchor points",
                "parangonar's AnchorPointNoteMatcher, guided by your anchors and by the "
                "links just before and after the passage."),
}
DEFAULT_METHOD = "dualdtw"
NEW_METHODS = tuple(key for key in METHODS if key != "anchors")   # a new alignment has no anchors
CACHED_SCORES = 40    # Outer HMM's cache keeps what it found in this many scores, the latest
LEAD_IN = 16          # performance notes played before a passage that Outer HMM gets first


def _plural(n: int, word: str) -> str:
    return f"{n} {word}{'' if n == 1 else 's'}"


class PlanError(ValueError):
    """The selection can't be realigned. The message says why and what to select."""


@dataclass(frozen=True)
class Plan:
    method: str
    perf_ids: frozenset      # the notes the matcher aligns (anchored notes are left out,
    score_ids: frozenset     # except score notes anchored outside a performance passage)
    remove: frozenset        # the links the new links replace
    start: Optional[Link]    # "from here to the end": this pair is linked
    boundaries: np.ndarray   # (n, 2) score beat and performance second of the anchors inside
    times: np.ndarray        # (m, 2) anchor points for AnchorPointNoteMatcher, first to last
    ignored_anchors: int     # anchors that cross other anchors
    summary: str             # what gets realigned, in words

    @property
    def name(self) -> str:
        return METHODS[self.method][0]


@dataclass(frozen=True)
class Result:
    plan: Plan
    links: frozenset         # the passage's new links
    paired_by_pitch: int     # parts too short for the matcher, or where it failed
    error: str = ""          # the matcher's first error, if it failed on a part


# --------------------------------------------------------------------------- planning

def plan(project: Project, sel_perf, sel_score, method: str = DEFAULT_METHOD,
         min_notes: int = MIN_NOTES) -> Plan:
    """What realigning the selected notes with method would do. A selection
    needs at least min_notes notes, or one note in each roll. Raises PlanError."""
    if method not in METHODS:
        raise ValueError(f"unknown method {method!r}")
    if method == "outerhmm" and _hmm is None:
        raise PlanError(OUTER_HMM_MISSING)
    if method == "outerhmm" and project.score_obj is None:
        raise PlanError("Outer HMM needs the MusicXML score in one part, which an alignment "
                        "from Parangonada files doesn't have, nor one whose score parts "
                        "couldn't be merged. Choose Dual DTW, Automatic or Anchor points.")
    perf, score, al = project.performance, project.score, project.alignment
    sel_perf = {str(i) for i in sel_perf if str(i) in perf.row}
    sel_score = {str(i) for i in sel_score if str(i) in score.row}
    anchors = project.anchors & al.links
    start = None

    if len(sel_perf) == 1 and len(sel_score) == 1:
        (pid,), (sid,) = sel_perf, sel_score
        t_perf, t_score = perf.onset[perf.row[pid]], score.onset[score.row[sid]]
        score_ids = set(score.ids[score.onset >= t_score])
        perf_ids = set(perf.ids[perf.onset >= t_perf])
        # Notes of the chord played before the selected note, unless they're
        # linked to earlier score notes.
        chord = Counter(score.pitch[np.isclose(score.onset, t_score)].tolist())
        chord[int(score.pitch[score.row[sid]])] -= 1
        early = perf.ids[_played_early(perf.onset, perf.pitch, t_perf, chord, CHORD_WINDOW)]
        perf_ids |= {p for p in early if al.by_perf.get(p, set()) <= score_ids}
        start = (sid, pid)
        summary = f"from performance note {pid} and score note {sid} to the end"
    else:
        if len(sel_perf) + len(sel_score) < min_notes:
            raise PlanError(f"Select at least {min_notes} notes to realign them, or one note "
                            "in each roll to realign from there to the end.")
        perf_ids, score_ids = set(sel_perf), set(sel_score)
        if not score_ids:
            score_ids = _matching_notes(project, perf_ids, "perf")
        elif not perf_ids:
            perf_ids = _matching_notes(project, score_ids, "score")
        summary = (f"{_plural(len(perf_ids), 'performance note')} and "
                   f"{_plural(len(score_ids), 'score note')}")

    fixed_perf = {p for _, p in anchors} | ({start[1]} if start else set())
    fixed_score = {s for s, _ in anchors} | ({start[0]} if start else set())
    if sel_perf and not start:
        # Only the performance notes' links are replaced, so a score note
        # anchored to another pass can get a partner in this one as well.
        # Anchors next to the passage keep their score notes.
        lo, hi = _played_next_to(project, perf_ids)
        fixed_score = {s for s, p in anchors if p in perf_ids or lo <= perf.onset[perf.row[p]] <= hi}
    match_perf, match_score = perf_ids - fixed_perf, score_ids - fixed_score
    if not match_score:
        raise PlanError("There are no score notes to align these notes with. "
                        "Select the matching score notes as well.")
    if not match_perf:
        raise PlanError("There are no performance notes to align these notes with. "
                        "Select the matching performance notes as well.")
    # Many-to-many: only the links of the notes you selected are replaced.
    # With performance notes selected, the score notes keep their links to
    # other performance notes, so a passage played again can be linked as well
    # as the first time. With only score notes selected, the performance notes
    # found keep theirs. From here to the end replaces the links of both.
    if start:
        remove = al.links_of(match_score, match_perf)
    elif sel_perf:
        remove = al.links_of((), match_perf)
    else:
        remove = al.links_of(match_score, ())
    remove -= anchors | ({start} if start else set())

    boundaries, ignored = _boundaries(_anchors_in(project, anchors, perf_ids, score_ids))
    s_rows = np.array([score.row[i] for i in match_score])
    p_rows = np.array([perf.row[i] for i in match_perf])
    first_onsets = (float(score.onset[s_rows].min()), float(perf.onset[p_rows].min()))
    last_onsets = (float(score.onset[s_rows].max()), float(perf.onset[p_rows].max()))
    before, after = _links_around(project, perf_ids, score_ids, first_onsets, last_onsets)
    if start:
        before = (float(t_score), float(t_perf))
    end = (float(score.offset[s_rows].max()), float(perf.offset[p_rows].max()))
    times = _anchor_times(before or first_onsets, boundaries, after or end,
                          first_onsets, last_onsets)
    return Plan(method, frozenset(match_perf), frozenset(match_score), frozenset(remove),
                start, boundaries, times, ignored, summary)


def _matching_notes(project: Project, ids: set, kind: str) -> set:
    """The notes in the other roll that go with a selection in one roll.

    They lie between the partners of the nearest linked notes before and after
    the selection, in the selection's pitch range. Notes linked to those two
    notes, or to unselected notes between them, are left out: they belong to
    those notes. Links farther away, such as to the other time of a passage
    played twice, don't count. A performance note linked to several places in
    the score, as in an Outer HMM alignment from FERMATA 0.1.11, which linked a
    note of a passage the score has twice to both, counts with the place
    nearest that of the next linked note out with one partner: where the
    performer was.
    """
    perf, score, al = project.performance, project.score, project.alignment
    if kind == "perf":
        src, dst, to_dst, to_src = perf, score, al.by_perf, al.by_score
    else:
        src, dst, to_dst, to_src = score, perf, al.by_score, al.by_perf
    rows = np.sort(np.array([src.row[i] for i in ids]))
    lo_pitch, hi_pitch = int(src.pitch[rows].min()), int(src.pitch[rows].max())
    def partner(r, farther, pick):
        """The onset of note r's partner: the place nearest the next linked note
        out with one partner (farther) for a performance note linked to several
        places, or else the latest or earliest (pick)."""
        onsets = [dst.onset[dst.row[d]] for d in to_dst[src.ids[r]]]
        if kind == "perf" and len(onsets) > 1:
            for q in farther:
                there = to_dst.get(src.ids[q], ())
                if len(there) == 1:
                    (d,) = there
                    return min(onsets, key=lambda onset: abs(onset - dst.onset[dst.row[d]]))
        return pick(onsets)

    before, after = -np.inf, np.inf       # the partners' onsets, in the other roll
    near_from, near_to = -np.inf, np.inf  # the linked notes' own onsets, with their chords
    spread = CHORD_WINDOW if kind == "perf" else 0.0   # a chord's notes are rarely played together
    for r in range(rows[0] - 1, -1, -1):
        if to_dst.get(src.ids[r]):
            before = partner(r, range(r - 1, -1, -1), max)
            near_from = src.onset[r] - spread
            break
    for r in range(rows[-1] + 1, len(src)):
        if to_dst.get(src.ids[r]):
            after = partner(r, range(r + 1, len(src)), min)
            near_to = src.onset[r] + spread
            break
    lo = np.searchsorted(dst.onset, before, side="left")
    hi = np.searchsorted(dst.onset, after, side="right")

    def taken(d):
        return any(near_from <= src.onset[src.row[o]] <= near_to
                   for o in to_src.get(d, set()) - ids)

    return {dst.ids[r] for r in range(lo, hi)
            if lo_pitch <= dst.pitch[r] <= hi_pitch and not taken(dst.ids[r])}


def _anchors_in(project: Project, anchors, perf_ids, score_ids) -> list[tuple[float, float]]:
    """(beat, second) of the anchors that belong to the passage: those whose
    notes are each in it or within its time span in their roll, such as an
    anchor in the other hand. An anchor with only one note in the passage,
    such as one on the first time of a passage played twice, doesn't count."""
    perf, score = project.performance, project.score
    s_on = score.onset[[score.row[i] for i in score_ids]]
    p_on = perf.onset[[perf.row[i] for i in perf_ids]]
    out = []
    for s, p in anchors:
        ts, tp = float(score.onset[score.row[s]]), float(perf.onset[perf.row[p]])
        in_score = s in score_ids or s_on.min() <= ts <= s_on.max()
        in_perf = p in perf_ids or p_on.min() - CHORD_WINDOW <= tp <= p_on.max() + CHORD_WINDOW
        if in_score and in_perf:
            out.append((ts, tp))
    return out


def _played_next_to(project: Project, perf_ids) -> tuple[float, float]:
    """The seconds from the nearest linked performance note before the passage
    perf_ids to the nearest one after it, those notes included, give or take a
    chord. Links farther away, such as to the other time of a passage played
    twice, are someone else's."""
    perf, al = project.performance, project.alignment
    rows = sorted(perf.row[i] for i in perf_ids)
    lo, hi = -np.inf, np.inf
    for r in range(rows[0] - 1, -1, -1):
        if al.by_perf.get(perf.ids[r]):
            lo = float(perf.onset[r])
            break
    for r in range(rows[-1] + 1, len(perf)):
        if al.by_perf.get(perf.ids[r]):
            hi = float(perf.onset[r])
            break
    return lo - CHORD_WINDOW, hi + CHORD_WINDOW


def _boundaries(points) -> tuple[np.ndarray, int]:
    """Anchor times sorted by score time, with the anchors of one chord merged
    and anchors that cross others left out (the longest run that goes forward
    in both rolls is kept). Returns the times and the number left out."""
    by_beat: dict[float, float] = {}
    for s, p in points:
        by_beat[s] = min(p, by_beat.get(s, np.inf))
    beats = sorted(by_beat)
    secs = [by_beat[b] for b in beats]
    n = len(beats)
    if n == 0:
        return np.zeros((0, 2)), 0
    best, prev = [1] * n, [-1] * n       # longest increasing run of seconds
    for i in range(n):
        for j in range(i):
            if secs[j] < secs[i] and best[j] + 1 > best[i]:
                best[i], prev[i] = best[j] + 1, j
    i = int(np.argmax(best))
    keep = []
    while i >= 0:
        keep.append(i)
        i = prev[i]
    keep.reverse()
    return np.array([[beats[i], secs[i]] for i in keep]), n - len(keep)


def _links_around(project: Project, perf_ids, score_ids, first_onsets, last_onsets):
    """The kept links nearest before and after the passage, as (beat, second)
    pairs, or None where there is no such link."""
    perf, score = project.performance, project.score
    before = after = None
    for s, p in project.alignment.links:
        if s in score_ids or p in perf_ids:
            continue
        ts, tp = float(score.onset[score.row[s]]), float(perf.onset[perf.row[p]])
        if ts <= first_onsets[0] and tp <= first_onsets[1] and (before is None or (ts, tp) > before):
            before = (ts, tp)
        if ts >= last_onsets[0] and tp >= last_onsets[1] and (after is None or (ts, tp) < after):
            after = (ts, tp)
    return before, after


def _anchor_times(first, boundaries, last, first_onsets, last_onsets) -> np.ndarray:
    """First point, inner anchors, last point, rising in both rolls and
    enclosing every onset of the passage, as AnchorPointNoteMatcher needs."""
    first = (min(first[0], first_onsets[0]), min(first[1], first_onsets[1]))
    last = (max(last[0], last_onsets[0]), max(last[1], last_onsets[1]))
    last = (max(last[0], first[0] + 1.0), max(last[1], first[1] + 0.5))
    inner = [b for b in boundaries.tolist()
             if first[0] < b[0] < last[0] and first[1] < b[1] < last[1]]
    return np.array([first, *inner, last], dtype=float)


# --------------------------------------------------------------------------- a new alignment

def new_alignment(score: ScoreFile, performance: PerformanceFile,
                  method: str = DEFAULT_METHOD, cache: Optional[Path] = None) -> Project:
    """Align a whole piece with method, one of NEW_METHODS: a new project.

    It takes seconds for a short piece and minutes for a long one, and only
    reads the notes, so it can run in a worker thread. The alignment is the
    project's first, so its zalign.csv keeps it. Outer HMM keeps what it found
    in the score in the folder cache, if given, and the project gets the
    sections it finds.
    """
    if method not in NEW_METHODS:
        raise ValueError(f"{method!r} can't make a new alignment")
    if method == "outerhmm":
        if _hmm is None:
            raise ValueError(OUTER_HMM_MISSING)
        if score.part is None:
            raise ValueError(f"The parts of {score.path.name} couldn't be merged into one, "
                             "which Outer HMM needs. Choose Dual DTW or Automatic.")
        entries, lines = _outer_hmm(score.part, score.notes, performance.performance, cache)
        return new_project(score, performance, _links(entries), method,
                           sections=_sections(lines, performance.performance))
    score_notes = _by_onset(score.notes, "onset_beat")
    # As long as they sounded, with the pedal, as partitura gives them the matchers.
    perf_notes = _by_onset(with_pedal(performance.notes, performance.sustained), "onset_sec")
    return new_project(score, performance, _links(_matcher(method)(score_notes, perf_notes)), method)


# --------------------------------------------------------------------------- running

def run(project: Project, plan: Plan, cache: Optional[Path] = None) -> Result:
    """Align the plan's notes. Only reads the project, so it can run in a
    worker thread. Outer HMM keeps what it found in the score in the folder
    cache, if given."""
    score_notes = _subset(project.score_note_array, plan.score_ids, "onset_beat")
    perf_notes = _subset(project.sounding_notes(), plan.perf_ids, "onset_sec")
    paired, error = 0, ""
    if plan.method == "anchors":
        links = _links(pa.AnchorPointNoteMatcher()(score_notes, perf_notes, plan.times))
    elif plan.method == "outerhmm":
        entries, _lines = _outer_hmm(project.score_obj, project.score_note_array,
                                     _performance(project, _lead_in(project, perf_notes)), cache)
        # The anchors split the passage: a link across one is dropped.
        s_part, p_part = _parts(score_notes, perf_notes, plan.boundaries)
        s_of = dict(zip(score_notes["id"].astype(str).tolist(), s_part.tolist()))
        p_of = dict(zip(perf_notes["id"].astype(str).tolist(), p_part.tolist()))
        links = {(s, p) for s, p in _links(entries)
                 if s in s_of and p in p_of and s_of[s] == p_of[p]}
    else:
        matcher = _matcher(plan.method)
        links = set()
        s_part, p_part = _parts(score_notes, perf_notes, plan.boundaries)
        for k in range(len(plan.boundaries) + 1):
            s, p = score_notes[s_part == k], perf_notes[p_part == k]
            if not len(s) or not len(p):
                continue
            if min(len(s), len(p)) < MIN_PART:
                links |= _pair_by_pitch(s, p)
                paired += 1
                continue
            try:
                links |= _links(matcher(s, p))
            except Exception as exc:  # a matcher that fails on a part shouldn't lose the rest
                links |= _pair_by_pitch(s, p)
                paired += 1
                error = error or f"{type(exc).__name__}: {exc}"
    links = {(s, p) for s, p in links if s in plan.score_ids and p in plan.perf_ids}
    if plan.start:
        links.add(plan.start)
    return Result(plan, frozenset(links), paired, error)


def _played_early(onsets, pitches, anchor_time, chord: Counter, window) -> np.ndarray:
    """Indices of the notes played up to window before anchor_time that belong
    to the chord, closest to the anchor first.

    Per pitch, only as many as the chord still lacks after the notes of that
    pitch played up to window after the anchor: a note of the same pitch just
    before the anchor is more often the end of the previous beat.
    """
    before = np.flatnonzero((onsets >= anchor_time - window) & (onsets < anchor_time))
    after = np.flatnonzero((onsets >= anchor_time) & (onsets <= anchor_time + window))
    out = []
    for pitch, count in chord.items():
        needed = count - int(np.count_nonzero(pitches[after] == pitch))
        if needed > 0:
            same = before[pitches[before] == pitch]
            out.extend(same[np.argsort(-onsets[same], kind="stable")][:needed].tolist())
    return np.array(out, dtype=int)


def _parts(score_notes, perf_notes, boundaries) -> tuple[np.ndarray, np.ndarray]:
    """The part of every score and performance note, split at the anchors.

    Score notes at an anchor's beat go with the anchor. So do performance
    notes of the anchor's chord that were played just before the anchor's
    own note, which is common: a chord's notes are rarely played together.
    """
    s_on, p_on = score_notes["onset_beat"], perf_notes["onset_sec"]
    s_part = np.searchsorted(boundaries[:, 0], s_on, side="right")
    p_part = np.searchsorted(boundaries[:, 1], p_on, side="right")
    pitches = perf_notes["pitch"].astype(int)
    for k, (beat, sec) in enumerate(boundaries.tolist()):
        chord = Counter(score_notes["pitch"][np.isclose(s_on, beat)].astype(int).tolist())
        window = CHORD_WINDOW if k == 0 else min(CHORD_WINDOW, (sec - boundaries[k - 1, 1]) / 2)
        p_part[_played_early(p_on, pitches, sec, chord, window)] = k + 1
    return s_part, p_part


def _matcher(method: str):
    if method == "dualdtw":
        matcher = pa.DualDTWNoteMatcher()
        return lambda score_notes, perf_notes: matcher(_with_grace(score_notes), perf_notes)
    if method == "automatic":
        return pa.AutomaticNoteMatcher()
    raise ValueError(f"{method!r} doesn't align part by part")


def _outer_hmm(part, score_notes: np.ndarray, performance, cache: Optional[Path]):
    """parangonar's SwitchingOuterHMMMatcher on the score as written, a partitura
    Part or Score, and a partitura Performance: its alignment and its section
    lines. What it works out in the score is kept in the folder cache, if
    given and it can be written, under a name made from the score's notes
    (score_notes) and parangonar's version. The cache only saves time: if it
    can't be written to, the matcher runs again without it."""
    score = part if hasattr(part, "parts") else pt.score.Score(partlist=[part])
    cache = _writable(cache)
    key = _score_key(score_notes) if cache else ""
    options = {"score_metadata_folder_path": str(cache), "score_identifier": key} if cache else {}
    matcher = pa.SwitchingOuterHMMMatcher(unfold_score=False, consider_parallel_sections=False,
                                          **options)
    try:
        entries = matcher(score, performance)
    except OSError:
        if not cache:
            raise
        cache = None   # a full disk, say: once more without the cache
        matcher = pa.SwitchingOuterHMMMatcher(unfold_score=False,
                                              consider_parallel_sections=False)
        entries = matcher(score, performance)
    if cache:
        _prune(cache, key)
    hmm = matcher.switchSnapOuterHMM
    lines = list(hmm.sections)
    last = _last_run(hmm.snapped_alignment, hmm.performance_note_array, hmm.reference_features,
                     lines)
    return entries, lines + ([last] if last else [])


def _writable(cache: Optional[Path]) -> Optional[Path]:
    """The cache folder, made if need be, or None if it can't be written."""
    if cache is None:
        return None
    try:
        Path(cache).mkdir(parents=True, exist_ok=True)
    except OSError:
        return None
    return Path(cache) if os.access(cache, os.W_OK) else None


def _last_run(alignment: list[dict], perf_notes: np.ndarray, score_notes: np.ndarray,
              sections: list[dict]):
    """The section line parangonar 3.4.0 leaves out: it makes a section of a
    run through the score when a jump ends it, so the run the performance ends
    with has none, nor has a performance played straight through. It starts
    after the last note of the last section and ends with the performance, and
    is a "rehearsal_repetition" if most of its score notes were played before,
    as parangonar has it. Its beats go from the onset of the first score note
    it plays to the offset of the last, in the alignment the sections come
    from, whose notes are in one place each. None if no note after that is
    linked."""
    ticks = {str(n["id"]): (int(n["onset_tick"]), int(n["onset_tick"] + n["duration_tick"]))
             for n in perf_notes}
    lines = [l for l in alignment if l["label"] != "deletion" and str(l["performance_id"]) in ticks]
    after = 0
    if sections:
        start, end = max((int(l["start_in_perf_time"]), int(l["end_in_perf_time"]))
                         for l in sections)
        ends = [i for i, l in enumerate(lines)
                if ticks[str(l["performance_id"])][0] >= start
                and ticks[str(l["performance_id"])][1] == end]
        if not ends:
            return None
        after = ends[-1] + 1
    seen = {str(l["score_id"]) for l in lines[:after] if l["label"] == "match"}
    run = lines[after:]
    matched = [i for i, l in enumerate(run) if l["label"] == "match"]
    if not matched:
        return None
    again = 0
    for l in run:
        if l["label"] == "match":
            again += str(l["score_id"]) in seen
            seen.add(str(l["score_id"]))
    first = ticks[str(run[matched[0]]["performance_id"])][0]
    last = max(ticks[str(l["performance_id"])][1] for l in run[matched[0]:])
    attribute = ("rehearsal_repetition" if again > len(matched) - again
                 else "first_rehearsal_run_of_section")
    beats = {str(n["id"]): (float(n["onset_beat"]), float(n["onset_beat"] + n["duration_beat"]))
             for n in score_notes}
    start = beats.get(str(run[matched[0]]["score_id"]), (0.0, 0.0))[0]
    end = beats.get(str(run[matched[-1]]["score_id"]), (0.0, 0.0))[1]
    return {"id": f"s{len(sections) + 1}",
            "start_in_beats_unfolded": start, "end_in_beats_unfolded": end,
            "start_in_beats_original": start, "end_in_beats_original": end,
            "start_in_perf_time": first, "end_in_perf_time": last,
            "section_attr_list": [attribute]}


def _score_key(notes: np.ndarray) -> str:
    """A name for a score's entry in Outer HMM's cache: the same notes give the
    same name. parangonar's version is in it, as a new version may keep
    something else there. Letters and digits only, as parangonar reads the
    name up to the first dot or "_metadata"."""
    digest = hashlib.sha1(pa.__version__.encode())
    digest.update("\n".join(map(str, notes["id"])).encode())
    for field in ("pitch", "onset_beat", "duration_beat"):
        digest.update(np.ascontiguousarray(notes[field], dtype=float).tobytes())
    return digest.hexdigest()[:24]


def _prune(cache: Path, key: str):
    """Mark the score's entry in the cache as just used, and keep only the
    CACHED_SCORES entries used last. Another FERMATA may prune at the same
    time, and a cache that can't be changed stays as it is."""
    def used_at(entry: Path) -> float:
        try:
            return entry.stat().st_mtime
        except OSError:   # just deleted by another FERMATA
            return 0.0
    try:
        used = cache / f"{key}_metadata.npz"
        if used.exists():
            used.touch()   # parangonar only reads it, which doesn't count as used
        entries = sorted(cache.glob("*_metadata.npz"), key=used_at, reverse=True)
        for old in entries[CACHED_SCORES:]:
            old.unlink(missing_ok=True)
    except OSError:
        pass


def _lead_in(project: Project, perf_notes: np.ndarray) -> np.ndarray:
    """The passage with the LEAD_IN notes played just before it first. Outer
    HMM doesn't know where in the score a passage starts and needs a few notes
    to find it; their links are dropped."""
    pna = project.sounding_notes()
    before = np.flatnonzero(pna["onset_sec"] < perf_notes["onset_sec"].min())
    before = before[np.argsort(pna["onset_sec"][before], kind="stable")]
    lead_in = before[len(before) - LEAD_IN:] if LEAD_IN else before[:0]
    return _by_onset(np.concatenate([pna[lead_in], perf_notes]), "onset_sec")


def _performance(project: Project, perf_notes: np.ndarray):
    """The notes to realign as the partitura Performance Outer HMM takes, with
    the performance's MIDI clock. Built note by note: partitura's
    from_note_array renames the notes when there's only one."""
    names = perf_notes.dtype.names
    notes = [{"id": str(n["id"]), "midi_pitch": int(n["pitch"]),
              "note_on": float(n["onset_sec"]),
              "note_off": float(n["onset_sec"] + n["duration_sec"]),
              "sound_off": float(n["onset_sec"] + n["duration_sec"]),
              "track": int(n["track"]) if "track" in names else 0,
              "channel": int(n["channel"]) if "channel" in names else 1,
              "velocity": int(n["velocity"]) if "velocity" in names else 64}
             for n in perf_notes]
    parts = getattr(project.perf_obj, "performedparts", None)
    clock = {"ppq": parts[0].ppq, "mpq": parts[0].mpq} if parts else {}
    part = pt.performance.PerformedPart(notes, **clock)
    return pt.performance.Performance(performedparts=[part])


def _sections(lines: list[dict], performance) -> list[Section]:
    """Outer HMM's section lines as sections, one for each line, named after
    its id, with its keywords, in the colours a .match file's sections get.
    Their MIDI ticks, of a key going down or up, become seconds through the
    notes' own ticks and seconds, which hold where the tempo changes. Like a
    .match file's sections, they keep their lines' beats, which exporting
    writes back while a section's first pass is as it was, as the matcher
    made them."""
    notes = [n for part in performance.performedparts for n in part.notes]
    ticks = np.array([n[f"note_{k}_tick"] for n in notes for k in ("on", "off")], float)
    seconds = np.array([n[f"note_{k}"] for n in notes for k in ("on", "off")], float)
    order = np.argsort(ticks, kind="stable")
    ticks, seconds = ticks[order], seconds[order]
    mpq, ppq = match_clock({})   # a new alignment's export clock
    colours = list(SECTION_COLOURS.values())
    out = []
    for n, line in enumerate(sorted(lines, key=lambda l: int(l["start_in_perf_time"]))):
        span = tuple(float(np.interp(float(line[key]), ticks, seconds))
                     for key in ("start_in_perf_time", "end_in_perf_time"))
        beats = tuple(float(line[f"{end}_in_beats_{kind}"])
                      for kind in ("unfolded", "original") for end in ("start", "end"))
        exported = tuple(int(round(t * ppq * 1e6 / mpq)) for t in span)
        out.append(Section(str(line["id"]), colours[n % len(colours)], span, (), str(line["id"]),
                           tuple(str(a) for a in line.get("section_attr_list") or ()),
                           beats + exported))
    return out


def _subset(note_array: np.ndarray, ids, onset_field: str) -> np.ndarray:
    return _by_onset(note_array[np.isin(note_array["id"].astype(str), list(ids))], onset_field)


def _by_onset(notes: np.ndarray, onset_field: str) -> np.ndarray:
    return notes[np.argsort(notes[onset_field], kind="stable")]


def _with_grace(score_notes: np.ndarray) -> np.ndarray:
    """DualDTWNoteMatcher needs an is_grace field, which note lists from
    Parangonada files and some scores don't have."""
    if "is_grace" in score_notes.dtype.names:
        return score_notes
    return rfn.append_fields(score_notes, "is_grace", np.zeros(len(score_notes), bool),
                             usemask=False)


def _links(entries) -> set:
    return {(str(e["score_id"]), str(e["performance_id"])) for e in entries
            if e.get("score_id") is not None and e.get("performance_id") is not None}


def _pair_by_pitch(score_notes: np.ndarray, perf_notes: np.ndarray) -> set:
    """Notes of the same pitch paired in time order, as linking a selection does."""
    by_pitch: dict[int, list[str]] = {}
    for note in score_notes:
        by_pitch.setdefault(int(note["pitch"]), []).append(str(note["id"]))
    links, used = set(), {}
    for note in perf_notes:
        pitch = int(note["pitch"])
        i = used.get(pitch, 0)
        if i < len(by_pitch.get(pitch, ())):
            links.add((by_pitch[pitch][i], str(note["id"])))
            used[pitch] = i + 1
    return links
