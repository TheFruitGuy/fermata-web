"""Backups of the work in progress, kept in a hidden folder.

FERMATA never writes to the files you open. Instead, each opened project gets
a session folder in FERMATA's data folder as soon as it changes, and after
every change the folder is brought up to date. It is a complete Parangonada
project, the same files an export writes, plus session.json, which records
where the work came from, whether it has been exported, and where each roll
was in the piece.

session.json's source is the file or folder the work was opened from; for a
new alignment, made from a score and a performance, its pair names both.

session.json's state is "open" while a FERMATA works on the session, "closed"
once it has ended, and "kept" when the work is saved for later: the next
FERMATA offers to continue it. Continuing starts a new session with a copy of
the work, and the old one is closed. Kept work is never pruned.

A lock file shows which sessions belong to a running FERMATA. A session whose
lock is free but which is still open with unexported changes was left behind
by a crash, and FERMATA offers to restore it.
"""
from __future__ import annotations

import json
import os
import shutil
import traceback
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable, Optional

import numpy as np
from PyQt6.QtCore import QLockFile

from . import __version__, model

SESSION_FILE = "session.json"
LOCK_FILE = "session.lock"
KEEP_DAYS = 14


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _write_json(path: Path, data: dict) -> None:
    staged = path.with_name(path.name + ".staged")
    staged.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    os.replace(staged, path)


def _read_json(path: Path) -> Optional[dict]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def _take_lock(folder: Path) -> Optional[QLockFile]:
    """The session's lock, or None if a running FERMATA holds it.

    A lock left behind by a crashed process is recognised by its process id
    and taken over; the lock's age is never a reason, because a session can
    stay open for hours.
    """
    lock = QLockFile(str(folder / LOCK_FILE))
    lock.setStaleLockTime(0)
    return lock if lock.tryLock(0) else None


def _path_key(path) -> Optional[str]:
    """path in a form that compares equal for the same file or folder."""
    if not path:
        return None
    try:
        return os.path.normcase(str(Path(path).expanduser().resolve()))
    except (OSError, RuntimeError, ValueError):
        return os.path.normcase(str(path))


class Cancelled(Exception):
    """The score asked for, to restore or continue work on a .match file, wasn't
    chosen: the work isn't opened now."""


class Session:
    """The backup of one opened project."""

    def __init__(self, root, project: model.Project):
        self.root = Path(root)
        self.project = project
        self.folder: Optional[Path] = None
        self._lock: Optional[QLockFile] = None
        self.info = {"format": 1, "fermata": __version__, "name": project.name,
                     "source": self._source(project),
                     "opened": _now(), "updated": None, "state": "open",
                     "unexported": False, "exported_to": None, "exported_at": None}
        if self._restores_from_pair(project):   # a new alignment: its score and performance
            self.info["pair"] = [str(path) for path in project.pair_files]

    def _restores_from_pair(self, project: model.Project) -> bool:
        """Whether this work is restored and found from a new alignment's two
        files: when it was made from them, or opened from a backup of such work.
        Work opened from an export folder is restored and found from that folder,
        as any folder is."""
        if project.pair:
            return True
        if not project.pair_files:
            return False
        return project.source is None or self._in_backups(project.source)

    def _source(self, project: model.Project) -> Optional[str]:
        """The file this work is restored and found from: the one it was opened
        from, or for work opened from a backup of work on a .match file (when the
        file or its score couldn't be found), that .match file, so that restoring
        or continuing it later tries the file and its score again."""
        if project.source is None:
            return None
        original = str(project.sources.get("original") or "")
        if original.lower().endswith(".match") and self._is_backup(project.source):
            return original
        return str(project.source)

    def _in_backups(self, path) -> bool:
        try:
            return self.root.resolve() in Path(path).resolve().parents
        except OSError:
            return False

    def _is_backup(self, path) -> bool:
        """Whether path is the folder of a backup, among the backups."""
        try:
            return self._in_backups(path) and (Path(path) / SESSION_FILE).is_file()
        except OSError:
            return False

    def backup(self, unexported: bool, view: Optional[dict] = None) -> None:
        """Bring the backup up to date. The folder is created on the first call.
        view is where the rolls are, to come back to them after a break."""
        if self.folder is None:
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            self.folder = self.root / f"{stamp}-{self.project.name}-{uuid.uuid4().hex[:6]}"
            self.folder.mkdir(parents=True)
            self._lock = _take_lock(self.folder)
            model.save_parangonada(self.project, self.folder)   # the complete project once
        else:
            model.save_work(self.project, self.folder)          # then only what edits change
        self.info.update(updated=_now(), unexported=unexported)
        if view is not None:
            self.info["view"] = view
        _write_json(self.folder / SESSION_FILE, self.info)

    def keep(self, unexported: bool, view: Optional[dict] = None) -> None:
        """Save the work for later: back it up now, and from now on this session
        ends as kept, so the next FERMATA offers to continue it. Kept at once
        rather than when the session ends, so that it's offered after a crash too."""
        self.info["state"] = "kept"
        self.backup(unexported, view)

    def carry_over(self, earlier: "Leftover") -> None:
        """Start as the continuation of earlier work: with its last export."""
        self.info["continues"] = earlier.folder.name
        if earlier.export_path is not None:
            self.info.update(exported_to=earlier.info["exported_to"],
                             exported_at=earlier.info.get("exported_at"))

    def exported(self, path: Path) -> None:
        """The work was exported to path: a folder of Parangonada CSV files, or a .match file."""
        self.info.update(unexported=False, exported_to=str(path), exported_at=_now())
        if self.folder is not None:
            _write_json(self.folder / SESSION_FILE, self.info)

    def close(self, keep: bool = False, view: Optional[dict] = None) -> None:
        """End the session normally. With keep, the work stays saved for later
        until it's continued; otherwise the backup is kept for KEEP_DAYS days."""
        try:
            if self.folder is not None:
                self.info["state"] = "kept" if keep else "closed"
                if view is not None:
                    self.info["view"] = view
                _write_json(self.folder / SESSION_FILE, self.info)
        finally:
            if self._lock is not None:
                self._lock.unlock()
                self._lock = None


@dataclass
class Leftover:
    """A session no running FERMATA holds: left behind by a crash with
    unexported changes, or saved for later."""
    folder: Path
    info: dict
    lock: QLockFile   # held while deciding, so no other FERMATA takes it too
    # Why restore opened the backup alone, without the .match file or the score
    # and MIDI file the work was on, so it can't be exported as .match: in words,
    # and with the error's traceback if there was one. "" if it didn't.
    not_reopened: str = ""

    @property
    def name(self) -> str:
        return self.info.get("name") or self.folder.name

    @property
    def opened_from(self) -> tuple[str, str]:
        """What the work was opened from, in words, and its files' paths: a
        .match file, Parangonada CSV files (a folder of them, also an export or
        a backup), or a new alignment's MusicXML score and MIDI file. ("", "")
        if it doesn't say."""
        pair, source = self.info.get("pair"), self.info.get("source")
        if pair:
            return "New alignment of a MusicXML score and a MIDI file", "\n".join(map(str, pair))
        if not source:
            return "", ""
        if str(source).lower().endswith(".match"):
            return "Opened from a .match file", str(source)
        return "Opened from Parangonada CSV files", str(source)

    @property
    def changed(self) -> str:
        """When the work last changed, as an ISO time, for sorting."""
        return self.info.get("updated") or self.info.get("opened") or ""

    @property
    def updated(self) -> str:
        try:
            return datetime.fromisoformat(self.changed).strftime("%d %B %Y at %H:%M")
        except (TypeError, ValueError):
            return "an unknown time"

    @property
    def export_path(self) -> Optional[Path]:
        """Where the work was last exported to, a folder of Parangonada CSV files
        or a .match file, if it's still there."""
        path = self.info.get("exported_to")
        return Path(path) if path and Path(path).exists() else None

    @property
    def unexported(self) -> bool:
        """Whether the work has changes that no export still there has."""
        return bool(self.info.get("unexported")) or bool(
            self.info.get("exported_to") and self.export_path is None)

    def release(self, state: Optional[str] = None) -> None:
        """Let go of the session. With state "closed" it isn't offered again,
        and it stays in the backups for KEEP_DAYS days from now."""
        try:
            if state is not None:
                self.info.update(state=state, released=_now())
                _write_json(self.folder / SESSION_FILE, self.info)
        except OSError:
            pass   # then it stays as it was, and is offered again next time
        finally:
            self.lock.unlock()


def _crashed(info: dict) -> bool:
    return info.get("state") == "open" and bool(info.get("unexported"))


def _kept(info: dict) -> bool:
    return info.get("state") == "kept"


def _claim(folder: Path, wanted: Callable[[dict], bool]) -> Optional[Leftover]:
    """folder's session, locked, if no running FERMATA holds it and wanted(info)."""
    info = _read_json(folder / SESSION_FILE)
    if not info or not wanted(info):
        return None
    lock = _take_lock(folder)
    if lock is None:
        return None
    info = _read_json(folder / SESSION_FILE)   # again: another FERMATA may have just taken it
    if not info or not wanted(info):
        lock.unlock()
        return None
    return Leftover(folder, info, lock)


def _folders(root) -> list[Path]:
    root = Path(root)
    if not root.exists():
        return []
    return sorted((f for f in root.iterdir() if f.is_dir()), reverse=True)


def find_leftovers(root) -> list[Leftover]:
    """Sessions with unexported changes whose FERMATA isn't running, newest first."""
    return [left for left in (_claim(f, _crashed) for f in _folders(root)) if left is not None]


def _origin_key(origin) -> tuple:
    """What work was opened from, in a form that compares equal for the same
    files: a file or folder, or a new alignment's (score, performance)."""
    if isinstance(origin, (tuple, list)):
        return tuple(_path_key(path) for path in origin)
    return (_path_key(origin),)


def find_kept(root, source=None) -> list[Leftover]:
    """Work saved for later whose FERMATA isn't running, the most recently
    changed first. With source, only work opened from that file or folder,
    or with a (score, performance) pair, only new alignments of those two.
    Each is locked until it's released."""
    key = _origin_key(source)
    def wanted(info):
        return _kept(info) and (source is None or
                                _origin_key(info.get("pair") or info.get("source")) == key)
    found = [left for left in (_claim(f, wanted) for f in _folders(root)) if left is not None]
    return sorted(found, key=lambda left: left.changed, reverse=True)


def take_kept(folder) -> Optional[Leftover]:
    """The work saved for later in folder, locked, or None if it isn't saved
    for later any more or a running FERMATA has it."""
    return _claim(Path(folder), _kept)


def restore(leftover: Leftover, score_for: Optional[Callable[[str, str], Optional[str]]] = None
            ) -> tuple[model.Project, Optional[model.Project]]:
    """Rebuild the work of a leftover session.

    Returns (project, backup). When the original file still exists and has
    the same notes, project is opened from it, which keeps .match export
    possible, and backup holds the links and ornaments to put on top. For a
    new alignment, the original is its score and performance, both of them,
    with the alignment as it was made. Otherwise project is the backup itself
    and backup is None.

    A .match file is opened with the MusicXML score it was opened with, or if
    that isn't there any more or doesn't fit, with the one score_for(path,
    refused) gives, if any: from the score folder, say, or chosen; refused is
    why the one it gave before can't be used. score_for may raise Cancelled,
    and a score it gives again after it was refused raises model.ScoreError.
    Work saved by FERMATA 0.1.4 kept only the score's name.
    """
    saved = model.load(leftover.folder)
    leftover.not_reopened = ""
    original, why = _reopen(leftover, saved, score_for)
    if original is not None:
        if not _same_notes(original.performance, saved.performance):
            why = (f"The performance notes in {_origin_name(leftover)} aren't the ones the work was "
                   f"saved with: {len(original.performance)} in the file, "
                   f"{len(saved.performance)} in the backup.")
        elif not _same_score(original, saved):
            why = (f"The score notes of {_origin_name(leftover)} aren't the ones the work was "
                   f"saved with: {len(original.score)} in the file, {len(saved.score)} in the "
                   "backup, and some the work links are missing or have another pitch.")
        else:
            return original, saved
    if leftover.info.get("pair") or _from_match(leftover):
        leftover.not_reopened = why or "It couldn't be opened again."
    return saved, None


def _from_match(leftover: Leftover) -> bool:
    return str(leftover.info.get("source") or "").lower().endswith(".match")


def _origin_name(leftover: Leftover) -> str:
    pair = leftover.info.get("pair")
    if pair:
        return f"{Path(pair[0]).name} and {Path(pair[1]).name}"
    return Path(str(leftover.info.get("source") or "")).name or "the file"


def _same_score(original: model.Project, saved: model.Project) -> bool:
    """Whether the backup's score notes are the original's. A .match file's
    score notes have its own ids, and the backup's only need to be among them,
    with the same pitches: work saved by FERMATA 0.1.4 has only the notes the
    file has, at the beats partitura worked out, without the MusicXML's others.
    The backup may have notes the original doesn't, as long as the work has no
    link or ornament on them: since 0.1.14, a .match file's score leaves out
    double notes, and reopening keeps only those the work uses (_reopen_match)."""
    if not str(original.source or "").lower().endswith(".match"):
        return _same_notes(original.score, saved.score)
    a, b = original.score, saved.score
    used = {s for s, _ in saved.alignment.links} | {s for o in saved.ornaments for s in o.score}
    if (set(b.ids) - set(a.ids)) & used:
        return False
    rows = np.array([(a.row[i], b.row[i]) for i in b.ids if i in a.row], dtype=int).reshape(-1, 2)
    return bool(np.all(a.pitch[rows[:, 0]] == b.pitch[rows[:, 1]]))


def _same_notes(a: model.NoteTrack, b: model.NoteTrack) -> bool:
    """Whether two rolls have the same notes: the same ids, each with the same
    pitch and onset. Ids alone aren't enough: a MIDI file's are numbered in
    time order, so a changed file with as many notes has the same ids."""
    if len(a) != len(b) or set(a.ids) != set(b.ids):
        return False
    order = np.array([b.row[i] for i in a.ids], dtype=int)
    return (bool(np.all(a.pitch == b.pitch[order]))
            and bool(np.allclose(a.onset, b.onset[order], atol=1e-3)))


def _reopen(leftover: Leftover, saved: model.Project,
            score_for: Optional[Callable[[str, str], Optional[str]]] = None
            ) -> tuple[Optional[model.Project], str]:
    """The files the work was opened from, opened again, and "", or None and
    why not, in words, if they're gone or can't be read any more. Cancelled and
    model.ScoreError from score_for go to the caller (see restore)."""
    pair, source = leftover.info.get("pair"), leftover.info.get("source")
    try:
        if pair:
            gone = [str(path) for path in pair if not Path(path).is_file()]
            if gone:
                return None, "These files aren't there any more: " + ", ".join(gone) + "."
            original = model.load_pair(*pair, links=model.first_links(leftover.folder))
            original.kept_files = dict(saved.kept_files)   # with zalign.csv as it was made
            return original, ""
        if source and str(source).lower().endswith(".match"):
            if not Path(source).is_file():
                return None, f"The .match file isn't there any more: {source}."
            original = _reopen_match(source, saved, score_for)
            return original, "" if original is not None else "Its MusicXML score wasn't found."
        if source and Path(source).exists():
            return model.load(source), ""
    except (Cancelled, model.ScoreError):
        raise
    except Exception as exc:  # then the backup alone, saying why
        return None, (f"{_origin_name(leftover)} couldn't be read again: {type(exc).__name__}: "
                      f"{exc}\n\n{traceback.format_exc().strip()}")
    return None, ""


def _reopen_match(source: str, saved: model.Project, score_for) -> Optional[model.Project]:
    """The .match file source opened again, with the MusicXML score it was
    opened with, which project.json keeps, or else the one score_for gives,
    asked again while it can't be used. A score found anew goes into saved's
    sources, which go on top of the original's. None if there's none."""
    if not Path(source).exists():
        return None
    # The score notes the work uses stay, also those FERMATA no longer reads
    # from the score: double notes, since 0.1.14, that work saved before linked.
    keep = {s for s, _ in saved.alignment.links} | {s for o in saved.ornaments for s in o.score}
    score = saved.sources.get("score")
    if score and Path(score).is_absolute() and Path(score).is_file():
        try:
            return model.load(source, score=score, keep=keep)
        except model.ScoreError:
            pass   # not its score any more: as if it had moved
    if score_for is None:
        return None
    refused, tried = "", set()
    while True:
        score = score_for(source, refused)
        if not score:
            return None
        if score in tried:   # given again after it was refused
            raise model.ScoreError(refused)
        tried.add(score)
        try:
            original = model.load(source, score=score, keep=keep)
            break
        except model.ScoreError as exc:
            refused = str(exc)
    saved.sources["score"] = original.sources["score"]
    return original


def continue_work(leftover: Leftover,
                  score_for: Optional[Callable[[str, str], Optional[str]]] = None) -> model.Project:
    """The work of a leftover session, to go on with it: the original file
    with the saved links, anchors, ornaments, comments and sections on it when
    the original is still there (see restore), or else the backup itself."""
    project, backup = restore(leftover, score_for)
    if backup is not None:
        alignment = project.alignment
        alignment.remove(alignment.links - backup.alignment.links)
        alignment.add(backup.alignment.links - alignment.links)
        project.ornaments = list(backup.ornaments)
        project.anchors = set(backup.anchors)
        project.comments = list(backup.comments)
        project.sections = list(backup.sections)
        project.sources = {**project.sources, **backup.sources}
        project.method = backup.method or project.method
    return project


def prune(root, keep_days: int = KEEP_DAYS) -> None:
    """Delete finished sessions whose last change is older than keep_days.

    Work saved for later, sessions a running FERMATA holds and sessions still
    waiting to be restored are kept. A session that was restored or continued
    is kept for keep_days from then, even if its last change is older.
    """
    cutoff = datetime.now() - timedelta(days=keep_days)
    for folder in _folders(root):
        info = _read_json(folder / SESSION_FILE) or {}
        if _kept(info) or _crashed(info):
            continue
        stamps = [s for s in (info.get("updated") or info.get("opened"), info.get("released")) if s]
        try:
            old = max(datetime.fromisoformat(s) for s in stamps) < cutoff
        except (TypeError, ValueError):   # no time recorded: go by the folder's
            old = datetime.fromtimestamp(folder.stat().st_mtime) < cutoff
        if not old:
            continue
        lock = _take_lock(folder)
        if lock is not None:
            lock.unlock()
            shutil.rmtree(folder, ignore_errors=True)
