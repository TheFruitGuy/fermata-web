"""Hearing the performance: its notes as audio. No Qt imports.

FERMATA plays the performance with a sampled piano, the Salamander C5 Light
soundfont that comes with it (see soundfont.py). If that can't be read, the
notes sound as a piano-like tone FERMATA makes itself. render() gives the audio
of any stretch of samples on its own, which is how the player streams a piece:
it asks for the next block whenever the sound card needs more. A note that
began in an earlier block carries on without a seam, because its sound is
worked out from the time since it began.

A note plays the soundfont's recording for its key and velocity, at its pitch:
softer velocity layers are darker and quieter, and within a layer, loudness
follows the velocity as in SoundFont players. Its volume envelope is the
soundfont's, with a release once the note ends, as the dampers do, and it's
silent TAIL seconds after its end in any case. Notes sound as long as the
performance file says, which for MIDI and .match files includes the sustain
pedal: partitura holds a pedalled note until the pedal comes up.

The tone is a handful of harmonics, brighter for louder notes, with a quick
attack, a decay that's longer for low notes than for high ones, and the same
short release.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from typing import Optional

import numpy as np

from .soundfont import Region, SoundFont

SAMPLE_RATE = 48000
ATTACK = 0.005      # seconds for the tone to reach full loudness
RELEASE = 0.1       # seconds: how fast the tone dies away once a note ends
TAIL = 8 * RELEASE  # a note is silent this long after its end, exactly, so blocks join
PARTIALS = 6        # harmonics per note of the tone
GAIN = 0.2          # loudness of the tone at full velocity, before the limiter
PIANO_GAIN = 1.5    # loudness of a recording at full velocity, before the limiter
# The attenuation generator counts 0.4 times, as in EMU's players, which the
# soundfont names: otherwise its loudest layer would jump 9 dB above the next.
ATTENUATION_SCALE = 0.4


@dataclass(frozen=True)
class Notes:
    """The notes to play, sorted by onset: seconds, MIDI pitch and velocity."""
    onset: np.ndarray
    offset: np.ndarray
    pitch: np.ndarray
    velocity: np.ndarray

    @classmethod
    def from_note_array(cls, notes: np.ndarray) -> "Notes":
        """From a performance note array. Without velocities, every note is played
        at 64."""
        order = np.argsort(notes["onset_sec"], kind="stable")
        notes = notes[order]
        onset = notes["onset_sec"].astype(float)
        velocity = (notes["velocity"].astype(float) if "velocity" in notes.dtype.names
                    else np.full(len(notes), 64.0))
        return cls(onset, onset + np.maximum(notes["duration_sec"].astype(float), 0.0),
                   notes["pitch"].astype(int), np.clip(velocity, 1.0, 127.0))

    @property
    def end(self) -> float:
        """When the last note has died away, in seconds."""
        return float(self.offset.max()) + TAIL if len(self.onset) else 0.0


def render(notes: Notes, first: int, count: int, rate: int = SAMPLE_RATE) -> np.ndarray:
    """The audio of samples first to first + count, counted from 0 seconds, as
    mono float32 between -1 and 1."""
    out = np.zeros(count, np.float64)
    if count <= 0 or not len(notes.onset):
        return out.astype(np.float32)
    t = (first + np.arange(count)) / rate
    t0, t1 = t[0], t[-1]
    sounding = np.flatnonzero((notes.onset <= t1) & (notes.offset + TAIL >= t0))
    sound = _played if piano() is not None else _tone
    for i in sounding.tolist():
        out += sound(t, notes.onset[i], notes.offset[i], int(notes.pitch[i]),
                     float(notes.velocity[i]), rate)
    return np.tanh(out).astype(np.float32)   # a soft limiter for dense chords


@lru_cache(maxsize=1)
def piano() -> Optional[SoundFont]:
    """The soundfont FERMATA plays with, read the first time it's needed, or
    None if it can't be read: then the notes sound as the tone."""
    try:
        return SoundFont()
    except Exception:   # a missing or broken file, whatever struct or numpy make of it
        return None


def _played(t: np.ndarray, onset: float, offset: float, pitch: int, velocity: float,
            rate: int) -> np.ndarray:
    """One note's sound at times t from the soundfont, silent before its onset."""
    since = t - onset
    on = since >= 0.0
    out = np.zeros_like(t)
    if not on.any():
        return out
    since = np.where(on, since, 0.0)
    font = piano()
    loudness = PIANO_GAIN * (velocity / 127.0) ** 2   # 40 dB from 127 down to 1
    for region in font.regions_for(pitch, int(round(velocity))):
        wave = font.wave(region)
        speed = font.rate * 2.0 ** (((pitch - region.root) * 100.0 + region.tune) / 1200.0)
        at = since * speed                        # where in the recording, in its samples
        i = at.astype(np.int64)
        playing = on & (i + 1 < len(wave))
        if not playing.any():
            continue                              # the recording has ended
        i = np.where(playing, i, 0)
        frac = at - i
        sound = np.where(playing, wave[i] * (1.0 - frac) + wave[i + 1] * frac, 0.0)
        gain = loudness * 10.0 ** (-ATTENUATION_SCALE * region.attenuation / 200.0) / 32768.0
        out += gain * sound * _envelope(region, since, offset - onset)
    # As for the tone: exactly nothing TAIL seconds after the note's end.
    return out * np.clip(1.0 - np.maximum(t - offset, 0.0) / TAIL, 0.0, 1.0)


def _envelope(region: Region, since: np.ndarray, held: float) -> np.ndarray:
    """The soundfont's volume envelope at times since a note's onset, for a
    note held for held seconds: a linear attack and a hold, then a decay, in
    decibels, down to the sustain level, and once the key is up, the release,
    in decibels, from wherever the decay had got to."""
    def level(s):
        return np.maximum(-np.maximum(s - region.attack - region.hold, 0.0) * 96.0 / region.decay,
                          -region.sustain)
    db = level(since)
    up = since > held
    if up.any():
        db = np.where(up, level(held) - (since - held) * 96.0 / region.release, db)
    gain = 10.0 ** (db / 20.0)
    if region.attack > 0.0:
        gain = gain * np.minimum(since / region.attack, 1.0)
    return gain


def _tone(t: np.ndarray, onset: float, offset: float, pitch: int, velocity: float,
          rate: int) -> np.ndarray:
    """One note's sound at times t as the tone, silent before its onset."""
    since = t - onset
    on = since >= 0.0
    if not on.any():
        return np.zeros_like(t)
    since = np.where(on, since, 0.0)
    strength = velocity / 127.0
    frequency = 440.0 * 2.0 ** ((pitch - 69) / 12.0)
    decay = float(np.clip(4.0 * 2.0 ** (-(pitch - 48) / 18.0), 0.3, 8.0))   # longer for low notes
    envelope = np.minimum(since / ATTACK, 1.0) * np.exp(-since / decay)
    after = np.maximum(t - offset, 0.0)
    # The release fades to exactly nothing at TAIL, so a note that render()
    # leaves out of a later block would have added nothing to it.
    envelope = envelope * np.exp(-after / RELEASE) * np.clip(1.0 - after / TAIL, 0.0, 1.0)
    tone = np.zeros_like(t)
    for k in range(1, PARTIALS + 1):
        f = k * frequency * (1.0 + 0.0004 * k * k)   # a piano's slightly stretched harmonics
        if f >= rate / 2:
            break
        weight = k ** (-2.2 + 1.2 * strength)          # louder notes are brighter
        tone += weight * np.exp(-since * 0.7 * (k - 1)) * np.sin(2.0 * np.pi * f * since)
    return np.where(on, GAIN * strength ** 1.6 * envelope * tone, 0.0)
