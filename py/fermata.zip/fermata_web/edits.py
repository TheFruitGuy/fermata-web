"""The edits that change the work, each one undoable, without Qt: the web
version's copy of the desktop's fermata/commands.py.

The desktop's code stays as it is (web/PLAN.md), so these are the bodies of
commands.py's QUndoCommands as plain classes, taking the same arguments, with
the same texts. Keep the two in step: they're listed under "Logic that exists
twice" in web/PLAN.md, and tests/test_edits.py runs both side by side when
PyQt6 is there.

Each edit has a `text` for the Undo and Redo menus, and `redo()` and `undo()`,
which call `on_change` after changing the project. redo() is called first when
the edit is pushed onto fermata_web.undo.UndoStack. Group compound edits in a
macro, as realigning does (RemoveLinks, then AddLinks) and marking an ornament
does (links, then SetAnnotations).
"""
from __future__ import annotations

from typing import Callable, Iterable

from fermata.model import Alignment, Link


def _plural(n: int, word: str) -> str:
    return f"{n} {word}{'' if n == 1 else 's'}"


class Edit:
    """One undoable change: `text` names it, redo() makes it, undo() takes it back."""

    text = ""

    def redo(self) -> None:
        raise NotImplementedError

    def undo(self) -> None:
        raise NotImplementedError


class _LinkEdit(Edit):
    def __init__(self, alignment: Alignment, links: Iterable[Link],
                 on_change: Callable[[], None], text: str):
        self.text = text
        self._alignment = alignment
        self._links = set(links)
        self._on_change = on_change
        self._done: set[Link] = set()


class AddLinks(_LinkEdit):
    def __init__(self, alignment, links, on_change):
        links = set(links)
        super().__init__(alignment, links, on_change, f"Add {_plural(len(links), 'link')}")

    def redo(self):
        self._done = self._alignment.add(self._links)
        self._on_change()

    def undo(self):
        self._alignment.remove(self._done)
        self._on_change()


class RemoveLinks(_LinkEdit):
    def __init__(self, alignment, links, on_change):
        links = set(links)
        super().__init__(alignment, links, on_change, f"Remove {_plural(len(links), 'link')}")

    def redo(self):
        self._done = self._alignment.remove(self._links)
        self._on_change()

    def undo(self):
        self._alignment.add(self._done)
        self._on_change()


class SetAnchors(Edit):
    """Pin links as anchors (pinned=True) or unpin them. Realigning keeps anchors."""

    def __init__(self, project, links, pinned: bool, on_change):
        links = set(links)
        verb = "Set" if pinned else "Clear"
        self.text = f"{verb} {_plural(len(links), 'anchor')}"
        self._project = project
        self._links = links
        self._pinned = pinned
        self._on_change = on_change
        self._done: set[Link] = set()

    def _set(self, links, pinned):
        if pinned:
            self._project.anchors |= links
        else:
            self._project.anchors -= links

    def redo(self):
        anchors = self._project.anchors
        self._done = self._links - anchors if self._pinned else self._links & anchors
        self._set(self._done, self._pinned)
        self._on_change()

    def undo(self):
        self._set(self._done, not self._pinned)
        self._on_change()


class SetAnnotations(Edit):
    """Replace one of the project's annotation lists as a whole: "ornaments",
    "comments" or "sections". The lists are short, and their items are never
    changed in place (Comment and Section are frozen), so keeping the list
    from before is all undo needs."""

    def __init__(self, project, name: str, value, on_change, text: str):
        self.text = text
        self._project = project
        self._name = name
        self._before = list(getattr(project, name))
        self._after = list(value)
        self._on_change = on_change

    def redo(self):
        setattr(self._project, self._name, list(self._after))
        self._on_change()

    def undo(self):
        setattr(self._project, self._name, list(self._before))
        self._on_change()


class ReplaceWork(Edit):
    """Replace all links, ornaments, anchors, comments and sections at once, as
    when restoring a backup.

    Undoing it goes back to the project as it was opened.
    """

    def __init__(self, project, links, ornaments, on_change, text="Restore the backup",
                 anchors=None, comments=None, sections=None):
        self.text = text
        self._project = project
        self._on_change = on_change
        self._before = (set(project.alignment.links), list(project.ornaments), set(project.anchors),
                        list(project.comments), list(project.sections))
        self._after = (set(links), list(ornaments),
                       set(project.anchors) if anchors is None else set(anchors),
                       list(project.comments) if comments is None else list(comments),
                       list(project.sections) if sections is None else list(sections))

    def _apply(self, state):
        links, ornaments, anchors, comments, sections = state
        alignment = self._project.alignment
        alignment.remove(alignment.links - links)
        alignment.add(links - alignment.links)
        self._project.ornaments = list(ornaments)
        self._project.anchors = set(anchors)
        self._project.comments = list(comments)
        self._project.sections = list(sections)
        self._on_change()

    def redo(self):
        self._apply(self._after)

    def undo(self):
        self._apply(self._before)
