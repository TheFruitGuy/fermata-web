"""Hearing the performance in the browser: the notes to play and their audio, from
fermata/playback.py as it is. The desktop's player (fermata/player.py, Qt) asks
playback.render for the next block whenever the sound card needs more; here the
page asks for the blocks ahead of the playhead and plays them with Web Audio.
What player.py and MainWindow decide in their Qt code is ported here: which
notes E plays, at most how many and how long (Player.play_notes,
MainWindow.hear_notes), and what the status bar says about it.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np

from fermata import playback, soundfont
from fermata.model import Project

NOTE_LENGTH = 0.8   # seconds a heard note sounds at most (player.NOTE_LENGTH)
HEAR_SPAN = 3.0     # seconds of a selection that E plays at most, from its first note
HEAR_NOTES = 16     # notes E plays at most


def _plural(n: int, word: str) -> str:
    return f"{n} {word}{'' if n == 1 else 's'}"


def install_soundfont(data) -> bool:
    """Put the soundfont the page fetched where soundfont.PATH expects it, and read
    it: whether the piano plays (else the notes sound as playback's tone)."""
    path = Path(soundfont.PATH)
    if data is not None and not path.is_file():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(bytes(data))
    playback.piano.cache_clear()
    return playback.piano() is not None


def has_soundfont() -> bool:
    return Path(soundfont.PATH).is_file()


def performance(project: Project) -> playback.Notes:
    return playback.Notes.from_note_array(project.sounding_notes())   # with the pedal


def heard(project: Project, kind: str, ids: list) -> tuple[Optional[playback.Notes], str]:
    """The notes E plays (MainWindow.hear_notes, Player.play_notes): performance notes
    as they were played, score notes together, each pitch once; from the first
    one's onset, each at most NOTE_LENGTH long, at most HEAR_SPAN seconds and
    HEAR_NOTES notes of them; and what the status bar says, for several."""
    if kind == "perf":
        array = project.sounding_notes()
        notes = playback.Notes.from_note_array(array[np.isin(array["id"].astype(str), list(ids))])
    else:
        score = project.score
        # Each pitch once, the same pitch twice would only sound louder, in score
        # order, so a big selection is heard from its start.
        rows = sorted((score.row[i] for i in ids if i in score.row), key=lambda r: (score.onset[r], score.pitch[r]))
        pitches = np.array(list(dict.fromkeys(int(score.pitch[r]) for r in rows)), dtype=int)
        notes = playback.Notes(np.zeros(len(pitches)), np.full(len(pitches), 0.8), pitches,
                               np.full(len(pitches), 80.0))
    if not len(notes.onset):
        return None, ""
    onset = notes.onset - notes.onset.min()
    keep = np.flatnonzero(onset <= HEAR_SPAN)[:HEAR_NOTES]   # a big selection: its first notes
    count = len(notes.onset)
    status = ""
    if len(ids) > 1:
        n = min(HEAR_NOTES, int(np.sum(onset <= HEAR_SPAN)))
        if kind == "score":
            what = f"{len(ids)} score notes together" + (
                f", the first {n} of their {count} pitches" if n < count else "")
        else:
            what = _plural(len(ids), "note") if n == count else f"the first {n} of {len(ids)} notes"
        status = f"Hearing {what}. E again on them stops."
    onset = onset[keep]
    offset = onset + np.clip((notes.offset - notes.onset)[keep], 0.15, NOTE_LENGTH)
    return playback.Notes(onset, offset, notes.pitch[keep], notes.velocity[keep]), status


def render(notes: playback.Notes, first: int, count: int) -> np.ndarray:
    """count samples of notes from sample first, as float32 (playback.render)."""
    return playback.render(notes, int(first), int(count)).astype(np.float32)
