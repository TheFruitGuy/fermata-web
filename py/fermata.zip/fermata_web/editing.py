"""Editing the links: what the selection links, removes, anchors and hides, and
the undo steps it makes. On the desktop this is RollWidget's selected_pairs,
_dragged_rows, anchor_targets, unlink_selection and hide_selection_links, and
MainWindow's add_links, replace_links, remove_links, _confirm_removing_many and
toggle_anchors (fermata/roll_widget.py, fermata/main_window.py); here they work
from the selection the page sends (web/PLAN.md, "Logic that exists twice").

A selection is the selected notes' ids in each roll, and the selected link, if
any, as (score id, performance id).
"""
from __future__ import annotations

from collections import Counter, defaultdict
from typing import Iterable, Optional

from fermata.model import Link, Project

from .edits import AddLinks, RemoveLinks, SetAnchors, SetAnnotations
from .undo import UndoStack


def _plural(n: int, word: str, plural: str = "") -> str:
    return f"{n} {word if n == 1 else plural or word + 's'}"


class Selection:
    """The selected notes of each roll, and the selected link."""

    def __init__(self, project: Project, perf: Iterable[str] = (), score: Iterable[str] = (),
                 link: Optional[Iterable[str]] = None):
        self.perf = {str(i) for i in perf if str(i) in project.performance.row}
        self.score = {str(i) for i in score if str(i) in project.score.row}
        link = tuple(str(i) for i in link) if link else None
        self.link: Optional[Link] = link if link in project.alignment.links else None


def selected_pairs(project: Project, sel: Selection) -> list[Link]:
    """Pair the selected notes: same pitch, in time order. With exactly one note
    selected in each roll, they're paired whatever their pitch (a wrong note is
    still the note that was meant). With one score note and several performance
    notes, every one of them is linked to it, whatever their pitch, as the notes
    of a trill are."""
    perf, score = project.performance, project.score
    pids = sorted(sel.perf, key=perf.row.get)
    sids = sorted(sel.score, key=score.row.get)
    if len(sids) == 1 and pids:
        return [(sids[0], pid) for pid in pids]
    by_pitch = defaultdict(list)
    for sid in sids:
        by_pitch[score.pitch[score.row[sid]]].append(sid)
    pairs, used = [], defaultdict(int)
    for pid in pids:
        pitch = perf.pitch[perf.row[pid]]
        if used[pitch] < len(by_pitch[pitch]):
            pairs.append((by_pitch[pitch][used[pitch]], pid))
            used[pitch] += 1
    return pairs


def dragged_pairs(project: Project, sel: Selection, kind: str, row: int, target: int) -> list[Link]:
    """Dragging note row of roll kind to note target of the other roll: its roll's
    whole selection if it's selected, or else itself, linked to the target."""
    perf, score = project.performance, project.score
    track = perf if kind == "perf" else score
    chosen = sel.perf if kind == "perf" else sel.score
    nid = str(track.ids[row])
    rows = sorted(track.row[i] for i in chosen) if nid in chosen else [row]
    if kind == "perf":
        return [(str(score.ids[target]), str(perf.ids[r])) for r in rows]
    return [(str(score.ids[r]), str(perf.ids[target])) for r in rows]


def anchor_targets(project: Project, sel: Selection) -> list[Link]:
    """The links that setting or clearing an anchor acts on: the selected link;
    otherwise the links between the selected notes, or all links of the
    selected notes when only one roll has a selection. With one note selected in
    each roll and no link between them, the pair itself, which gets linked."""
    if sel.link:
        return [sel.link]
    sp, ss = sel.perf, sel.score
    links = project.alignment.links_of(ss, sp)
    if sp and ss:
        links = {(s, p) for s, p in links if s in ss and p in sp}
        if not links and len(sp) == 1 and len(ss) == 1:
            return [(next(iter(ss)), next(iter(sp)))]
    return sorted(links)


def unlink_targets(project: Project, sel: Selection) -> tuple[list[Link], str]:
    """What S removes, and from what: the selected link ("link"); or else the
    selected performance notes' links and only theirs ("perf"), even with score
    notes still selected; or else the selected score notes' ("score")."""
    if sel.link:
        return [sel.link], "link"
    if sel.perf:
        return sorted(project.alignment.links_of((), sel.perf)), "perf"
    return sorted(project.alignment.links_of(sel.score, ())), "score"


def removing_many(links: Iterable[Link]) -> Optional[dict]:
    """The question before the selected score notes lose their links when one of
    them has several, which is easy to miss: None when there's nothing to ask."""
    links = list(links)
    per_note = Counter(s for s, _ in links)
    many = sorted((s for s, n in per_note.items() if n > 1), key=lambda s: -per_note[s])
    if not many:
        return None
    names = ", ".join(f"{s} ({per_note[s]} performance notes)" for s in many[:5])
    more = f", and {len(many) - 5} more" if len(many) > 5 else ""
    return {"title": "Remove all these links?",
            "text": f"Remove {_plural(len(links), 'link')} of the selected score notes?",
            "informative": (f"{'This score note is' if len(many) == 1 else 'These score notes are'} "
                            f"linked to several performance notes: {names}{more}. All of those "
                            "links go. Ctrl/Cmd+Z undoes it."),
            "button": "Remove"}


class Editor:
    """The project's edits on its undo stack, each reporting that the project
    changed through on_change, as the desktop's commands call _model_changed."""

    def __init__(self, project: Project, undo: UndoStack, on_change):
        self.project, self.undo, self.on_change = project, undo, on_change

    def add_links(self, links) -> bool:
        new = set(links) - self.project.alignment.links
        if new:
            self.undo.push(AddLinks(self.project.alignment, new, self.on_change))
        return bool(new)

    def replace_links(self, links) -> bool:
        """Q: link the pairs instead of their performance notes' other links, in
        one undo step. The score notes keep their other links. Anchors among the
        links removed are cleared in the same step, as removing them does."""
        old, new = self.project.alignment.replacing(links)
        if not old:
            return self.add_links(new)
        anchors = old & self.project.anchors
        notes = {p for _, p in links}
        self.undo.begin_macro(f"Relink {_plural(len(notes), 'performance note')}")
        self.undo.push(RemoveLinks(self.project.alignment, old, self.on_change))
        if new:
            self.undo.push(AddLinks(self.project.alignment, new, self.on_change))
        if anchors:
            self.undo.push(SetAnchors(self.project, anchors, False, self.on_change))
        self.undo.end_macro()
        return True

    def remove_links(self, links) -> bool:
        """Remove links. Anchors among them are cleared in the same undo step."""
        existing = set(links) & self.project.alignment.links
        if not existing:
            return False
        anchors = existing & self.project.anchors
        if anchors:
            self.undo.begin_macro(f"Remove {_plural(len(existing), 'link')}")
        self.undo.push(RemoveLinks(self.project.alignment, existing, self.on_change))
        if anchors:
            self.undo.push(SetAnchors(self.project, anchors, False, self.on_change))
            self.undo.end_macro()
        return True

    def apply_links(self, add, remove) -> None:
        """Link changes, as part of a macro; anchors on removed links are cleared
        too (MainWindow._apply_links)."""
        al = self.project.alignment
        remove = set(remove) & al.links
        if remove:
            self.undo.push(RemoveLinks(al, remove, self.on_change))
            anchors = remove & self.project.anchors
            if anchors:
                self.undo.push(SetAnchors(self.project, anchors, False, self.on_change))
        add = set(add) - al.links
        if add:
            self.undo.push(AddLinks(al, add, self.on_change))

    def set_annotations(self, name: str, value, text: str) -> None:
        self.undo.push(SetAnnotations(self.project, name, value, self.on_change, text))

    def mark_grouping(self, change, text: str) -> None:
        """A grouping marked, with its links, in one undo step (_finish_ornament)."""
        self.undo.begin_macro(text)
        self.apply_links(change.add, change.remove)
        self.set_annotations("ornaments", change.ornaments, text)
        self.undo.end_macro()

    def realign(self, name: str, removed: set, added: set) -> None:
        """A realign result, in one undo step "Realign with <method>", as
        MainWindow._realign_done pushes it."""
        if not removed and not added:
            return
        self.undo.begin_macro(f"Realign with {name}")
        if removed:
            self.undo.push(RemoveLinks(self.project.alignment, removed, self.on_change))
        if added:
            self.undo.push(AddLinks(self.project.alignment, added, self.on_change))
        self.undo.end_macro()

    def toggle_anchors(self, targets) -> str:
        """Pin the targeted links as anchors, or unpin them if they all are
        already. Returns the status bar's text."""
        targets = set(targets)
        if not targets:
            return "Select a link or linked notes to set an anchor."
        new_links = targets - self.project.alignment.links
        if not new_links and targets <= self.project.anchors:
            self.undo.push(SetAnchors(self.project, targets, False, self.on_change))
            return f"Cleared {_plural(len(targets), 'anchor')}."
        self.undo.begin_macro(f"Set {_plural(len(targets), 'anchor')}")
        if new_links:
            self.undo.push(AddLinks(self.project.alignment, new_links, self.on_change))
        self.undo.push(SetAnchors(self.project, targets, True, self.on_change))
        self.undo.end_macro()
        return (f"{_plural(len(targets), 'anchor')} set. Realigning keeps anchors; P again "
                "clears them.")


def hide_links(project: Project, sel: Selection, hidden: set) -> tuple[set, str, bool]:
    """H: hide the links of the selected notes (or the selected link) for now, to
    see through a dense cluster, or show them again if they're all hidden
    already. Returns the hidden links, the status bar's text, and whether the
    selected link is to be unselected because it's hidden now."""
    links = {sel.link} if sel.link else project.alignment.links_of(sel.score, sel.perf)
    if not links:
        return hidden, "Select the notes whose links you want to hide, then press H.", False
    if links <= hidden:
        return (hidden - links, f"{_plural(len(links), 'link')} shown again.", False)
    hidden = hidden | links
    return (hidden, f"{_plural(len(links), 'link')} hidden. Their notes keep a short stub, and "
            "hovering a note still shows its links. H again shows them, Shift+H shows all.",
            sel.link in hidden)


def show_all_text(project: Project, hidden: set) -> str:
    """Shift+H: the status bar's text for showing every hidden link again."""
    n = len(hidden & project.alignment.links)
    return f"{_plural(n, 'hidden link')} shown again." if n else ""
