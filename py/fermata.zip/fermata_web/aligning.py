"""New alignments and realigning, split between the two workers (web/PLAN.md,
"Architecture"). The core worker keeps the project: it reads the chosen files
(start_page.py's _ReadWorker), plans (MainWindow.realign_selection) and applies
what comes back (MainWindow._aligned and _realign_done). The job worker runs
the matcher (_AlignWorker and _RealignWorker) on a pickle of what it needs,
and answers with a pickle of what it made, so that the core worker stays free
and Cancel can stop the job worker at once.
"""
from __future__ import annotations

import pickle
import tempfile
import traceback
from pathlib import Path
from typing import Any, Optional

import numpy as np

from fermata import model
from fermata.model import Project

from .editing import _plural


def pickled(value) -> np.ndarray:
    """value pickled, as bytes the worker hands over to the page as a Uint8Array."""
    return np.frombuffer(pickle.dumps(value, protocol=pickle.HIGHEST_PROTOCOL), np.uint8)


def unpickled(data) -> Any:
    return pickle.loads(bytes(data))


# --------------------------------------------------------------------------- the core worker

def read(kind: str, path: Path, name: str):
    """Read a chosen score or performance, as _ReadWorker.run does: (the file
    read, "") or (None, what's wrong in words)."""
    try:
        return (model.read_score if kind == "score" else model.read_performance)(path), ""
    except ValueError as exc:   # says what's wrong in words
        return None, str(exc)
    except Exception as exc:  # anything else: say it rather than lose it
        return None, f"{name} couldn't be read: {type(exc).__name__}: {exc}"


def describe(score: model.ScoreFile, performance: model.PerformanceFile, method_name: str) -> str:
    """_AlignJob.describe: "312 score notes and 340 performance notes with Dual DTW"."""
    return (f"{len(score.notes):,} score notes and {len(performance.notes):,} "
            f"performance notes with {method_name}")


def aligned_status(project: Project, described: str, took: str, unaligned: tuple[int, int]) -> str:
    """The status bar's text once a new alignment is open, as MainWindow._aligned has it."""
    un_perf, un_score = unaligned
    return (f"Aligned {described} in {took}: {len(project.alignment.links):,} links, "
            f"{_plural(un_perf, 'performance note')} and {_plural(un_score, 'score note')} "
            "without a link.")


def realign_changes(project: Project, result) -> tuple[set, set]:
    """The links a realign result removes and adds, as _realign_done works them out."""
    current = project.alignment.links
    removed = (set(result.plan.remove) & current) - result.links
    added = set(result.links) - current
    return removed, added


def realign_message(result, removed: set, added: set) -> str:
    """The status bar's text after realigning, as _realign_done words it."""
    import fermata.realign as realign
    plan = result.plan
    if removed or added:
        message = (f"Realigned {plan.summary} with {plan.name}: "
                   f"{_plural(len(added), 'new link')}, {_plural(len(removed), 'link')} removed.")
    else:
        message = f"Realigned {plan.summary} with {plan.name}: the links didn't change."
    if result.paired_by_pitch and not len(plan.boundaries) and not result.error:
        message += (f" The selection has fewer than {realign.MIN_PART} notes in a roll, too "
                    f"few for {plan.name}, so notes of the same pitch were paired in time "
                    "order.")
    elif result.paired_by_pitch:
        message += (f" {_plural(result.paired_by_pitch, 'part')} between anchors "
                    f"{'was' if result.paired_by_pitch == 1 else 'were'} paired by pitch")
        message += f" ({plan.name} failed: {result.error})." if result.error else "."
    if plan.ignored_anchors:
        message += (f" {_plural(plan.ignored_anchors, 'anchor')} "
                    f"{'crosses' if plan.ignored_anchors == 1 else 'cross'} other anchors "
                    "and didn't split the passage.")
    return message


# --------------------------------------------------------------------------- the job worker

def cache() -> Path:
    """Outer HMM's cache, as MainWindow.matcher_cache: on the job worker's IDBFS
    mount at /cache, kept between visits, or for the visit where there's none."""
    root = Path("/cache")
    if not root.is_dir():
        root = Path(tempfile.gettempdir()) / "fermata-cache"
    return root / "outerhmm"


def run_job(job) -> dict:
    """Run a job the core worker made: ("new", score, performance, method) for a
    new alignment, or ("realign", project, plan). Answers {"result": a pickle of
    the new Project or the realign Result}, or {"failed": what went wrong}, as
    the desktop's workers emit failed with it."""
    import fermata.realign as realign
    kind, *rest = unpickled(job)
    try:
        if kind == "new":
            score, performance, method = rest
            made = realign.new_alignment(score, performance, method, cache())
        else:
            project, plan = rest
            made = realign.run(project, plan, cache())
    except Exception as exc:  # shown to the user; the alignment is left as it was
        return {"failed": f"{type(exc).__name__}: {exc}"}
    return {"result": pickled(made)}


def dispatch(method: str, args: Optional[dict] = None) -> dict:
    """What the job worker answers, as api.dispatch: run_job, and warm_up, which
    imports realign while nothing waits for it."""
    try:
        if method == "warm_up":
            import fermata.realign  # noqa: F401
            return {"ok": True, "result": None}
        if method != "run_job":
            raise LookupError(f"No such call: {method}")
        return {"ok": True, "result": run_job(**(args or {}))}
    except Exception as exc:
        return {"ok": False, "error": {"kind": "bug", "message": f"{type(exc).__name__}: {exc}",
                                       "details": traceback.format_exc()}}

