"""The sidebar's texts: the Selection group's line and the Alignment group's
counts, as MainWindow._update_sidebar writes them (fermata/main_window.py),
with RollWidget's unaligned_counts, mismatch_count, hidden_count and
other_pass_count (web/PLAN.md, "Logic that exists twice"). A selected ornament
comes with Phase 4.
"""
from __future__ import annotations

import numpy as np

from fermata import annotations as ann
from fermata import repeats
from fermata.model import Project

from .editing import Selection, _plural
from .view import _mismatch_links


def selection_text(project: Project, sel: Selection) -> str:
    if sel.link:
        sid, pid = sel.link
        return f"Link between score note {sid} and performance note {pid}."
    text = f"{_plural(len(sel.perf), 'performance note')}, {_plural(len(sel.score), 'score note')}."
    ornaments = ann.ornaments_of(project, sel.perf, sel.score)
    if ornaments:
        kinds = ", ".join(ann.grouping_name(o) if o.group == "other" else ann.grouping_name(o).lower()
                          for o in ornaments)
        text += f" Part of {'a grouping' if len(ornaments) == 1 else 'groupings'}: {kinds}."
    return text


def unaligned_counts(project: Project) -> tuple[int, int]:
    """Notes without a link, leaving out the notes of passes that aren't aligned
    (RollWidget.unaligned_counts)."""
    aligned = project.aligned_mask("perf")
    other = repeats.other_pass_mask(project, aligned)
    return int((~aligned & ~other).sum()), int((~project.aligned_mask("score")).sum())


def alignment_text(project: Project, hidden: set) -> str:
    perf, score, alignment = project.performance, project.score, project.alignment
    un_perf, un_score = unaligned_counts(project)
    lines = [_plural(len(alignment.links), "link"),
             f"{_plural(un_perf, 'performance note')} without a link",
             f"{_plural(un_score, 'score note')} without a link"]
    links = sorted(alignment.links)
    prow = np.fromiter((perf.row[p] for _, p in links), int, len(links))
    srow = np.fromiter((score.row[s] for s, _ in links), int, len(links))
    mismatched = int(_mismatch_links(project, links, prow, srow).sum())
    if mismatched:
        lines.append(f"{_plural(mismatched, 'link')} between notes of different pitches")
    many = len(alignment.many_to_many_links(ignore=project.grouping_links()))
    if many:
        lines.append(f"{_plural(many, 'link')} on notes with several partners")
    if project.ornaments:
        orns = sum(o.group == "ornament" for o in project.ornaments)
        others = len(project.ornaments) - orns
        if orns:
            lines.append(_plural(orns, "ornament"))
        if others:
            lines.append(_plural(others, "other note grouping"))
    anchors = project.pinned_anchors()
    if anchors:
        lines.append(_plural(len(anchors), "anchor"))
    n_hidden = len(hidden & alignment.links)
    if n_hidden:
        lines.append(f"{_plural(n_hidden, 'link')} hidden (Shift+H shows them)")
    comments = project.comments
    if comments:
        unresolved = sum(not c.resolved for c in comments)
        lines.append(f"{_plural(len(comments), 'comment')}, {unresolved} open")
    if project.sections:
        lines.append(_plural(len(project.sections), "section"))
    n_other = int(repeats.other_pass_mask(project, project.aligned_mask("perf")).sum())
    if n_other:
        lines.append(f"{_plural(n_other, 'performance note')} in passes that aren't aligned")
    return "\n".join(lines)
