"""What the core worker answers: one dispatch(method, args) for every call.

dispatch never raises. It answers {"ok": True, "result": ...}, or
{"ok": False, "error": {"kind", "message", "details"}}: kind "user" for what
the desktop shows as a message (ValueError, and realign's PlanError), with
details "", and kind "bug" for anything else, with the traceback in details
for the user to copy, as the desktop's reports have it.
"""
from __future__ import annotations

import dataclasses
import io
import sys
import tempfile
import traceback
import zipfile
from importlib import metadata
from pathlib import Path
from typing import Any, Optional

import numpy as np

from fermata import __version__, model, repeats
from fermata import session as sessions

from fermata import annotations as ann

from . import aligning, comments, editing, grouping, pitch, saving, sections, sidebar, sound, status, view
from .edits import ReplaceWork
from . import files as store
from . import matches
from .undo import UndoStack


class State:
    """The opened project and its undo stack: everything the core worker keeps.
    derived is what the status texts need from the whole project, worked out the
    first time they need it, and dropped whenever the project changes."""

    def __init__(self):
        self.project: Optional[model.Project] = None
        self.undo = UndoStack()
        self.derived: Optional[status.Derived] = None
        self.editor: Optional[editing.Editor] = None
        self.changed = False   # an edit, undo or redo changed the project since the last answer
        self.default_method: Optional[str] = None   # the setting "method", for _sync_method
        self.chosen = {"score": None, "performance": None}   # the start page's files, read
        self.realigning: Optional[model.Project] = None   # the project a realign job was made from
        self.session: Optional[sessions.Session] = None   # the open project's backup
        self.kept = False             # the work is saved for later: closing keeps it without asking
        self.backup_failed = False    # said once per project, as the desktop's _backup_failed
        self.play_notes = None        # the performance as playback.Notes, made the first time it plays
        self.hear_notes = None        # what E plays now


state = State()


def _version(dist: str) -> str:
    try:
        return metadata.version(dist)
    except metadata.PackageNotFoundError:
        return ""


def version_info() -> dict:
    """FERMATA's version and those of what it runs on. Pyodide's is added by the worker."""
    return {"fermata": __version__, "python": sys.version.split()[0],
            "partitura": _version("partitura"), "parangonar": _version("parangonar")}


def counts() -> dict:
    project = state.project
    if project is None:
        return {"performance_notes": 0, "score_notes": 0, "links": 0}
    return {"performance_notes": len(project.performance.ids),
            "score_notes": len(project.score.ids),
            "links": len(project.alignment.links)}


def _install(project: model.Project) -> dict:
    """Make project the open project, with a new undo history, as
    MainWindow._install does, and answer with what the page shows: its name,
    the problems found while opening it, its counts and the whole view model."""
    _end_session()
    state.project = project
    state.derived = None
    state.undo.clear()
    state.editor = editing.Editor(project, state.undo, _project_changed)
    state.changed = False
    state.session = sessions.Session(saving.root(), project)
    state.play_notes = state.hear_notes = None
    state.backup_failed = False
    _sync_method(project)
    return {"name": project.name, "warnings": list(project.warnings), **counts(),
            "view": view.full(project), "undo": _undo_state(), "method": project.method}


_REALIGN: Optional[tuple] = None


def _realign_tables() -> tuple:
    """realign.METHODS and realign.DEFAULT_METHOD, read from realign.py with ast:
    importing realign would load pandas and matplotlib, which opening doesn't need."""
    global _REALIGN
    if _REALIGN is None:
        import ast
        import fermata
        tree = ast.parse((Path(fermata.__file__).parent / "realign.py").read_text(encoding="utf-8"))
        found = {node.targets[0].id: node.value for node in tree.body
                 if isinstance(node, ast.Assign) and len(node.targets) == 1
                 and isinstance(node.targets[0], ast.Name)}
        _REALIGN = (ast.literal_eval(found["METHODS"]), ast.literal_eval(found["DEFAULT_METHOD"]))
    return _REALIGN


def default_method(method: Optional[str] = None) -> None:
    """The realign method last chosen (the setting "method"), which a project
    without its own gets, as the desktop's _sync_method gives it."""
    state.default_method = method


def _sync_method(project: model.Project) -> None:
    """The project's method, or the last one chosen, or the default: MainWindow._sync_method."""
    methods, default = _realign_tables()
    method = project.method
    if method not in methods:
        method = state.default_method
    if method not in methods:
        method = default
    project.method = method


def _project_changed() -> None:
    """Every edit, and its undo and redo, calls this, as the desktop's commands
    call _model_changed."""
    state.changed = True
    state.derived = None


def _undo_state() -> dict:
    """What the Undo and Redo buttons and menu items show, and whether the work
    has changes that aren't exported."""
    undo = state.undo
    return {"can_undo": undo.can_undo, "can_redo": undo.can_redo, "undo_text": undo.undo_text,
            "redo_text": undo.redo_text, "clean": undo.is_clean, "kept": state.kept}


def _answer(**extra) -> dict:
    """The answer to an edit: the view model's new states and links if the
    project changed, the undo stack's state, and whatever else the call says."""
    answer = {"undo": _undo_state(), **extra}
    if state.changed:
        state.changed = False
        answer["view"] = view.edited(_project())
    return answer


def _selection(perf=None, score=None, link=None) -> editing.Selection:
    return editing.Selection(_project(), perf or (), score or (), link)


def link_selection(perf: Optional[list] = None, score: Optional[list] = None,
                   replace: bool = False) -> dict:
    """A, L or Enter: link the selected notes, as selected_pairs pairs them; with
    replace (Q), instead of the selected performance notes' other links."""
    sel = _selection(perf, score)
    pairs = editing.selected_pairs(_project(), sel)
    if not pairs:
        return _answer(status="Select notes in both rolls first. "
                              "Notes of the same pitch are paired in time order.")
    (state.editor.replace_links if replace else state.editor.add_links)(pairs)
    return _answer()


def link_drag(kind: str, row: int, target: int, perf: Optional[list] = None,
              score: Optional[list] = None) -> dict:
    """A note dragged to a note of the other roll: it, or its roll's selection
    if it's selected, is linked to that note."""
    if kind not in ("perf", "score"):
        raise ValueError(f"No such roll: {kind}")
    state.editor.add_links(editing.dragged_pairs(_project(), _selection(perf, score), kind,
                                                 int(row), int(target)))
    return _answer()


def unlink_selection(perf: Optional[list] = None, score: Optional[list] = None,
                     link: Optional[list] = None, confirmed: bool = False) -> dict:
    """S: remove the selected link, or the selected notes' links. For the
    selected score notes, when one of them would lose several, the answer is
    the question to ask first ("confirm"); asked again with confirmed, it goes on."""
    links, source = editing.unlink_targets(_project(), _selection(perf, score, link))
    existing = set(links) & _project().alignment.links
    if not existing:
        return _answer()
    if source == "score" and not confirmed:
        question = editing.removing_many(existing)
        if question:
            return _answer(confirm=question)
    state.editor.remove_links(existing)
    return _answer()


def toggle_anchors(perf: Optional[list] = None, score: Optional[list] = None,
                   link: Optional[list] = None) -> dict:
    """P: set or clear anchors on the selected link or the links of the selected notes."""
    text = state.editor.toggle_anchors(editing.anchor_targets(_project(), _selection(perf, score, link)))
    return _answer(status=text)


def _links(pairs) -> set:
    return {(str(s), str(p)) for s, p in pairs or ()}


def hide_links(perf: Optional[list] = None, score: Optional[list] = None,
               link: Optional[list] = None, hidden: Optional[list] = None) -> dict:
    """H: the links hidden after hiding the selection's, or showing them again."""
    hidden, text, unselect = editing.hide_links(_project(), _selection(perf, score, link), _links(hidden))
    return {"hidden": sorted(hidden), "status": text, "unselect_link": unselect}


def show_all_links(hidden: Optional[list] = None) -> dict:
    """Shift+H: the status bar's text for showing every hidden link again."""
    return {"status": editing.show_all_text(_project(), _links(hidden))}


def undo() -> dict:
    if state.undo.can_undo:
        state.undo.undo()
    return _answer()


def redo() -> dict:
    if state.undo.can_redo:
        state.undo.redo()
    return _answer()


def sidebar_texts(perf: Optional[list] = None, score: Optional[list] = None,
                  link: Optional[list] = None, hidden: Optional[list] = None,
                  ornament: Optional[int] = None, marking: Optional[dict] = None) -> dict:
    """The Selection group's line, the Alignment group's counts, and the Note
    grouping group's hint and whether Remove is on (_update_sidebar). marking:
    {"label", "onset"} while a grouping is being marked."""
    project = _project()
    orn = project.ornaments[ornament] if ornament is not None and 0 <= ornament < len(project.ornaments) else None
    selection = (grouping.selected_text(orn) if orn is not None
                 else sidebar.selection_text(project, _selection(perf, score, link)))
    marking = marking or {}
    return {"selection": selection, "alignment": sidebar.alignment_text(project, _links(hidden)),
            "grouping_hint": grouping.hint(marking.get("label"), bool(marking.get("onset")), bool(perf)),
            "can_remove": bool(grouping.targets(project, ornament, score or ())),
            "banner": (grouping.banner(marking["label"], bool(marking.get("onset")), bool(perf))
                       if marking.get("label") else "")}


# ------------------------------------------------------------------ comments

def add_comment(text: str, author: str, perf: Optional[list] = None) -> dict:
    """C, or Add comment: a comment on the selected performance notes, signed by
    author, which opens (MainWindow.add_comment). {"status"} alone when there's
    no text or no performance note selected."""
    project = _project()
    try:
        comment = ann.new_comment(text, author, set(perf or ()))
    except ann.AnnotationError as exc:
        return {"status": str(exc), "undo": _undo_state()}
    state.editor.set_annotations("comments", project.comments + [comment], "Add a comment")
    return _answer(status=f"Added comment {len(project.comments)}.", open=len(project.comments) - 1)


def comment_text(index: int) -> str:
    """A comment's text, for Edit to start with."""
    project = _project()
    return project.comments[comments.checked(project, index)].text


def comment_spans(index: int) -> dict:
    """Opening a comment: where the rolls move to (show_notes)."""
    project = _project()
    return comments.spans(project, comments.checked(project, index))


def reply_comment(index: int, text: str, author: str) -> dict:
    project = _project()
    index = comments.checked(project, index)
    try:
        comment = ann.reply(project.comments[index], text, author)
    except ann.AnnotationError as exc:
        return {"status": str(exc), "undo": _undo_state()}
    state.editor.set_annotations("comments", comments.replaced(project, index, comment),
                                 f"Reply to comment {index + 1}")
    return _answer()


def edit_comment(index: int, text: str) -> dict:
    project = _project()
    index = comments.checked(project, index)
    try:
        comment = comments.edited(project, index, text)
    except ann.AnnotationError as exc:
        return {"status": str(exc), "undo": _undo_state()}
    state.editor.set_annotations("comments", comments.replaced(project, index, comment),
                                 f"Edit comment {index + 1}")
    return _answer()


def toggle_resolved(index: int) -> dict:
    project = _project()
    index = comments.checked(project, index)
    comment, text = comments.toggled(project, index)
    state.editor.set_annotations("comments", comments.replaced(project, index, comment), text)
    return _answer()


def delete_comment(index: int) -> dict:
    """Delete, or the Delete key with a comment open: it and its replies go."""
    project = _project()
    index = comments.checked(project, index)
    state.editor.set_annotations("comments", [c for i, c in enumerate(project.comments) if i != index],
                                 f"Delete comment {index + 1}")
    return _answer(open=-1)


# ------------------------------------------------------------------ backups and saved work

def _exported(zip_name: str) -> None:
    """The work is exported, as a zip downloaded: closing doesn't ask (MainWindow._exported)."""
    state.undo.set_clean()
    if state.session is not None:
        state.session.exported(saving.export_marker(zip_name))


def _end_session(view: Optional[dict] = None) -> None:
    """End the open project's session: saved for later, or closed (_end_session)."""
    if state.session is not None:
        try:
            state.session.close(keep=state.kept, view=view)
        except OSError:
            pass   # the backup stays as it was, and is offered again if it has unexported work
        state.session = None
    state.kept = False


def backup(view: Optional[dict] = None) -> dict:
    """Bring the backup up to date (MainWindow._backup), half a second after a
    change. Answers the session's folder, which the page holds a lock on, or
    None while nothing has changed; and {"failed"} with the box's text, once."""
    if state.project is None or state.session is None:
        return {"folder": None}
    unexported = not state.undo.is_clean
    if state.session.folder is None and not unexported:
        return {"folder": None}   # nothing has changed yet, so there's nothing to protect
    try:
        state.session.backup(unexported, view=view)
    except Exception as exc:
        answer = {"folder": None, "status": f"Backup failed: {exc}"}
        if not state.backup_failed:
            state.backup_failed = True
            answer["failed"] = (f"FERMATA couldn't back up your work in this browser's storage.\n\n{exc}\n\n"
                                "Export your work to keep it safe.")
        return answer
    return {"folder": state.session.folder.name}


def _keep_now(view: Optional[dict]) -> Optional[str]:
    """Save the work for later now (_keep_now): from then on every change is saved
    for later too. Returns why it couldn't be, or None."""
    try:
        state.session.keep(not state.undo.is_clean, view=view)
    except Exception as exc:
        return (f"FERMATA couldn't save your work in this browser's storage.\n\n{exc}\n\n"
                "Export your work to keep it safe.")
    state.kept = True
    return None


def save_for_later(view: Optional[dict] = None) -> dict:
    """File > Save for Later (Ctrl/Cmd+Alt+S), and the closing box's Save for Later."""
    project = _project()
    backup(view)
    if state.session.folder is None:
        return {"status": f"There's nothing to save yet: you haven't changed {project.name}.",
                "undo": _undo_state()}
    failed = _keep_now(view)
    if failed:
        return {"failed": failed, "undo": _undo_state()}
    return {"status": f"Saved {project.name} for later. The next time you open FERMATA, it offers to "
                      "continue where you left off.", "folder": state.session.folder.name,
            "undo": _undo_state()}


def saved_work(held: Optional[list] = None) -> list:
    """The start page's Continue list and File > Continue Work: the work saved for
    later, the most recent first (_fill_continue_menu)."""
    with saving.held(held):
        found = sessions.find_kept(saving.root())
    for left in found:
        left.release()   # only listed here; taken again when chosen
    return [saving.describe(left) for left in found]


def saved_for(source: Optional[str] = None, pair: bool = False, example: bool = False,
              held: Optional[list] = None) -> Optional[dict]:
    """Opening a file, or aligning a pair of files, that has work saved for later
    (_offer_saved_work_on): the box's texts, with the folder, or None. source:
    the kept copy's key and the file's name in it, "key/name"; pair: the score
    and performance chosen on the start page, from read_file; example: the
    example, which the desktop offers saved work on too; with none of them,
    what the open project was opened from, as the page asks right after opening."""
    if example:
        origin = str(model.EXAMPLE_MATCH)
    elif pair:
        score, performance = state.chosen["score"], state.chosen["performance"]
        if score is None or performance is None:
            return None
        origin = (str(score.path), str(performance.path))
    elif source is not None:
        key, _, name = str(source).partition("/")
        origin = str(store.kept(key) / name) if name else str(store.kept(key))
    else:
        project = _project()
        if project.pair:
            origin = tuple(str(p) for p in project.pair_files)
        elif project.source is not None:
            origin = str(project.source)
        else:
            return None
        pair = isinstance(origin, tuple)
    with saving.held(held):
        found = sessions.find_kept(saving.root(), source=origin)
    for left in found:
        left.release()
    if not found:
        return None
    left = found[0]
    question = (f"align {Path(origin[0]).name} and {Path(origin[1]).name} anew" if pair
                else f"open {Path(origin).name} as it is")
    return {"folder": left.folder.name, "title": "Continue your work?",
            "text": f"You saved work on {left.name} for later.",
            "informative": f"{saving.saved_state(left)}\n\nContinue it, or {question}?",
            "original": "Align Anew" if pair else "Open the Original"}


def _leftover(folder: str, find) -> sessions.Leftover:
    left = find(saving.root() / Path(str(folder)).name)
    if left is None:
        raise ValueError("That work isn't saved for later any more, or it's open in another tab.")
    return left


def continue_saved(folder: str, held: Optional[list] = None, view: Optional[dict] = None) -> dict:
    """Continue work saved for later (continue_saved, _continue): the original file
    with the saved work on it, the last export and the view. The undo history
    starts afresh, and the work stays saved for later."""
    if state.session is not None:
        _end_session(view)
    with saving.held(held):
        left = _leftover(folder, sessions.take_kept)
    try:
        project = sessions.continue_work(left)
    except Exception as exc:
        left.release()
        raise ValueError(f"The work saved for later couldn't be opened.\n\n{exc}") from exc
    answer = _install(project)
    state.session.carry_over(left)
    if left.unexported:
        state.undo.reset_clean()   # not exported: the title and closing say so
    failed = _keep_now(left.info.get("view"))
    left.release("closed" if not failed else None)
    answer.update(undo=_undo_state(), view_state=left.info.get("view"),
                  folder=state.session.folder.name if state.session.folder else None,
                  exported=left.export_path.name if left.export_path else "",
                  status=f"Continuing your work on {project.name} from {left.updated}.",
                  not_reopened=saving.not_reopened(left, "continued"), failed=failed)
    return answer


def stop_offering(folder: str, held: Optional[list] = None) -> str:
    """Don't Offer Again: the work isn't saved for later any more, and stays in the
    backups for KEEP_DAYS days."""
    with saving.held(held):
        left = sessions.take_kept(saving.root() / Path(str(folder)).name)
    if left is None:
        return "That work isn't saved for later any more, or it's open in another tab."
    left.release("closed")
    return (f"FERMATA won't offer {left.name} again. It stays in the backups for "
            f"{sessions.KEEP_DAYS} days: File > Download Backups.")


def leftovers(held: Optional[list] = None) -> list:
    """After a crash, or a tab closed with changes that weren't exported: the work
    to offer to restore (offer_restore), newest first."""
    with saving.held(held):
        found = sessions.find_leftovers(saving.root())
    for left in found:
        left.release()
    return [{"folder": left.folder.name, "title": "Restore your work?",
             "text": f"FERMATA closed before your changes to {left.info.get('name') or left.folder.name} "
                     "were exported.",
             "informative": f"The backup is from {left.updated}. You can undo the restore."} for left in found]


def _claim_crashed(folder: Path):
    return sessions._claim(folder, sessions._crashed)


def restore_leftover(folder: str, held: Optional[list] = None) -> dict:
    """Restore: the backup on top of the original file, as one undo step, or the
    backup alone, marked as not exported (MainWindow._restore)."""
    with saving.held(held):
        left = _leftover(folder, _claim_crashed)
    try:
        project, saved = sessions.restore(left)
    except Exception as exc:
        left.release()
        raise ValueError(f"The backup couldn't be opened.\n\n{exc}") from exc
    answer = _install(project)
    if saved is not None:   # the original file is still there: restore on top of it
        state.undo.push(ReplaceWork(project, saved.alignment.links, saved.ornaments, _project_changed,
                                    anchors=saved.anchors, comments=saved.comments, sections=saved.sections))
        project.sources = {**project.sources, **saved.sources}
        if saved.method:
            project.method = saved.method
            _sync_method(project)
    else:                   # opened from the backup itself: mark it as not exported
        state.undo.reset_clean()
    # Back up the restored work right away, before letting go of the old backup.
    done = backup(left.info.get("view"))
    left.release("closed")
    state.changed = False
    answer.update(view=view.full(project), undo=_undo_state(), method=project.method,
                  view_state=left.info.get("view"), folder=done.get("folder"),
                  status=f"Restored your work on {project.name}",
                  not_reopened=saving.not_reopened(left, "restored"))
    return answer


def dont_restore(folder: str, held: Optional[list] = None) -> None:
    """Don't Restore: kept in the backups, not offered again."""
    with saving.held(held):
        left = _claim_crashed(saving.root() / Path(str(folder)).name)
    if left is not None:
        left.release("closed")


def prune(held: Optional[list] = None) -> None:
    """Delete finished sessions older than 14 days (session.prune), at start-up."""
    with saving.held(held):
        sessions.prune(saving.root())


def backups_zip() -> dict:
    """File > Download Backups: every backup in a zip, where the desktop shows their folder."""
    root = saving.root()
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as z:
        if root.is_dir():
            for path in sorted(root.rglob("*")):
                if path.is_file() and path.name != sessions.LOCK_FILE:
                    z.write(path, path.relative_to(root).as_posix())
    return {"zip": "fermata-backups.zip", "data": np.frombuffer(buffer.getvalue(), np.uint8)}


# ------------------------------------------------------------------ sound

def sound_ready() -> dict:
    """Whether the soundfont is in place, or the page should fetch it first."""
    return {"soundfont": sound.has_soundfont(), "rate": sound.playback.SAMPLE_RATE}


def install_soundfont(data=None) -> dict:
    """The soundfont the page fetched: written where soundfont.PATH expects it, and
    read. piano is False when it couldn't be, and the notes sound as a tone."""
    return {"piano": sound.install_soundfont(data)}


def play(start: float) -> dict:
    """Space, Z or Play: the performance from start seconds; at its end, from its
    beginning (MainWindow.toggle_playback). Answers where it starts and ends."""
    project = _project()
    if state.play_notes is None:
        state.play_notes = sound.performance(project)
    notes = state.play_notes
    if start >= notes.end - sound.playback.TAIL:
        start = float(project.performance.start)
    return {"start": float(start), "end": float(notes.end), "rate": sound.playback.SAMPLE_RATE}


def hear(kind: str, ids: list) -> dict:
    """E: notes to hear on their own, and the status bar's text for several."""
    notes, text = sound.heard(_project(), kind, [str(i) for i in ids])
    state.hear_notes = notes
    return {"end": float(notes.end) if notes is not None else 0.0, "status": text,
            "rate": sound.playback.SAMPLE_RATE}


def render_block(which: str, first: int, count: int) -> "np.ndarray":
    """count samples of the performance ("play") or of the notes heard ("hear"),
    from sample first, as float32."""
    notes = state.play_notes if which == "play" else state.hear_notes
    if notes is None:
        return np.zeros(int(count), np.float32)
    return sound.render(notes, first, count)


# ------------------------------------------------------------------ pitch errors

def pitch_panel(pid: Optional[str] = None) -> dict:
    """What the Pitch errors panel shows for performance note pid, or the rules."""
    return pitch.panel(state.project, pid)


# ------------------------------------------------------------------ sections

def section_colours() -> list:
    """The Sections group's colours: annotations.SECTION_COLOURS, by name."""
    return [[name, colour] for name, colour in ann.SECTION_COLOURS.items()]


def section_dialog(index: Optional[int] = None) -> dict:
    """What the window for a section's name and description says (_SectionDialog)."""
    return sections.dialog(_project(), index)


def mark_section(name: str, description: str, colour: str, perf: Optional[list] = None) -> dict:
    """M, or Mark section: a section over the selected performance notes, in colour
    (MainWindow.mark_section), chosen in the list."""
    project = _project()
    try:
        section = ann.new_section(project, set(perf or ()), name, colour, description or "")
    except ann.AnnotationError as exc:
        return {"status": str(exc), "undo": _undo_state()}
    state.editor.set_annotations("sections", project.sections + [section], "Mark a section")
    return _answer(status=f"Marked {ann.section_title(section)}.", section=len(project.sections) - 1)


def edit_section(index: int, name: str, keywords: str) -> dict:
    project = _project()
    index = sections.checked(project, index)
    section = project.sections[index]
    changed = sections.edited(project, index, name, keywords)
    if changed != section:
        state.editor.set_annotations("sections", sections.replaced(project, index, changed),
                                     f"Edit section {section.name}")
    return _answer()


def recolour_section(index: int, colour: str) -> dict:
    project = _project()
    index = sections.checked(project, index)
    section = project.sections[index]
    state.editor.set_annotations("sections", sections.replaced(project, index, dataclasses.replace(section, colour=colour)),
                                 f"Recolour section {section.name}")
    return _answer()


def delete_section(index: int) -> dict:
    """Delete, or the Delete key with a section chosen."""
    project = _project()
    index = sections.checked(project, index)
    name = project.sections[index].name
    state.editor.set_annotations("sections", [s for i, s in enumerate(project.sections) if i != index],
                                 f"Delete section {name}")
    return _answer(section=-1)


def change_pass(index: int, k: int, span: list, edge: int) -> dict:
    """A section's edge dragged in the performance roll and let go: pass k with
    the edge placed as _snapped_span places it (MainWindow._change_pass)."""
    project = _project()
    index = sections.checked(project, index)
    section = project.sections[index]
    passes = list(section.passes)
    placed = sections.snapped(project, span, int(edge))
    if 0 <= k < len(passes) and placed is not None and placed != tuple(passes[k]):
        passes[k] = placed
        state.editor.set_annotations("sections", sections.replaced(project, index, section.with_passes(passes)),
                                     f"Change section {section.name}")
    return _answer()


def find_repetitions() -> dict:
    """Find passages played again and mark them as passes of sections."""
    project = _project()
    found = repeats.find(project)
    if found.new_passes:
        state.editor.set_annotations("sections", found.sections, "Find repetitions")
    return _answer(status=found.summary)


def section_spans(index: int) -> dict:
    """Choosing a section in the list: where the rolls move to (show_section)."""
    project = _project()
    return sections.spans(project, sections.checked(project, index))


def pass_notes(index: int, k: int, unlinked: bool = False) -> dict:
    """A double click on a section's name bar, or a Ctrl/Cmd-click: its pass's notes."""
    project = _project()
    return sections.pass_notes(project, sections.checked(project, index), int(k), bool(unlinked))


def section_missing(index: int) -> "np.ndarray":
    """The chosen section's score notes to draw unlinked while only its links show."""
    project = _project()
    return sections.missing(project, sections.checked(project, index))


# ------------------------------------------------------------------ note grouping

def grouping_choices() -> dict:
    """The Note grouping group's choices: model.GROUPINGS and annotations.ORNAMENT_TYPES."""
    return {"groupings": [[k, v] for k, v in model.GROUPINGS.items()],
            "ornaments": [[k, name] for k, (name, _mark) in ann.ORNAMENT_TYPES.items()]}


def start_marking(group: str, kind: str = "", name: str = "") -> dict:
    """Mark grouping (T): what to mark, {"kind", "label", "onset", "status"}, or
    {"status"} with why an other grouping's name can't be used (_start_marking)."""
    try:
        group, kind, label = grouping.spec(group, kind, name)
    except ann.AnnotationError as exc:
        return {"status": str(exc)}
    onset = group == "improvisation"
    return {"group": group, "kind": kind, "label": label, "onset": onset,
            "status": grouping.marking_status(label, onset)}


def finish_grouping(group: str, kind: str, score_note: str, perf: Optional[list] = None) -> dict:
    """Marking: the score note, or an improvisation's chord, was clicked. The
    selected performance notes become its grouping, linked to it, in one undo
    step, and the new grouping is selected (_finish_ornament). Answers
    {"status"} alone when it can't be marked, and marking goes on."""
    project = _project()
    try:
        change = ann.mark_grouping(project, set(perf or ()), {score_note}, group, kind)
    except ann.AnnotationError as exc:
        return {"status": str(exc), "undo": _undo_state()}
    text = f"Mark {ann.a_grouping(change.ornaments[-1])}"
    state.editor.mark_grouping(change, text)
    return _answer(status=change.summary, done=True, select_ornament=len(project.ornaments) - 1)


def remove_ornaments(ornament: Optional[int] = None, score: Optional[list] = None) -> dict:
    """Remove the selected grouping, or the selected score notes' (Remove, or
    Delete on its box). Its links stay (MainWindow.remove_ornaments)."""
    project = _project()
    targets = grouping.targets(project, ornament, score or ())
    if not targets:
        return {"status": "Click an ornament's box in the performance roll, or its score note, "
                          "to choose what to remove.", "undo": _undo_state()}
    keep = [o for o in project.ornaments if all(o is not t for t in targets)]
    n = editing._plural(len(targets), "ornament")
    state.editor.set_annotations("ornaments", keep, f"Remove {n}")
    return _answer(status=f"Removed {n}. The links stay; to remove them too, select their notes "
                          "and press S.")


# ------------------------------------------------------------------ aligning

def read_file(kind: str, name: str, data) -> dict:
    """A score or performance chosen on the start page: kept in the store, so
    that the new alignment's sources stay, and read as _ReadWorker reads it.
    Answers the copy's key and what was read ("312 notes, 2 parts"), or what's
    wrong in words."""
    if kind not in state.chosen:
        raise LookupError(f"No such kind of file: {kind}")
    state.chosen[kind] = None
    key, root = store.keep({name: data})
    read, problem = aligning.read(kind, root / name, name)
    state.chosen[kind] = read
    return {"key": key, "summary": read.summary if read else "", "problem": problem}


def align_job(method: str) -> dict:
    """Align on the start page: the job for the job worker, a new alignment of the
    files read, and what the progress line says ("Aligning … with Dual DTW…")."""
    score, performance = state.chosen["score"], state.chosen["performance"]
    if score is None or performance is None:
        raise ValueError("Choose a score and a performance first.")
    if method not in _realign_tables()[0] or method == "anchors":
        raise LookupError(f"{method!r} can't make a new alignment")
    state.default_method = method   # the last method used, for the Realign group too
    return {"job": aligning.pickled(("new", score, performance, method)),
            "describe": aligning.describe(score, performance, _method_name(method))}


def install_aligned(result, describe: str, took: str) -> dict:
    """Open the new alignment the job worker made, as MainWindow._aligned does: not
    an undo step, and not exported. Answers what opening answers, with the
    status bar's text."""
    project = aligning.unpickled(result)
    answer = _install(project)
    state.undo.reset_clean()
    answer["undo"] = _undo_state()
    answer["status"] = aligning.aligned_status(project, describe, took,
                                               sidebar.unaligned_counts(project))
    return answer


def set_method(method: str) -> None:
    """The Realign group's method, kept in project.json and as the default for new
    projects (MainWindow._method_changed)."""
    if method not in _realign_tables()[0]:
        raise LookupError(f"unknown method {method!r}")
    state.default_method = method
    if state.project is not None:
        state.project.method = method


def realign_plan(perf: Optional[list] = None, score: Optional[list] = None,
                 method: str = "", min_notes: int = 3) -> dict:
    """R: what realigning the selected notes would do (MainWindow.realign_selection).
    Answers {"status"} with what to select when they can't be realigned, or the
    job for the job worker with the progress text, as _start_realign shows it."""
    import fermata.realign as realign
    project = _project()
    try:
        plan = realign.plan(project, set(perf or ()), set(score or ()), method or project.method,
                            int(min_notes))
    except realign.PlanError as exc:
        return {"status": str(exc)}
    state.realigning = project
    return {"job": aligning.pickled(("realign", project, plan)),
            "text": f"Realigning {plan.summary} with {plan.name}…"}


def realign_done(result) -> dict:
    """Apply a realign result in one undo step, as MainWindow._realign_done does,
    and answer with the status bar's text, or none when another project was
    opened meanwhile."""
    result = aligning.unpickled(result)
    project = state.project
    if project is None or state.realigning is not project:
        return {"status": None, "undo": _undo_state()}
    state.realigning = None
    removed, added = aligning.realign_changes(project, result)
    state.editor.realign(result.plan.name, removed, added)
    return _answer(status=aligning.realign_message(result, removed, added))


def warm_up() -> None:
    """Import realign while nothing waits for it, so that the first R doesn't."""
    import fermata.realign  # noqa: F401


def realign_failed() -> dict:
    """The job failed or was dropped: nothing to apply."""
    state.realigning = None
    return {"undo": _undo_state()}


def close_project(view: Optional[dict] = None, pending: bool = False) -> None:
    """No project open, as the desktop's show_start_page leaves it: going back to
    the start page closes the project, and ends its session (_end_session): with a
    backup still pending, it's written first."""
    if pending:
        backup(view)
    _end_session(view)
    state.project = None
    state.derived = None
    state.editor = None
    state.undo.clear()


def _project() -> model.Project:
    if state.project is None:
        raise LookupError("No project is open.")
    return state.project


def hover_status(note: Optional[list] = None, link: Optional[list] = None,
                 hidden: Optional[list] = None, ornament: Optional[int] = None,
                 marking: Optional[dict] = None, onset: Optional[str] = None,
                 selected: bool = False) -> str:
    """The status bar's text for what the pointer is on in the rolls: a note as
    [kind, row], a grouping's box by its index, or a link as [score id,
    performance id]. hidden: the links hidden with H, as [score id, performance
    id] pairs. While marking ({"label", "onset"}): the chord under the pointer
    by its lowest note, onset, and whether performance notes are selected, as
    RollWidget._hover_status has it."""
    project = _project()
    if marking and marking.get("onset") and onset is not None:
        return grouping.onset_status(project, onset, selected)
    if marking and not marking.get("onset") and note is not None and note[0] == "score":
        return grouping.note_status(project, marking["label"], int(note[1]), selected)
    if note is None and ornament is not None and 0 <= ornament < len(project.ornaments):
        return grouping.box_status(project.ornaments[ornament])
    if state.derived is None:
        state.derived = status.Derived(project)
    return status.hover_status(project, state.derived, note=note, link=link,
                               hidden=[(str(s), str(p)) for s, p in hidden or ()])


def open_example() -> dict:
    """Open the example FERMATA comes with, as Open the example does on the desktop."""
    return _install(model.load(model.EXAMPLE_MATCH, score=model.EXAMPLE_SCORE))


def _open_folder(folder, key: str) -> dict:
    """Open a Parangonada folder kept in the store. As on the desktop
    (MainWindow.open_project), any problem opening it is a message for the user.
    The answer's "key" names the copy and "folder" the folder, for Recent."""
    try:
        project = model.load_parangonada(folder)
    except Exception as exc:
        raise ValueError(f"{folder.name} couldn't be opened.\n\n{exc}") from exc
    return {**_install(project), "key": key, "folder": folder.name}


def open_parangonada(name: str, files: dict) -> dict:
    """Open a folder of Parangonada CSV files that the page read: name is the
    folder's name, files its files ({name: bytes}). They're kept in the site's
    storage first; the answer's "key" names the copy, for Recent."""
    key, root = store.keep({f"{name}/{file}": data for file, data in files.items()})
    return _open_folder(root / name, key)


def open_zip(name: str, data) -> dict:
    """Open a zip of a Parangonada folder: its CSV and JSON files at its top, as
    Parangonada takes them, or in its one folder, as Finder's Compress and
    Windows' Send to Compressed Folder make it (leaving out __MACOSX). The folder
    is named after that folder, or after the zip. The files are kept first."""
    folder = Path(name).stem
    try:
        with zipfile.ZipFile(io.BytesIO(bytes(data))) as z:
            entries = [i for i in z.infolist()
                       if not i.is_dir() and not i.filename.startswith("__MACOSX/")]
            wanted = lambda n: n.lower().endswith((".csv", ".json"))   # noqa: E731
            chosen = {i.filename: z.read(i) for i in entries if "/" not in i.filename and wanted(i.filename)}
            if not set(chosen) & set(model.PARANGONADA_FILES):
                inside = [i for i in entries if i.filename.count("/") == 1]
                tops = {i.filename.split("/")[0] for i in inside}
                if len(tops) == 1:
                    folder = tops.pop()
                    chosen = {i.filename.split("/")[1]: z.read(i) for i in inside if wanted(i.filename)}
    except Exception as exc:
        raise ValueError(f"{name} couldn't be opened.\n\n{exc}") from exc
    key, root = store.keep({f"{folder}/{file}": data for file, data in chosen.items()})
    return _open_folder(root / folder, key)


def prepare_match(name: str, files: dict) -> dict:
    """Keep a .match file the page read, with the side files among the files that
    came with it ({name: bytes}), and say which score names to look for:
    {"key", "name", "names"}."""
    if not matches.is_match(name):   # as model.load says it, inside open_project's message
        raise ValueError(f"{name} couldn't be opened.\n\n"
                         f"{name} isn't a .match file or a folder of Parangonada CSV files.")
    key, path = matches.keep_match(name, files)
    return {"key": key, "name": path.name, "names": matches.score_names(path)}


def find_score(listing: list, names: list) -> Optional[str]:
    """The score in the score folder, from the page's listing of it (paths relative
    to the folder): the relative path model.find_score picks, or None."""
    return matches.find_in_listing([str(p) for p in listing], [str(n) for n in names])


def ask_score_why(key: str, folder: bool) -> str:
    """Why the score of a kept .match file is asked for: with folder, a score
    folder is chosen and the score isn't in it."""
    return matches.ask_why(matches.match_in(store.kept(key)), folder)


def open_match(key: str, score: Optional[dict] = None, score_key: str = "", asked: bool = True,
               found: bool = False) -> dict:
    """Open a kept .match file with its score: score {"name", "data"} as the page
    read it, which is kept first, or score_key, a score kept before (Recent's).
    A score without data is one the score folder listed but the page couldn't
    read: model.load then says it can't be found, as the desktop would.
    asked: the score was looked for or asked for, rather than given; found: it's
    the one found in the score folder. The answer is the opened project, with the
    keys of both copies, or {"ask": why} when the score can't be used and another
    should be asked for, as the desktop's open_project asks."""
    match = matches.match_in(store.kept(key))
    if score is not None and score.get("data") is None:
        score_path = Path(tempfile.mkdtemp(prefix="fermata-gone-")) / Path(str(score["name"])).name
    elif score is not None:
        score_key, root = store.keep({str(score["name"]): score["data"]})
        score_path = root / str(score["name"])
    else:
        score_path = matches.score_in(store.kept(score_key))
    project, why = matches.load(match, score_path, asked, found)
    if project is None:
        return {"ask": why}
    return {**_install(project), "key": key, "score_key": score_key, "score": score_path.name}


def match_info(key: str) -> dict:
    """A kept .match file's name, and the score names it looks for, as
    prepare_match answers: for opening it again from Recent."""
    match = matches.match_in(store.kept(key))
    return {"key": key, "name": match.name, "names": matches.score_names(match)}


def open_kept(key: str) -> dict:
    """Open a Parangonada folder's copy kept in the site's storage again, as Recent does."""
    root = store.kept(key)
    folders = sorted(p for p in root.iterdir() if p.is_dir())
    if len(folders) != 1:
        raise ValueError("Its copy in this browser's storage can't be read. Open the file again.")
    return _open_folder(folders[0], key)


def copies() -> list:
    """The keys of the copies kept in the site's storage."""
    return store.keys()


def forget_copies(keep: list) -> list:
    """Free every copy but those whose keys are in keep, and return the keys freed."""
    return store.keep_only([str(k) for k in keep] + sorted(saving.referenced_keys()))


def _no_match_export() -> str:
    """Why the open work can't be exported as a .match file, as MainWindow's
    _no_match_export says it for a project opened from Parangonada CSV files.
    (Work opened from its backup alone comes with Phase 5.)"""
    return ("A .match file needs the full score. This project was opened from "
            "Parangonada CSV files, which only have note lists: open it from a .match "
            "file to export one.")


def export_names() -> dict:
    """What exporting a .match file suggests (model.match_export_names: the folder,
    the file and the three info lines), or why it can't be exported as one."""
    project = _project()
    if not model.can_export_match(project):
        return {"refused": _no_match_export()}
    return {"names": model.match_export_names(project)}


def _zip(folder: Path) -> "np.ndarray":
    """The folder's files in a zip, at its top, as Parangonada takes them."""
    data = io.BytesIO()
    with zipfile.ZipFile(data, "w", zipfile.ZIP_DEFLATED) as z:
        for path in sorted(folder.iterdir()):
            if path.is_file():
                z.write(path, path.name)
    return np.frombuffer(data.getvalue(), np.uint8)


def export_match(info: dict) -> dict:
    """Export as a .match file (model.export_match), with the info lines given,
    into the folder match_export_names names, and answer it as a zip to
    download, named after the folder, with the status bar's text, as
    MainWindow.export_match does. The work then counts as exported."""
    project = _project()
    if not model.can_export_match(project):
        raise ValueError(f"{_no_match_export()} Export as Parangonada CSV files instead.")
    # As _MatchInfoDialog.values gives them: an empty one is "-", as .match files write it.
    info = {str(k): str(v).strip().replace(",", "_") or "-" for k, v in info.items()}
    names = model.match_export_names(project)
    folder = Path(tempfile.mkdtemp(prefix="fermata-export-")) / names["folder"]
    path = folder / names["file"]
    try:
        model.export_match(project, path, info)
    except Exception as exc:
        raise ValueError(f"Exporting {names['folder']} failed.\n\n{exc}") from exc
    project.match_header.setdefault("info", {}).update(info)   # the next export suggests it
    note = ""
    if project.pinned_anchors():
        note = " Its anchors aren't in it: .match files have no place for them."

    def beats(o):   # not the id: exporting numbers them anew
        return o["start_in_beats_unfolded"], o["end_in_beats_unfolded"]
    known = {beats(o) for o in project.match_header.get("omitted_sections", [])}
    omitted = [o for o in repeats.omitted_sections(project) if beats(o) not in known]
    if omitted:
        note += (f" {editing._plural(len(omitted), 'stretch', 'stretches')} of the score nobody "
                 "played went in as omitted sections.")
    _exported(f"{names['folder']}.zip")
    return {"zip": f"{names['folder']}.zip", "data": _zip(folder),
            "status": f"Exported to {names['folder']}.zip.{note}", "undo": _undo_state()}


def export_parangonada() -> dict:
    """Export as Parangonada CSV files (model.export_project) into a folder named
    after the project, and answer it as a zip to download, as
    MainWindow.export_csv does. The work then counts as exported."""
    project = _project()
    folder = Path(tempfile.mkdtemp(prefix="fermata-export-")) / project.name
    try:
        model.export_project(project, folder)
    except Exception as exc:
        raise ValueError(f"Exporting {project.name} failed.\n\n{exc}") from exc
    _exported(f"{project.name}.zip")
    return {"zip": f"{project.name}.zip", "data": _zip(folder),
            "status": f"Exported the Parangonada CSV files to {project.name}.zip.",
            "undo": _undo_state()}


def _method_name(key: Optional[str]) -> str:
    """A realign method's name, as realign.METHODS has it."""
    return _realign_tables()[0].get(key or "", (key or "-",))[0]


def project_info(exported: str = "") -> list:
    """File > Project info…'s rows, as MainWindow.show_project_info has them. A
    browser has no paths, so the files show by name; exported: the zip the work
    was last exported to, as the page knows it."""
    project = _project()
    sources = project.sources
    name = lambda path: Path(path).name if path else ""   # noqa: E731
    opened = (name(project.source) if project.source
              else "a new alignment of the score and performance files" if project.pair else "-")
    return [["Opened from", opened],
            ["First opened from", name(sources.get("original")) or "-"],
            ["Score file", name(sources.get("score")) or "not known"],
            ["Performance file", name(sources.get("performance")) or "not known"],
            ["Realign method", _method_name(project.method)],
            ["Sections", str(len(project.sections))],
            ["Exported to", exported or "not exported yet"],
            ["Saved for later", "no"]]


METHODS = {f.__name__: f for f in (version_info, counts, open_example, open_parangonada, open_zip,
                                     prepare_match, find_score, ask_score_why, open_match, match_info,
                                     open_kept, copies, forget_copies, close_project, hover_status,
                                     link_selection, link_drag, unlink_selection, toggle_anchors,
                                     hide_links, show_all_links, undo, redo, sidebar_texts,
                                     export_names, export_match, export_parangonada, project_info,
                                     default_method, read_file, align_job, install_aligned, set_method,
                                     realign_plan, realign_done, realign_failed, warm_up,
                                     grouping_choices, start_marking, finish_grouping,
                                     remove_ornaments, add_comment, comment_spans, reply_comment,
                                     edit_comment, toggle_resolved, delete_comment, comment_text,
                                     section_colours, section_dialog, mark_section, edit_section,
                                     recolour_section, delete_section, change_pass, find_repetitions,
                                     section_spans, pass_notes, section_missing, pitch_panel,
                                     backup, save_for_later, saved_work, saved_for, continue_saved,
                                     stop_offering, leftovers, restore_leftover, dont_restore, prune,
                                     backups_zip, sound_ready, install_soundfont, play, hear, render_block)}


def _is_user_error(exc: BaseException) -> bool:
    if isinstance(exc, ValueError):
        return True
    realign = sys.modules.get("fermata.realign")   # imported only once something realigns
    return realign is not None and isinstance(exc, realign.PlanError)


def dispatch(method: str, args: Any = None) -> dict:
    """Call method with args (a dict of keyword arguments, or None)."""
    try:
        function = METHODS.get(method)
        if function is None:
            raise LookupError(f"No such call: {method}")
        return {"ok": True, "result": function(**(args or {}))}
    except Exception as exc:
        if _is_user_error(exc):
            return {"ok": False, "error": {"kind": "user", "message": str(exc), "details": ""}}
        return {"ok": False, "error": {"kind": "bug", "message": f"{type(exc).__name__}: {exc}",
                                       "details": traceback.format_exc()}}
