"""What the canvas draws, worked out from the open project: the view model
(web/PLAN.md, "View model"). The canvas keeps no rules about the data of its
own: which notes are linked, which are linked to another pitch and which links
are anchors all come from here, through fermata's own functions where it has
them.

The arrays go to the page as typed arrays: float64 for times, int32 for rows,
uint8 for pitches, states and flags. (Pyodide makes int64 arrays BigInt64Arrays
and bool arrays plain arrays, so neither is used.)
"""
from __future__ import annotations

import numpy as np

from fermata import repeats
from fermata.annotations import grouping_mark, ornament_mark, pitch_name
from fermata.model import NoteTrack, Project

from . import comments as _comments
from . import sections as _sections

# A note's state, by which the canvas colours it: roll_widget.py's groups in
# _draw_notes, apart from the selection, which the page keeps. Mirrored in
# web/src/canvas/view-model.ts.
UNLINKED, LINKED, OTHER_PASS, MISMATCH = 0, 1, 2, 3
# A link's flags, likewise.
LINK_MISMATCH, LINK_ANCHOR = 1, 2


def _track(track: NoteTrack, state: np.ndarray) -> dict:
    """One roll's notes as columns, in the track's order (by onset)."""
    lo, hi = track.pitch_range
    return {"ids": [str(i) for i in track.ids],
            "onset": track.onset.astype(np.float64), "offset": track.offset.astype(np.float64),
            "pitch": track.pitch.astype(np.uint8), "state": state.astype(np.uint8),
            "start": track.start, "end": track.end, "max_duration": track.max_duration,
            "pitch_lo": lo, "pitch_hi": hi}


def _overlap_depth(track: NoteTrack) -> np.ndarray:
    """Per note, how deep it lies in notes of its pitch that each start inside
    the one before: 0 for a note that starts inside none, else one more than the
    deepest it starts inside. Drawn in that order, a later note is never hidden
    under a longer one that began before it. Notes on the same beat are level,
    and so are notes that only touch, give or take a float's rounding.
    roll_widget.py's _overlap_depth (web/PLAN.md, "Logic that exists twice")."""
    depth = np.zeros(len(track), int)
    onset, offset = track.onset.tolist(), track.offset.tolist()
    begun: dict[int, list] = {}   # pitch: the rows begun before that still sound
    for row in np.lexsort((track.onset, track.pitch)).tolist():
        notes = begun.setdefault(int(track.pitch[row]), [])
        notes[:] = [r for r in notes if offset[r] > onset[row] + 1e-3]
        inside = [depth[r] for r in notes if onset[r] < onset[row] - 1e-3]
        depth[row] = max(inside) + 1 if inside else 0
        notes.append(row)
    return depth


def _mismatch_links(project: Project, links: list, prow: np.ndarray,
                    srow: np.ndarray) -> np.ndarray:
    """Per link, whether it goes to a note of another pitch, a pitch error say.
    A link between an ornament's score and performance notes, such as a trill's
    upper notes, doesn't count: they're meant to differ. RollWidget._pitch_mismatch
    on the desktop (web/PLAN.md, "Logic that exists twice")."""
    perf, score = project.performance, project.score
    ornate = {(s, p) for o in project.ornaments for s in o.score for p in o.performance}
    differ = perf.pitch[prow] != score.pitch[srow]
    return differ & np.fromiter((link not in ornate for link in links), bool, len(links))


def full(project: Project) -> dict:
    """The whole view model, as the page gets it when a project opens: both
    rolls' notes with their states, the links between them, and the pitch names."""
    part = edited(project)
    score = _track(project.score, part["score_state"])
    # The layer each score note is drawn in; the score notes never change.
    score["depth"] = np.minimum(_overlap_depth(project.score), 255).astype(np.uint8)
    return {"perf": _track(project.performance, part["perf_state"]),
            "score": score,
            "links": part["links"], "ornaments": part["ornaments"], "comments": part["comments"],
            "sections": part["sections"],
            "notated": notated(project),
            "pitch_names": [pitch_name(p) for p in range(128)]}


def ornaments(project: Project) -> list:
    """Each grouping's box in the performance roll (_draw_ornaments): the rows of its
    performance notes and its mark (tr, continuo, impro, or the name given), in
    project.ornaments' order, by which the page names the selected one."""
    perf = project.performance
    return [{"rows": np.array([perf.row[i] for i in o.performance if i in perf.row], np.int32),
             "mark": grouping_mark(o)} for o in project.ornaments]


def notated(project: Project) -> list:
    """The ornaments written in the score (_draw_notated): per score note, its row,
    and each ornament's type with its short name (for the rarer ones, whose sign
    is their name) and its sign's tooltip."""
    from .grouping import notated_text
    score = project.score
    return [{"row": int(score.row[sid]), "kinds": list(kinds),
             "marks": [ornament_mark(k) for k in kinds],
             "texts": [notated_text(project, sid, k) for k in kinds]}
            for sid, kinds in project.notated.items() if sid in score.row]


def edited(project: Project) -> dict:
    """What an edit of the links changes in the view model: the notes' states and
    the links, which the page puts in place of its own."""
    perf, score = project.performance, project.score
    links = sorted(project.alignment.links)   # in RollWidget._refresh_alignment's order
    n = len(links)
    prow = np.fromiter((perf.row[p] for _, p in links), np.int32, n)
    srow = np.fromiter((score.row[s] for s, _ in links), np.int32, n)
    mismatch = _mismatch_links(project, links, prow, srow)
    anchors = project.pinned_anchors()
    flags = (mismatch * LINK_MISMATCH
             + np.fromiter((link in anchors for link in links), bool, n) * LINK_ANCHOR)

    states = {}
    for kind, track, rows in (("perf", perf, prow), ("score", score, srow)):
        aligned = project.aligned_mask(kind)
        mismatched = np.zeros(len(track), bool)
        mismatched[rows[mismatch]] = True
        other = (repeats.other_pass_mask(project, aligned) if kind == "perf"
                 else np.zeros(len(track), bool))
        states[kind] = np.where(aligned, np.where(mismatched, MISMATCH, LINKED),
                                np.where(other, OTHER_PASS, UNLINKED))
    return {"perf_state": states["perf"].astype(np.uint8), "score_state": states["score"].astype(np.uint8),
            "links": {"perf": prow, "score": srow, "flags": flags.astype(np.uint8)},
            "ornaments": ornaments(project), "comments": _comments.view(project),
            "sections": _sections.view(project)}
