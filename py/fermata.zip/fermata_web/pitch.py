"""The Pitch errors panel's contents (fermata/pitch_panel.py: PitchPanel.show_note
and _Ladder's rows), from annotations.pitch_check: the clicked performance
note's title, the ladder of pitches around it with what a score note on each
would make of it, its score partners, and what the rules make of its links.
The page draws the ladder.
"""
from __future__ import annotations

from typing import Optional

from fermata import annotations as ann
from fermata.model import Project

BEYOND = 3     # pitches shown past the range on each side (pitch_panel.BEYOND)
REACH = ann.PITCH_ERROR_RANGE + BEYOND
BLACK = {1, 3, 6, 8, 10}


def panel(project: Optional[Project], pid: Optional[str]) -> dict:
    """What the panel shows for performance note pid, or with None, the rules."""
    if project is None or pid is None or pid not in project.performance.row:
        return {"title": "Which score pitches a performance note can be a pitch error of.", "bold": "",
                "pitch": None, "rows": [], "partners": [],
                "verdict": f"A note played up to {ann.PITCH_ERROR_RANGE} semitones from the score note it "
                           "was meant to be is a pitch error, and is linked to it. Farther off, it's an "
                           "insertion, unless a whole passage is played an octave off.",
                "reach": REACH, "beyond": BEYOND, "range": ann.PITCH_ERROR_RANGE}
    check = ann.pitch_check(project, pid)
    rows = [{"off": off, "name": ann.pitch_name(check.pitch + off), "kind": ann.pitch_error_kind(off),
             "black": (check.pitch + off) % 12 in BLACK} for off in range(REACH, -REACH - 1, -1)]
    partners = [[sid, p, ann.pitch_name(p)] for sid, p in check.partners]
    return {"title": f", {ann.pitch_name(check.pitch)}", "bold": f"Performance note {pid}",
            "pitch": check.pitch, "rows": rows, "partners": partners, "verdict": check.verdict,
            "reach": REACH, "beyond": BEYOND, "range": ann.PITCH_ERROR_RANGE}
