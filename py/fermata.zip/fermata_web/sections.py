"""Sections and their passes, as MainWindow's Sections group handles them
(fermata/main_window.py: mark_section, _SectionDialog, _change_pass,
find_repetitions, _go_to_section, edit_section, recolour_section,
delete_section) with RollWidget's views of them (_section_spans, show_section,
_select_pass_notes, _snapped_span, _unlinked_in_chosen_section). The rules are
annotations.py's and repeats.py's; the page keeps which section is chosen, and
on which pass, as the sidebar's list and RollWidget.sel_section do.
"""
from __future__ import annotations

import dataclasses
from typing import Optional

import numpy as np

from fermata import annotations as ann
from fermata import repeats
from fermata.model import Project

from .editing import _plural


def view(project: Project) -> list:
    """Each section as the page draws it: its colour, its passes in seconds with
    each one's label in the performance roll and whether it's a pass that isn't
    aligned, its score side in beats, and its line in the sidebar's list
    (_section_spans, _refresh_annotations)."""
    out = []
    for section in project.sections:
        passes = [list(map(float, span)) for span in section.passes]
        aligned = repeats.aligned_pass(project, section)
        if len(passes) < 2:
            labels, other = [section.name] * len(passes), [False] * len(passes)
        else:
            labels = [f"{section.name}, {repeats.pass_name(k)}" + (", aligned" if k == aligned else "")
                      for k in range(len(passes))]
            other = [aligned is not None and k != aligned for k in range(len(passes))]
        score = repeats.score_beats(project, section)
        out.append({"colour": section.colour, "name": section.name, "passes": passes, "labels": labels,
                    "other": other, "aligned": aligned, "score": list(score) if score else None,
                    "title": ann.section_title(section)})
    return out


def checked(project: Project, index: Optional[int]) -> int:
    if index is None or not 0 <= index < len(project.sections):
        raise LookupError(f"No such section: {index}")
    return index


def dialog(project: Project, index: Optional[int]) -> dict:
    """The window for a section's name and description (_SectionDialog): a new
    section's (index None), or section index's, with the ids its lines would get."""
    if index is None:
        return {"title": "Mark a section", "name": f"Section {len(project.sections) + 1}", "keywords": "",
                "placeholder": ann.DEFAULT_SECTION_KEYWORD,
                "hint": "The name is only for you. The description, keywords separated by commas, describes "
                        "the section in .match files, in its line's SectionAttrList. Left empty, it's "
                        f"{ann.DEFAULT_SECTION_KEYWORD}."}
    section = project.sections[checked(project, index)]
    ids = repeats.section_ids(project)[index]
    where = (f"it's {ids[0]}" if len(ids) == 1 else
             f"its passes are {', '.join(ids[:-1])} and {ids[-1]}" if ids else "it gets an id")
    return {"title": f"Edit section {section.name}", "name": section.name,
            "keywords": ", ".join(section.attributes), "placeholder": "rehearsal_repetition, theme",
            "hint": "The name is only for you. The description, keywords separated by commas, describes the "
                    f"section in .match files, where {where} if you export now: sections are numbered in "
                    "the order they're played."}


def replaced(project: Project, index: int, section) -> list:
    sections = list(project.sections)
    sections[index] = section
    return sections


def edited(project: Project, index: int, name: str, keywords: str):
    """The section with a new name (an empty one keeps the old) and keywords."""
    section = project.sections[index]
    return dataclasses.replace(section, name=name.strip() or section.name,
                               attributes=ann.parse_keywords(keywords))


def snapped(project: Project, span, edge: int) -> Optional[tuple]:
    """A pass's span with its dragged edge placed (_snapped_span): the start snaps
    to the onset of the first note played from there on, so the pass begins with
    a note; the end stays where it was dropped. None if no note would start in it."""
    perf = project.performance
    start, end = float(span[0]), float(span[1])
    if edge == 0:
        first = int(np.searchsorted(perf.onset, start, "left"))
        if first >= len(perf):
            return None
        start = float(perf.onset[first])
    rows = repeats.pass_rows(project, (start, end))
    return (start, end) if len(rows) and start < end else None


def spans(project: Project, index: int) -> dict:
    """Where choosing section index in the list moves the rolls (show_section): the
    performance roll to its aligned pass (its first if none is), the score roll to
    the bars its links go to, or else through the time map (_show_spans)."""
    section = project.sections[index]
    perf_span = None
    if section.passes:
        k = repeats.aligned_pass(project, section)
        perf_span = tuple(section.passes[0 if k is None else k])
    score_span = repeats.score_beats(project, section)
    tm = project.time_map() if perf_span is None or score_span is None else None
    if score_span is None and perf_span is not None:
        score_span = (tm.to_score(perf_span[0]), tm.to_score(perf_span[1]))
    if perf_span is None and score_span is not None:
        perf_span = (tm.to_perf(score_span[0]), tm.to_perf(score_span[1]))
    out = {}
    if perf_span is not None:
        out["perf"] = [float(perf_span[0]), float(perf_span[1])]
    if score_span is not None:
        out["score"] = [float(score_span[0]), float(score_span[1])]
    return out


def pass_notes(project: Project, index: int, k: int, unlinked: bool) -> dict:
    """The performance notes with an onset in pass k of section index, or only
    those without a link, with the status bar's text (_select_pass_notes)."""
    section = project.sections[index]
    if not 0 <= k < len(section.passes):
        raise LookupError(f"No such pass: {k}")
    rows = repeats.pass_rows(project, section.passes[k])
    if unlinked:
        rows = rows[~project.aligned_mask("perf")[rows]]
    which = " without a link" if unlinked else ""
    status = (f"Selected {_plural(len(rows), 'performance note')}{which} of section {section.name}."
              if len(rows) else f"Section {section.name} has no performance notes{which}.")
    return {"rows": rows.astype(np.int32), "status": status}


def missing(project: Project, index: int) -> np.ndarray:
    """While section index is chosen with only its links shown: the rows of its
    score side's notes without a link to one of its performance notes, which are
    drawn unlinked (_unlinked_in_chosen_section)."""
    section = project.sections[index]
    perf, score, by_perf = project.performance, project.score, project.alignment.by_perf
    linked = {s for span in section.passes for p in perf.ids[repeats.pass_rows(project, span)]
              for s in by_perf.get(p, ())}
    rows = [int(r) for span in section.passes for r in repeats.pass_score_rows(project, span)
            if str(score.ids[r]) not in linked]
    return np.array(sorted(set(rows)), np.int32)
