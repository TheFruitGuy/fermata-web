"""Backups, restoring after a crash, and work saved for later, as MainWindow does
them with fermata/session.py, which runs here as it is (_backup, _end_session,
save_for_later, _keep_now, _fill_continue_menu, continue_saved, stop_offering,
_offer_saved_work_on, _continue, offer_restore, _restore, _confirm_close).

The sessions live in the core worker's storage, /persist/sessions. A desktop
FERMATA keeps other running FERMATAs off a session with its QLockFile; in the
browser, where the stand-in QLockFile is always free, each tab holds a Web Lock
for its own session's folder, and the page says which folders other tabs hold
(held): session.py's _take_lock finds those taken, as QLockFile would.

An export is a zip the browser downloads, which session.py can't see on disk:
each export leaves a marker file of its name in /persist/exports, so that
"exported to <name>.zip" holds as session.py checks it.
"""
from __future__ import annotations

import contextlib
import re
from pathlib import Path
from typing import Iterable, Optional

from fermata import session

from . import files as store


def root() -> Path:
    """The sessions' folder, beside the store's copies."""
    return store.store().parent / "sessions"


def exports() -> Path:
    return store.store().parent / "exports"


def export_marker(name: str) -> Path:
    """The marker of an export downloaded as name, made now."""
    folder = exports()
    folder.mkdir(parents=True, exist_ok=True)
    marker = folder / Path(name).name
    marker.touch()
    return marker


@contextlib.contextmanager
def held(folders: Iterable[str] = ()):
    """While this runs, the sessions other tabs hold, by folder name, can't be
    locked, as a QLockFile another FERMATA holds can't be."""
    taken = set(folders or ())
    original = session._take_lock

    def take(folder: Path):
        return None if Path(folder).name in taken else original(folder)

    session._take_lock = take
    try:
        yield
    finally:
        session._take_lock = original


def describe(left: session.Leftover) -> dict:
    """A piece of saved work as the start page's Continue list shows it (_saved_row)."""
    exported = left.export_path is not None and not left.unexported
    origin, paths = left.opened_from
    change = f"last change {left.updated}" if origin else f"Last change {left.updated}"
    state = f"exported to {left.export_path.name}" if exported else "not exported"
    return {"folder": left.folder.name, "name": left.name, "updated": left.updated,
            "detail": ", ".join(part for part in (origin, change, state) if part),
            "files": "\n".join(Path(p).name for p in paths.splitlines()) if paths else ""}


def saved_state(left: session.Leftover) -> str:
    """MainWindow._saved_state."""
    text = f"Its last change was on {left.updated}"
    if left.export_path is not None and not left.unexported:
        return f"{text}, and it's exported to {left.export_path.name}."
    return f"{text}, and it has changes that aren't exported."


def referenced_keys() -> set[str]:
    """The keys of the store's copies that any session's files name: the files
    its work was opened from, which restoring and continuing open again."""
    keys = set()
    pattern = re.compile(r"files[\\/]+([0-9a-f]{24})")
    for folder in session._folders(root()):
        for name in (session.SESSION_FILE, "project.json"):
            try:
                keys.update(pattern.findall((folder / name).read_text(encoding="utf-8")))
            except OSError:
                pass
    return keys


def not_reopened(left: session.Leftover, done: str) -> Optional[dict]:
    """The box after work was continued or restored (done) from its backup alone
    (_say_not_reopened), or None. The report is the reason itself: a browser has
    no system or paths to add."""
    if not left.not_reopened:
        return None
    files = "its score and MIDI file" if left.info.get("pair") else "its .match file"
    return {"title": f"Work {done} from its backup",
            "text": f"FERMATA {done} your work on {left.name} from its backup alone, without {files}, so it "
                    "can't be exported as a .match file now. Exporting as Parangonada CSV files works, and "
                    "nothing of your work is lost.",
            "informative": f"{left.not_reopened.splitlines()[0]}\n\nThe copy of {files} in this browser's "
                           "storage couldn't be opened again. Open the file again to export it as a .match file.",
            "details": left.not_reopened}
