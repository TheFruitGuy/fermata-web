"""The web version's undo stack: the edits of fermata_web/edits.py, as the
desktop's QUndoStack keeps them.

push() makes an edit and keeps it; undo() and redo() move through them. Edits
pushed between begin_macro() and end_macro() undo and redo as one step, and
macros can be nested. set_clean() marks the current state, as an export does,
and is_clean says whether the work is back there. on_change is called after
every change to the stack, as QUndoStack's indexChanged starts the backup
timer on the desktop.
"""
from __future__ import annotations

from typing import Callable, Optional

from .edits import Edit


class Macro(Edit):
    """Edits made as one step: undone in the reverse order."""

    def __init__(self, text: str):
        self.text = text
        self.edits: list[Edit] = []

    def redo(self):
        for edit in self.edits:
            edit.redo()

    def undo(self):
        for edit in reversed(self.edits):
            edit.undo()


class UndoStack:
    def __init__(self, on_change: Optional[Callable[[], None]] = None):
        self.on_change = on_change
        self._edits: list[Edit] = []
        self._index = 0          # how many of _edits are done
        self._clean: Optional[int] = 0   # the index that is clean, None once it can't come back
        self._macros: list[Macro] = []   # open macros, innermost last

    def _changed(self):
        if self.on_change is not None:
            self.on_change()

    def push(self, edit: Edit) -> None:
        """Make edit and keep it: in the open macro, or as the next step,
        dropping the steps that were undone."""
        edit.redo()
        if self._macros:
            self._macros[-1].edits.append(edit)
            return
        self._add(edit)

    def _add(self, edit: Edit) -> None:
        del self._edits[self._index:]
        if self._clean is not None and self._clean > self._index:
            self._clean = None
        self._edits.append(edit)
        self._index += 1
        self._changed()

    def begin_macro(self, text: str) -> None:
        self._macros.append(Macro(text))

    def end_macro(self) -> None:
        macro = self._macros.pop()
        if self._macros:
            self._macros[-1].edits.append(macro)
        else:
            self._add(macro)

    @property
    def in_macro(self) -> bool:
        return bool(self._macros)

    @property
    def can_undo(self) -> bool:
        return self._index > 0 and not self._macros

    @property
    def can_redo(self) -> bool:
        return self._index < len(self._edits) and not self._macros

    @property
    def undo_text(self) -> str:
        return self._edits[self._index - 1].text if self.can_undo else ""

    @property
    def redo_text(self) -> str:
        return self._edits[self._index].text if self.can_redo else ""

    def undo(self) -> None:
        if not self.can_undo:
            return
        self._index -= 1
        self._edits[self._index].undo()
        self._changed()

    def redo(self) -> None:
        if not self.can_redo:
            return
        self._edits[self._index].redo()
        self._index += 1
        self._changed()

    @property
    def index(self) -> int:
        return self._index

    def __len__(self) -> int:
        return len(self._edits)

    def set_clean(self) -> None:
        self._clean = self._index
        self._changed()

    def reset_clean(self) -> None:
        """No step is clean any more, as QUndoStack.resetClean: a new alignment
        isn't exported, so it has changes even before its first edit."""
        self._clean = None
        self._changed()

    @property
    def is_clean(self) -> bool:
        """Whether the work is as it was at set_clean(). Never while a macro is open, as in Qt."""
        return self._clean == self._index and not self._macros

    def clear(self) -> None:
        """Forget every step, as when another project is opened. The work as it is now is clean."""
        self._edits.clear()
        self._index = 0
        self._clean = 0
        self._macros.clear()
        self._changed()
