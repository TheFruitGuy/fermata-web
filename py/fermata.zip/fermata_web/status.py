"""The status bar's texts for what the pointer is on in the rolls: a note or a
link. On the desktop they're RollWidget._describe, _unlinked_status, the link
texts of _hover_status and _groupings_by_note (fermata/roll_widget.py); here they
work from the project and the page's state it sends, the hidden links (H), and
the page shows them (web/PLAN.md, "Logic that exists twice").
"""
from __future__ import annotations

from typing import Iterable, Optional

from fermata import repeats
from fermata.annotations import a_grouping, a_ornament, pitch_name
from fermata.model import Link, Project


def fmt_time(t: float) -> str:
    """roll_widget.fmt_time: two decimals at most, without trailing zeros."""
    return f"{t:.2f}".rstrip("0").rstrip(".")


class Derived:
    """What the texts need that takes a pass over every note, worked out once for
    the project as it is: per performance note whether it's in a pass that isn't
    aligned, each section's aligned pass, and each note's grouping. Make a new one
    whenever the links or the annotations change."""

    def __init__(self, project: Project):
        self.other_pass = repeats.other_pass_mask(project, project.aligned_mask("perf"))
        self.aligned_pass = [repeats.aligned_pass(project, s) for s in project.sections]
        self.grouping: dict[tuple[str, str], object] = {}
        for orn in project.ornaments:
            self.grouping.update({("score", i): orn for i in orn.score})
            self.grouping.update({("perf", i): orn for i in orn.performance})


def _unlinked_status(project: Project, derived: Derived, row: int) -> str:
    """Why a performance note has no link."""
    if derived.other_pass[row]:
        t = project.performance.onset[row]
        for section, aligned in zip(project.sections, derived.aligned_pass):
            for k, span in enumerate(section.passes):
                if aligned is not None and k != aligned and span[0] <= t <= span[1]:
                    return (f"no link: {repeats.pass_name(k)} of section {section.name}; "
                            f"{repeats.pass_name(aligned)} is the aligned one")
    return "no link (extra note in the performance)"


def describe_note(project: Project, derived: Derived, kind: str, row: int,
                  hidden: Iterable[Link] = ()) -> str:
    """A note: its id, pitch and time, its partners (marked when they're anchors
    or their links are hidden), and the grouping, notated ornaments and comments
    it's in."""
    hidden = set(hidden)
    track, al = (project.performance if kind == "perf" else project.score), project.alignment
    nid, name = track.ids[row], pitch_name(int(track.pitch[row]))
    ornament = derived.grouping.get((kind, str(nid)))
    extra = f", part of {a_grouping(ornament)}" if ornament else ""
    if kind == "score" and str(nid) in project.notated:
        written = " and ".join(a_ornament(k) for k in project.notated[str(nid)])
        extra += f", with {written} written in the score"
    numbers = ([str(i + 1) for i, c in enumerate(project.comments) if nid in c.performance]
               if kind == "perf" else [])   # comments are about performance notes only
    if numbers:
        extra += f", in comment {', '.join(numbers)}"
    anchors = project.anchors

    def names(links):
        def marks(link):
            found = [m for m, on in (("anchor", link in anchors), ("hidden", link in hidden)) if on]
            return f" ({', '.join(found)})" if found else ""
        return ", ".join(f"{other}{marks(link)}" for other, link in links)

    if kind == "perf":
        partners = [(sid, (sid, nid)) for sid in sorted(al.by_perf.get(nid, ()))]
        status = (f"linked to score {names(partners)}" if partners
                  else _unlinked_status(project, derived, row))
        return f"Performance note {nid}: {name} at {track.onset[row]:.2f} s, {status}{extra}"
    partners = [(pid, (nid, pid)) for pid in sorted(al.by_score.get(nid, ()))]
    status = f"linked to performance {names(partners)}" if partners else "no link (not played)"
    return f"Score note {nid}: {name} at beat {fmt_time(track.onset[row])}, {status}{extra}"


def describe_link(project: Project, link: Link) -> str:
    """A link, or an anchor."""
    if link in project.anchors:
        return (f"Anchor between score note {link[0]} and performance note {link[1]}. "
                "Realigning keeps it. Click to select it, P clears the anchor.")
    return (f"Link between score note {link[0]} and performance note {link[1]}. Click to "
            "select it, Delete removes it, P makes it an anchor.")


def hover_status(project: Project, derived: Derived, note: Optional[tuple] = None,
                 link: Optional[tuple] = None, hidden: Iterable[Link] = ()) -> str:
    """The status bar's text for a note (kind, row) or a link (score id,
    performance id) under the pointer, as _hover_status has it outside marking."""
    if note is not None:
        kind, row = note
        if kind not in ("perf", "score"):
            raise ValueError(f"No such roll: {kind}")
        return describe_note(project, derived, kind, int(row), hidden)
    if link is not None:
        return describe_link(project, (str(link[0]), str(link[1])))
    return ""

