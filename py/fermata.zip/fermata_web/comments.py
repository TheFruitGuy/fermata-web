"""Comments for a second reviewer, as MainWindow's Comments group handles them
(fermata/main_window.py: add_comment, open_comment, _show_comment,
reply_comment, edit_comment, toggle_resolved, delete_comment, _refresh_annotations)
with RollWidget's texts for a comment's marker (_update_hover) and where opening
one moves the rolls (show_notes, _show_spans). The comments themselves are
annotations.py's; the page keeps which one is open, as the sidebar's list does,
and asks for the reviewer's name and the texts.
"""
from __future__ import annotations

import dataclasses
from typing import Optional

import numpy as np

from fermata import annotations as ann
from fermata.model import Project

# The dim colour of the times in a comment's thread (comment_thread_html's
# default), on the sidebar's light and dark backgrounds alike.
DIM = "#8A95A0"


def view(project: Project) -> list:
    """Each comment as the page shows it: the rows of its performance notes, whether
    it's resolved, its line in the list, its thread for the sidebar and the
    pop-up, and the status bar's text for its marker."""
    perf = project.performance
    out = []
    for i, c in enumerate(project.comments):
        first = c.text.splitlines()[0] if c.text else ""
        by = f" by {c.author}" if c.author else ""
        out.append({"rows": np.array([perf.row[p] for p in c.performance if p in perf.row], np.int32),
                    "resolved": bool(c.resolved), "title": ann.comment_title(c, i + 1),
                    "thread": ann.comment_thread_html(c, i + 1, DIM),
                    "status": f"Comment {i + 1}{by}: {first} Click to open it."})
    return out


def spans(project: Project, index: int) -> dict:
    """Where opening comment index moves the rolls (show_notes and _show_spans): its
    notes' span in the performance, and the score's through the time map."""
    perf = project.performance
    rows = [perf.row[p] for p in project.comments[index].performance if p in perf.row]
    if not rows:
        return {}
    a, b = float(perf.onset[rows].min()), float(perf.offset[rows].max())
    tm = project.time_map()
    return {"perf": [a, b], "score": [float(tm.to_score(a)), float(tm.to_score(b))],
            "pitches": [int(perf.pitch[rows].min()), int(perf.pitch[rows].max())]}


def checked(project: Project, index: Optional[int]) -> int:
    if index is None or not 0 <= index < len(project.comments):
        raise LookupError(f"No such comment: {index}")
    return index


def replaced(project: Project, index: int, comment) -> list:
    comments = list(project.comments)
    comments[index] = comment
    return comments


def edited(project: Project, index: int, text: str):
    """The comment with text, or AnnotationError when there's none (edit_comment)."""
    if not text.strip():
        raise ann.AnnotationError("A comment needs some text. Delete removes it.")
    return dataclasses.replace(project.comments[index], text=text.strip())


def toggled(project: Project, index: int) -> tuple:
    """(the comment resolved or reopened, the undo text) (toggle_resolved)."""
    comment = project.comments[index]
    verb = "Reopen" if comment.resolved else "Resolve"
    return dataclasses.replace(comment, resolved=not comment.resolved), f"{verb} comment {index + 1}"


HINT = ("Select notes and press C to add a comment. Click a comment in the list, or its marker "
        "on the rolls, to open it.")
