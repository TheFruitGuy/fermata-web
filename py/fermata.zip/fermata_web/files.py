"""Files the page read with the File API, put where FERMATA opens them by path,
as the desktop opens files on the disk (web/PLAN.md, "Files").

They're kept in the site's storage, so that Recent reopens them with one click
(web/PLAN.md, decision 4): the files of each opening go into a folder of their
own in the store, named by a hash of their paths and contents, so that the same
files are kept once, and FERMATA opens them from there. In the browser the
store is on IDBFS, which the core worker mounts at /persist and saves to
IndexedDB after every call that changes it. Where there's no /persist (the
tests, or a browser that keeps nothing), a temporary folder takes its place for
as long as Python runs.
"""
from __future__ import annotations

import hashlib
import shutil
import tempfile
from pathlib import Path
from typing import Iterable, Optional

PERSIST = Path("/persist")
_store: Optional[Path] = None


def store() -> Path:
    """The folder that holds the kept copies, one folder per key."""
    global _store
    if _store is None:
        _store = PERSIST / "files" if PERSIST.is_dir() else Path(tempfile.mkdtemp(prefix="fermata-store-"))
        _store.mkdir(parents=True, exist_ok=True)
    return _store


def _check(path: str) -> list[str]:
    """The parts of a relative path, each the name of a file or folder."""
    parts = path.split("/")
    for name in parts:
        if not name or name in (".", "..") or Path(name).name != name:
            raise ValueError(f"{path!r} isn't the name of a file or folder.")
    return parts


def _key(files: dict) -> str:
    digest = hashlib.sha256()
    for path in sorted(files):
        data = bytes(files[path])
        digest.update(path.encode("utf-8") + b"\0" + len(data).to_bytes(8, "little"))
        digest.update(data)
    return digest.hexdigest()[:24]


def keep(files: dict) -> tuple[str, Path]:
    """Keep files ({relative path: bytes}, such as {"name/ppart.csv": ...}) in the
    store, and return their key and the folder they're in. The same files give
    the same key, and are written once."""
    for path in files:
        _check(path)
    key = _key(files)
    root = store() / key
    if not root.is_dir():
        partial = store() / f".{key}.partial"   # never half a copy under its key
        shutil.rmtree(partial, ignore_errors=True)
        for path, data in files.items():
            target = partial.joinpath(*_check(path))
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(bytes(data))
        partial.mkdir(parents=True, exist_ok=True)
        partial.rename(root)
    return key, root


def kept(key: str) -> Path:
    """The folder of a key's copy. ValueError when it's gone, as after the site's
    data was cleared."""
    _check(key)
    root = store() / key
    if key.startswith(".") or not root.is_dir():
        raise ValueError("Its copy in this browser's storage is gone, perhaps because the site's "
                         "data was cleared. Open the file again.")
    return root


def keys() -> list[str]:
    """The keys of every copy kept."""
    return sorted(p.name for p in store().iterdir() if p.is_dir() and not p.name.startswith("."))


def keep_only(wanted: Iterable[str]) -> list[str]:
    """Delete every copy whose key isn't wanted, and return the keys deleted."""
    wanted = set(wanted)
    gone = []
    for path in store().iterdir():
        if path.is_dir() and path.name not in wanted:
            shutil.rmtree(path, ignore_errors=True)
            if not path.name.startswith("."):
                gone.append(path.name)
    return sorted(gone)
