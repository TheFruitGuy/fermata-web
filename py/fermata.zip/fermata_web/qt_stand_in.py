"""A stand-in for PyQt6.QtCore where there is no PyQt6, so that the desktop's
fermata/session.py imports as it is (web/PLAN.md, "The desktop's code stays
as it is").

session.py takes Qt's QLockFile to keep two FERMATAs off the same backup. In
the browser, tabs are kept apart with navigator.locks instead, so here every
lock is free. Only PyQt6.QtCore is put in sys.modules, so PyQt6.QtGui and the
rest still can't be imported, and code that checks for Qt still finds none.
Where the real PyQt6 is installed, nothing is put in.
"""
from __future__ import annotations

import importlib.util
import sys
import types


class QLockFile:
    """Qt's lock file where there is no Qt: every lock is free."""

    def __init__(self, path: str):
        self.path = path

    def setStaleLockTime(self, ms: int) -> None:
        pass

    def tryLock(self, timeout: int = 0) -> bool:
        return True

    def unlock(self) -> None:
        pass


def install() -> bool:
    """Put the stand-in in sys.modules unless PyQt6 is there. True if it's in use."""
    core = sys.modules.get("PyQt6.QtCore")
    if core is not None:
        return getattr(core, "QLockFile", None) is QLockFile
    if importlib.util.find_spec("PyQt6") is not None:
        return False
    package = types.ModuleType("PyQt6")
    package.__path__ = []      # a package with nothing else in it: PyQt6.QtGui can't be found
    core = types.ModuleType("PyQt6.QtCore")
    core.QLockFile = QLockFile
    package.QtCore = core
    sys.modules["PyQt6"] = package
    sys.modules["PyQt6.QtCore"] = core
    return True
