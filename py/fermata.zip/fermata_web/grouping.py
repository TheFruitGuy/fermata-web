"""Note grouping, as MainWindow's Note grouping group does it (fermata/main_window.py:
_grouping_spec, _start_marking, _update_ornament_group, _finish_ornament,
_ornament_targets, remove_ornaments), with RollWidget's texts while marking
(_draw_marking_banner, _onset_status, _hover_status) and for ornaments written
in the score (_notated_text). The rules are annotations.py's; the page keeps
whether it's marking, as RollWidget keeps it, and sends it with each call.
"""
from __future__ import annotations

from typing import Optional

from fermata import annotations as ann
from fermata import model
from fermata.model import Project


def spec(group: str, kind: str = "", name: str = "") -> tuple[str, str, str]:
    """(grouping, type or name, "a ..." label) of what Mark grouping marks. Raises
    ann.AnnotationError for an other grouping without a usable name."""
    if group == "ornament":
        if kind not in ann.ORNAMENT_TYPES:
            raise LookupError(f"No such ornament: {kind}")
        return group, kind, ann.a_ornament(kind)
    if group == "other":
        return group, ann.other_grouping_name(name), f"the grouping {name.strip()}"
    if group not in model.GROUPINGS:
        raise LookupError(f"No such grouping: {group}")
    return group, group, ann.a_grouping(model.Ornament(group, (), (), group))


def marking_status(label: str, onset: bool) -> str:
    """The status bar's text once marking starts (_marking_changed)."""
    target = "chord" if onset else "score note"
    return f"Marking {label}: select its performance notes, then click its {target}. Esc cancels."


def banner(label: str, onset: bool, selected: bool) -> str:
    """The banner below the score roll while marking (_draw_marking_banner)."""
    target = "its chord" if onset else "its score note"
    if not selected:
        return f"Marking {label}: select its performance notes, then click {target}. Esc cancels."
    return f"Marking {label}: click {target}. Esc cancels."


def hint(label: Optional[str], onset: bool, selected: bool) -> str:
    """The Note grouping group's hint (_update_ornament_group)."""
    if label:
        name = label.split(" ", 1)[-1]
        target = "chord (any of its notes, or between them)" if onset else "score note"
        text = (f"2. Click the {target} the {name} belongs to." if selected
                else f"1. Select the performance notes of the {name}, then 2. click its {target}.")
        return text + " Esc cancels."
    return ("Choose the grouping, click Mark grouping, select its performance notes, then click "
            "its score note, or for an improvisation its chord. Click a grouping's box to select it.")


def note_status(project: Project, label: str, row: int, selected: bool) -> str:
    """Pointing at a score note while marking (_hover_status)."""
    name = label.split(" ", 1)[-1]
    sid = project.score.ids[row]
    return (f"Click to mark the {name} on score note {sid}." if selected else
            f"Select the performance notes of the {name} first, then click its score note.")


def onset_status(project: Project, sid: str, selected: bool) -> str:
    """Pointing at a chord while marking an improvisation (_onset_status)."""
    if not selected:
        return "Select the performance notes of the improvisation first, then click its chord."
    score = project.score
    chord = model.chord_notes(score, sid)
    beat = float(score.onset[score.row[sid]])
    notes = "1 note" if len(chord) == 1 else f"{len(chord)} notes"
    return (f"Click to mark the improvisation on the chord at beat {beat:g} ({notes}); its "
            f"notes are linked to the lowest, {sid}.")


def box_status(orn) -> str:
    """Pointing at a grouping's box (_hover_status)."""
    return (f"{ann.describe_ornament(orn)}. Click the box to select it; Delete then removes "
            "the ornament, and its links stay.")


def selected_text(orn) -> str:
    """The Selection group's line with a grouping's box selected (_update_sidebar)."""
    return f"{ann.describe_ornament(orn)}. Delete or Remove removes the ornament; its links stay."


def notated_text(project: Project, sid: str, kind: str) -> str:
    """The tooltip of an ornament's sign written in the score (_notated_text)."""
    score = project.score
    pitch = ann.pitch_name(int(score.pitch[score.row[sid]]))
    what = ann.ornament_description(kind)
    name = ann.ornament_name(kind)
    return (f"{name[:1].upper()}{name[1:]}, written in the score on note {sid} ({pitch})"
            + (f": {what}." if what else "."))


def targets(project: Project, ornament: Optional[int], sel_score) -> list:
    """What Remove removes: the grouping whose box is selected, by its index in
    project.ornaments, or else the groupings of the selected score notes."""
    if ornament is not None and 0 <= ornament < len(project.ornaments):
        return [project.ornaments[ornament]]
    return ann.ornaments_of(project, (), sel_score)
