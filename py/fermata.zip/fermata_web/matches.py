"""Opening a .match file in the browser: the decisions and texts of the desktop's
MainWindow.open_project, _found_score and _ask_score (fermata/main_window.py),
around fermata.model's own functions, which are called unchanged. The page shows
the boxes and reads the files the user chooses; it asks here what to look for,
what to say and what to do next (web/PLAN.md, "Logic that exists twice").

A .match file is kept in the store with its side files beside it, under the
names the user gave them, and its score in a folder of its own, also under its
own name: the .match file's name decides which score names it looks for and the
side files' names, and the score's name decides how partitura reads it.
"""
from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Optional

from fermata import model

from . import files


def is_match(name: str) -> bool:
    """Is it a .match file by its name, as the desktop's path.suffix.lower() == ".match"?"""
    return Path(name).suffix.lower() == ".match"


def keep_match(name: str, sent: dict) -> tuple[str, Path]:
    """Keep a .match file the page read, with its side files from what came with
    it ({name: bytes}): those model.match_side_files names, matched ignoring case,
    as the desktop finds them on a Mac. Any other file is left out. Returns the
    copy's key and the .match file's path."""
    ornaments, comments = model.match_side_files(Path(name))
    by_lower = {other.lower(): other for other in sent if other != name}
    chosen = {name: sent[name]}
    for side in (ornaments.name, comments.name):
        other = by_lower.get(side.lower())
        if other is not None:
            chosen[side] = sent[other]
    key, root = files.keep(chosen)
    return key, root / name


def match_in(root: Path) -> Path:
    """The .match file in a kept copy."""
    found = sorted(p for p in root.iterdir() if p.is_file() and is_match(p.name))
    if not found:
        raise ValueError("Its copy in this browser's storage can't be read. Open the file again.")
    return found[0]


def score_in(root: Path) -> Path:
    """The score in a kept copy."""
    found = sorted(p for p in root.iterdir() if p.is_file())
    if len(found) != 1:
        raise ValueError("The score's copy in this browser's storage can't be read.")
    return found[0]


def score_names(match: Path) -> list[str]:
    """The names of the score to look for, as model.match_score_names gives them.
    A file that can't be read is a message, as _ask_score shows it."""
    try:
        return model.match_score_names(match)
    except (OSError, ValueError) as exc:
        raise ValueError(f"{match.name} couldn't be read.\n\n{exc}") from exc


def find_in_listing(listing: list[str], names: list[str]) -> Optional[str]:
    """The score in a folder, from the page's listing of its files (paths relative
    to the folder, with "/"): for each name in turn, the file model.find_score
    picks, as _found_score tries them. find_score runs unchanged, on empty files
    standing in for the listing. Returns the file's relative path, or None."""
    # Only files of a wanted name can be found, so only those stand in: a big
    # score folder doesn't become thousands of empty files.
    wanted = {name.lower() for name in names}
    listing = [path for path in listing if str(path).rsplit("/", 1)[-1].lower() in wanted]
    if not listing:
        return None
    with tempfile.TemporaryDirectory(prefix="fermata-scores-") as tmp:
        root = Path(tmp) / "scores"
        root.mkdir()
        for path in listing:
            parts = str(path).split("/")
            if any(part in ("", ".", "..") for part in parts):
                continue
            target = root.joinpath(*parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.touch()
        for name in names:
            found = model.find_score(root, name)
            if found is not None:
                return found.relative_to(root).as_posix()
    return None


def ask_why(match: Path, folder_chosen: bool) -> str:
    """Why the score is asked for, when it wasn't found: _ask_score's why."""
    names = score_names(match)
    which = " or ".join(names)
    if not names:
        return (f"{match.name} doesn't say which score it goes with: its scoreFileName is -, "
                "and its name isn't one of the dataset's, such as "
                "p1200811001rachmaop30m1mi_alignment.match for rachmaop30m1.musicxml.")
    if folder_chosen:
        return f"Its score, {which}, isn't in your score folder."
    return f"Its score is {which}, and no score folder is chosen yet."


def load(match: Path, score: Path, asked: bool, found: bool):
    """open_project's loop, one turn: the project, or, when a score that was looked
    for or asked for can't be used, None and why, to ask for another. A score that
    was given (Recent's) is a message instead, as is any other problem."""
    try:
        return model.load(match, score=score), None
    except model.ScoreError as exc:
        if not asked:
            raise ValueError(f"{match.name} couldn't be opened.\n\n{exc}") from exc
        where = "The score found in your score folder can't be used. " if found else ""
        return None, f"{where}{exc}"
    except Exception as exc:   # as the desktop shows any loading problem
        raise ValueError(f"{match.name} couldn't be opened.\n\n{exc}") from exc
