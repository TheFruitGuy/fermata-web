"""FERMATA's web version, the Python side: what the core worker answers.

It runs in Pyodide next to FERMATA's Qt-free modules (fermata.model, edits,
session and the rest) and keeps no rules about the data of its own: those are
in fermata/. See web/PLAN.md.

Importing it puts the QLockFile stand-in in place where there is no PyQt6, so
fermata.session can be imported (qt_stand_in.py).
"""
from . import qt_stand_in

qt_stand_in.install()
